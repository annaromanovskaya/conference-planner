"""Validated language-model integration."""
