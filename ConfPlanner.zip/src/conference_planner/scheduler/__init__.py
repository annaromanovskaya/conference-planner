"""Background job configuration."""
