"""Async persistence layer."""
