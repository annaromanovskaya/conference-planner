from collections.abc import AsyncIterator

import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession

from conference_planner.db.migrations import run_migrations
from conference_planner.db.session import create_engine_and_sessionmaker


@pytest_asyncio.fixture
async def session(tmp_path) -> AsyncIterator[AsyncSession]:
    database_url = f"sqlite+aiosqlite:///{tmp_path / 'test.db'}"
    run_migrations(database_url)
    engine, session_factory = create_engine_and_sessionmaker(database_url)
    async with session_factory() as db_session:
        yield db_session
    await engine.dispose()
