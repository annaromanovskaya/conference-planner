import pytest

from conference_planner.schemas.common import AgentTaskType
from conference_planner.workflows.planner import WorkflowPlanner


@pytest.mark.asyncio
async def test_planner_builds_bounded_research_pipeline_for_conference_search() -> None:
    plan = await WorkflowPlanner().plan(
        1,
        "Найди конференции по звёздной астрономии 2027 и проверь дедлайны",
    )

    assert [task.task_type for task in plan.tasks] == [
        AgentTaskType.SEARCH_CANDIDATES,
        AgentTaskType.CRAWL_CANDIDATE,
        AgentTaskType.EXTRACT_RESEARCH,
        AgentTaskType.VERIFY_RESEARCH,
        AgentTaskType.PROPOSE_PERSISTENCE,
    ]
    assert len(plan.tasks) <= 8


@pytest.mark.asyncio
async def test_planner_recognizes_conference_search_with_words_between_verb_and_subject() -> None:
    plan = await WorkflowPlanner().plan(
        1,
        (
            "Найди релевантные моим темам конференции и добавь их в список "
            "кандидатов, остальные удалить"
        ),
    )

    assert [task.task_type for task in plan.tasks] == [
        AgentTaskType.SEARCH_CANDIDATES,
        AgentTaskType.CRAWL_CANDIDATE,
        AgentTaskType.EXTRACT_RESEARCH,
        AgentTaskType.VERIFY_RESEARCH,
        AgentTaskType.PROPOSE_PERSISTENCE,
    ]


@pytest.mark.asyncio
async def test_planner_starts_with_crawl_for_explicit_url() -> None:
    plan = await WorkflowPlanner().plan(
        1,
        "Проверь https://events.example/stellar-2027 и найди дедлайны",
    )

    assert plan.tasks[0].task_type == AgentTaskType.CRAWL_CANDIDATE
    assert plan.tasks[0].input_data["url"] == "https://events.example/stellar-2027"


@pytest.mark.asyncio
async def test_planner_uses_database_read_for_non_research_list_request() -> None:
    plan = await WorkflowPlanner().plan(1, "Покажи мои сохранённые конференции")

    assert [task.task_type for task in plan.tasks] == [
        AgentTaskType.READ_DATABASE,
        AgentTaskType.SYNTHESIZE_RESPONSE,
    ]
