import tomllib
from importlib import import_module
from pathlib import Path

import pytest

ROOT = Path(__file__).parents[2]


def test_project_uses_conference_planner_identity() -> None:
    package = import_module("conference_planner")
    project = tomllib.loads((ROOT / "pyproject.toml").read_text())
    dockerfile = (ROOT / "Dockerfile").read_text()

    assert package.__name__ == "conference_planner"
    assert project["project"]["name"] == "conference-planner"
    assert project["project"]["scripts"] == {
        "conference-planner": "conference_planner.main:run",
        "conference-planner-healthcheck": "conference_planner.healthcheck:run",
    }
    assert 'ENTRYPOINT ["conference-planner"]' in dockerfile
    assert 'CMD ["conference-planner-healthcheck"]' in dockerfile


def test_legacy_sqlite_database_is_moved_to_planner_name(tmp_path: Path) -> None:
    migrations = import_module("conference_planner.db.migrations")
    legacy_name = "conference_" + "s" + "cout.db"
    legacy = tmp_path / legacy_name
    target = tmp_path / "conference_planner.db"
    legacy.write_bytes(b"existing database")

    migrations.migrate_legacy_sqlite_database(f"sqlite+aiosqlite:///{target}")

    assert target.read_bytes() == b"existing database"
    assert not legacy.exists()


def test_legacy_sqlite_database_rejects_ambiguous_dual_files(tmp_path: Path) -> None:
    migrations = import_module("conference_planner.db.migrations")
    legacy_name = "conference_" + "s" + "cout.db"
    legacy = tmp_path / legacy_name
    target = tmp_path / "conference_planner.db"
    legacy.write_bytes(b"legacy")
    target.write_bytes(b"current")

    with pytest.raises(RuntimeError, match="both legacy and current"):
        migrations.migrate_legacy_sqlite_database(f"sqlite+aiosqlite:///{target}")

    assert target.read_bytes() == b"current"
    assert legacy.read_bytes() == b"legacy"
