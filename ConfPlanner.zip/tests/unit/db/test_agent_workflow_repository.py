import importlib

import pytest
from pydantic import ValidationError

from conference_planner.db.models import User


def _workflow_api():
    schemas = importlib.import_module("conference_planner.schemas.workflows")
    repositories = importlib.import_module(
        "conference_planner.db.repositories.agent_workflows"
    )
    return schemas, repositories.AgentWorkflowRepository


def _plan(schemas):
    return schemas.WorkflowPlan(
        tasks=(
            schemas.WorkflowTaskSpec(
                task_id="search",
                task_type="SEARCH_CANDIDATES",
            ),
            schemas.WorkflowTaskSpec(
                task_id="crawl",
                task_type="CRAWL_CANDIDATE",
                dependencies=("search",),
            ),
        )
    )


def _budget(schemas):
    return schemas.WorkflowBudget(
        max_tasks=8,
        max_model_calls=3,
        max_tokens=10_000,
        timeout_seconds=300,
    )


def test_workflow_plan_rejects_cycles() -> None:
    schemas, _ = _workflow_api()

    with pytest.raises(ValidationError, match="cycle"):
        schemas.WorkflowPlan(
            tasks=(
                schemas.WorkflowTaskSpec(
                    task_id="first",
                    task_type="SEARCH_CANDIDATES",
                    dependencies=("second",),
                ),
                schemas.WorkflowTaskSpec(
                    task_id="second",
                    task_type="CRAWL_CANDIDATE",
                    dependencies=("first",),
                ),
            )
        )


def test_workflow_plan_rejects_unknown_task_type() -> None:
    schemas, _ = _workflow_api()

    with pytest.raises(ValidationError):
        schemas.WorkflowTaskSpec(task_id="unsafe", task_type="EXECUTE_SHELL")


@pytest.mark.asyncio
async def test_repository_keeps_runs_owner_scoped(session) -> None:
    schemas, repository_type = _workflow_api()
    first = User(telegram_id=101)
    second = User(telegram_id=202)
    session.add_all((first, second))
    await session.flush()
    repository = repository_type(session)

    run = await repository.create_run(
        first.id,
        "Найди конференции",
        _plan(schemas),
        _budget(schemas),
    )

    assert run.user_id == first.id
    assert run.status.value == "PLANNED"
    with pytest.raises(ValueError, match="run not found"):
        await repository.get_run(second.id, run.id)


@pytest.mark.asyncio
async def test_claim_ready_task_waits_for_dependencies_and_is_atomic(session) -> None:
    schemas, repository_type = _workflow_api()
    user = User(telegram_id=303)
    session.add(user)
    await session.flush()
    repository = repository_type(session)
    run = await repository.create_run(user.id, "Проверь IAU", _plan(schemas), _budget(schemas))

    first = await repository.claim_ready_task(run.id)
    duplicate_claim = await repository.claim_ready_task(run.id)

    assert first is not None
    assert first.task_key == "search"
    assert first.status.value == "RUNNING"
    assert duplicate_claim is None

    artifact = await repository.complete_task(
        first.id,
        artifact_kind="search_results",
        payload={"candidate_ids": [7]},
        source_hashes=("sha256:first",),
    )
    second = await repository.claim_ready_task(run.id)

    assert artifact.payload == {"candidate_ids": [7]}
    assert artifact.source_hashes == ["sha256:first"]
    assert second is not None
    assert second.task_key == "crawl"


@pytest.mark.asyncio
async def test_resume_requeues_retryable_failure_without_repeating_completed_task(session) -> None:
    schemas, repository_type = _workflow_api()
    user = User(telegram_id=404)
    session.add(user)
    await session.flush()
    repository = repository_type(session)
    run = await repository.create_run(user.id, "Возобнови поиск", _plan(schemas), _budget(schemas))
    search = await repository.claim_ready_task(run.id)
    assert search is not None
    await repository.complete_task(search.id, "search_results", {"count": 1}, ())
    crawl = await repository.claim_ready_task(run.id)
    assert crawl is not None
    await repository.fail_task(crawl.id, "FETCH_TIMEOUT", retryable=True)

    resumed = await repository.resume_run(run.id)
    tasks = await repository.list_tasks(run.id)

    assert resumed.status.value == "PLANNED"
    assert [(task.task_key, task.status.value) for task in tasks] == [
        ("search", "COMPLETED"),
        ("crawl", "PENDING"),
    ]
