from datetime import UTC, datetime

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from conference_planner.db.repositories.web_cache import WebDocumentCacheRepository
from conference_planner.web.fetcher import FetchedPage


@pytest.mark.asyncio
async def test_web_cache_stores_and_updates_document_metadata(session: AsyncSession) -> None:
    repository = WebDocumentCacheRepository(session)
    first_seen = datetime(2026, 10, 15, 8, tzinfo=UTC)
    updated = await repository.store(
        FetchedPage(
            "https://event.example/",
            "<p>First</p>",
            status_code=200,
            etag='"v1"',
            last_modified="Wed, 14 Oct 2026 08:00:00 GMT",
            content_hash="first-hash",
        ),
        "First",
        observed_at=first_seen,
    )
    await session.commit()

    cached = await repository.get("https://event.example/")
    assert cached is not None
    assert cached.id == updated.id
    assert cached.extracted_text == "First"
    assert cached.etag == '"v1"'
    assert cached.content_hash == "first-hash"
    assert cached.observed_at == first_seen

    second_seen = datetime(2026, 10, 18, 8, tzinfo=UTC)
    await repository.store(
        FetchedPage(
            "https://event.example/",
            "<p>Second</p>",
            status_code=200,
            etag='"v1"',
            content_hash="second-hash",
        ),
        "Second",
        observed_at=second_seen,
    )
    await session.commit()

    cached = await repository.get("https://event.example/")
    assert cached is not None
    assert cached.id == updated.id
    assert cached.extracted_text == "Second"
    assert cached.content_hash == "second-hash"
    assert cached.observed_at == second_seen
