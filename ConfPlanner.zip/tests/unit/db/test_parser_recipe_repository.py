import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from conference_planner.db.repositories.parser_recipes import ParserRecipeRepository
from conference_planner.schemas.parser_recipes import PageKind, ParserRecipe, RecipeStatus


def recipe(selector: str = "main h1") -> ParserRecipe:
    return ParserRecipe(
        domain="Events.Example",
        page_kind=PageKind.DETAIL,
        field_selectors={"name": selector},
        link_labels=("important dates",),
    )


@pytest.mark.asyncio
async def test_parser_recipe_versions_and_activates_only_latest_validated_recipe(
    session: AsyncSession,
) -> None:
    repository = ParserRecipeRepository(session)
    first = await repository.propose(recipe())
    second = await repository.propose(recipe("article h1"))

    assert (first.version, second.version) == (1, 2)
    assert first.status == RecipeStatus.PROPOSED
    await repository.activate_after_validation(first.id)
    assert await repository.active_for(
        "https://events.example/meeting", PageKind.DETAIL
    ) == first

    await repository.activate_after_validation(second.id)
    await session.refresh(first)
    assert first.status == RecipeStatus.DISABLED
    assert second.status == RecipeStatus.ACTIVE
    assert await repository.active_for(
        "https://EVENTS.example/another", PageKind.DETAIL
    ) == second


@pytest.mark.asyncio
async def test_parser_recipe_can_be_marked_degraded_when_layout_changes(
    session: AsyncSession,
) -> None:
    repository = ParserRecipeRepository(session)
    stored = await repository.propose(recipe())
    await repository.activate_after_validation(stored.id)

    degraded = await repository.mark_degraded(stored.id, "REQUIRED_FIELD_MISSING")

    assert degraded.status == RecipeStatus.DEGRADED
    assert degraded.failure_count == 1
    assert degraded.last_error_code == "REQUIRED_FIELD_MISSING"
    assert await repository.active_for(
        "https://events.example/meeting", PageKind.DETAIL
    ) is None


@pytest.mark.asyncio
async def test_parser_recipe_repository_rejects_unsafe_proposal(session: AsyncSession) -> None:
    repository = ParserRecipeRepository(session)

    with pytest.raises(ValueError):
        await repository.propose(recipe("script"))


@pytest.mark.asyncio
async def test_parser_recipe_repository_exposes_validated_schema(
    session: AsyncSession,
) -> None:
    repository = ParserRecipeRepository(session)
    stored = await repository.propose(recipe(".important-date"))

    schema = repository.to_schema(stored)

    assert schema.domain == "events.example"
    assert schema.field_selectors == {"name": ".important-date"}
