from datetime import UTC, date, datetime

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from conference_planner.ai.models import ChatResponse
from conference_planner.db.repositories.ollama_usage import OllamaUsageRepository
from conference_planner.db.repositories.users import UserRepository
from conference_planner.schemas.common import ProviderUsageStatus


async def _user_id(session: AsyncSession, telegram_id: int) -> int:
    user = await UserRepository(session).get_or_create_by_telegram_id(telegram_id)
    await session.flush()
    return user.id


@pytest.mark.asyncio
async def test_record_success_creates_and_increments_daily_aggregate(
    session: AsyncSession,
) -> None:
    user_id = await _user_id(session, 101)
    repository = OllamaUsageRepository(session)
    observed_at = datetime(2026, 10, 14, 8, 30, tzinfo=UTC)

    await repository.record_success(
        user_id,
        "ollama-cloud",
        "gemma4:31b",
        ChatResponse(prompt_tokens=120, cached_prompt_tokens=80, output_tokens=25),
        observed_at,
    )
    await repository.record_success(
        user_id,
        "ollama-cloud",
        "gemma4:31b",
        ChatResponse(prompt_tokens=30, output_tokens=5),
        observed_at,
    )

    rows = await repository.get_daily_totals(user_id, "ollama-cloud", date(2026, 10, 14))
    status = await repository.get_status(user_id, "ollama-cloud")

    assert len(rows) == 1
    assert rows[0].request_count == 2
    assert rows[0].prompt_tokens == 150
    assert rows[0].cached_prompt_tokens == 80
    assert rows[0].output_tokens == 30
    assert status is not None
    assert status.status is ProviderUsageStatus.AVAILABLE
    assert status.model_name == "gemma4:31b"
    assert status.observed_at == observed_at


@pytest.mark.asyncio
async def test_usage_aggregates_do_not_mix_owner_model_or_utc_day(
    session: AsyncSession,
) -> None:
    first_user = await _user_id(session, 201)
    second_user = await _user_id(session, 202)
    repository = OllamaUsageRepository(session)
    response = ChatResponse(prompt_tokens=10, cached_prompt_tokens=4, output_tokens=2)

    await repository.record_success(
        first_user,
        "ollama-cloud",
        "gemma4:31b",
        response,
        datetime(2026, 10, 14, 23, 59, tzinfo=UTC),
    )
    await repository.record_success(
        first_user,
        "ollama-cloud",
        "gpt-oss:20b",
        response,
        datetime(2026, 10, 14, 12, 0, tzinfo=UTC),
    )
    await repository.record_success(
        first_user,
        "ollama-cloud",
        "gemma4:31b",
        response,
        datetime(2026, 10, 15, 0, 1, tzinfo=UTC),
    )
    await repository.record_success(
        second_user,
        "ollama-cloud",
        "gemma4:31b",
        response,
        datetime(2026, 10, 14, 12, 0, tzinfo=UTC),
    )

    first_day = await repository.get_daily_totals(first_user, "ollama-cloud", date(2026, 10, 14))
    second_day = await repository.get_daily_totals(first_user, "ollama-cloud", date(2026, 10, 15))
    other_owner = await repository.get_daily_totals(second_user, "ollama-cloud", date(2026, 10, 14))

    assert [(row.model_name, row.request_count) for row in first_day] == [
        ("gemma4:31b", 1),
        ("gpt-oss:20b", 1),
    ]
    assert [(row.model_name, row.request_count) for row in second_day] == [("gemma4:31b", 1)]
    assert [(row.model_name, row.request_count) for row in other_owner] == [("gemma4:31b", 1)]


@pytest.mark.asyncio
async def test_success_without_counters_records_status_but_not_fake_totals(
    session: AsyncSession,
) -> None:
    user_id = await _user_id(session, 301)
    repository = OllamaUsageRepository(session)
    observed_at = datetime(2026, 10, 14, 9, 0, tzinfo=UTC)

    await repository.record_success(
        user_id,
        "ollama-cloud",
        "gemma4:31b",
        ChatResponse(content="ok"),
        observed_at,
    )

    rows = await repository.get_daily_totals(user_id, "ollama-cloud", date(2026, 10, 14))
    status = await repository.get_status(user_id, "ollama-cloud")

    assert rows == ()
    assert status is not None
    assert status.status is ProviderUsageStatus.AVAILABLE
    assert status.observed_at == observed_at


@pytest.mark.asyncio
async def test_month_totals_sum_only_requested_calendar_range(
    session: AsyncSession,
) -> None:
    user_id = await _user_id(session, 401)
    repository = OllamaUsageRepository(session)
    response = ChatResponse(prompt_tokens=10, cached_prompt_tokens=4, output_tokens=2)
    for observed_at in (
        datetime(2026, 9, 30, 23, 59, tzinfo=UTC),
        datetime(2026, 10, 1, 0, 0, tzinfo=UTC),
        datetime(2026, 10, 31, 23, 59, tzinfo=UTC),
        datetime(2026, 11, 1, 0, 0, tzinfo=UTC),
    ):
        await repository.record_success(
            user_id, "ollama-cloud", "gemma4:31b", response, observed_at
        )

    totals = await repository.get_month_totals(
        user_id,
        "ollama-cloud",
        date(2026, 10, 1),
        date(2026, 11, 1),
    )

    assert totals["gemma4:31b"].request_count == 2
    assert totals["gemma4:31b"].prompt_tokens == 20
    assert totals["gemma4:31b"].cached_prompt_tokens == 8
    assert totals["gemma4:31b"].output_tokens == 4
