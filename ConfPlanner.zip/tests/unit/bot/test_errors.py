from dataclasses import dataclass

import pytest

from conference_planner.ai.gateway import ModelGatewayError
from conference_planner.bot.errors import ExternalErrorMiddleware


@dataclass
class FakeMessage:
    answers: list[tuple[str, dict]]

    async def answer(self, text: str, **kwargs) -> None:
        self.answers.append((text, kwargs))


@pytest.mark.asyncio
async def test_provider_failure_is_reported_to_user_without_details() -> None:
    event = FakeMessage([])

    async def handler(_event, _data):
        raise ModelGatewayError("secret backend details")

    result = await ExternalErrorMiddleware()(handler, event, {})

    assert result is None
    assert len(event.answers) == 1
    assert "модел" in event.answers[0][0].casefold()
    assert "secret backend details" not in event.answers[0][0]
    assert event.answers[0][1]["reply_markup"].is_persistent is True


@pytest.mark.asyncio
async def test_provider_failure_clears_active_dialogue_state() -> None:
    class State:
        cleared = False

        async def clear(self):
            self.cleared = True

    state = State()

    async def handler(_event, _data):
        raise ModelGatewayError("upstream failed")

    await ExternalErrorMiddleware()(handler, FakeMessage([]), {"state": state})

    assert state.cleared is True
