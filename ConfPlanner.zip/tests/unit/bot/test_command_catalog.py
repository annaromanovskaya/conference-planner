from conference_planner.bot.command_catalog import COMMANDS, command_help_text


def test_command_catalog_contains_every_supported_user_command() -> None:
    assert tuple(item.usage for item in COMMANDS) == (
        "/start",
        "/help",
        "/model",
        "/new",
        "/memory",
        "/forget ID",
        "/cancel",
        "/test_reminder",
        "/cancel_test_reminder",
    )
    assert "/test_conference" not in command_help_text()


def test_command_catalog_renders_a_readable_russian_list() -> None:
    text = command_help_text()

    assert text.startswith("КОМАНДЫ\n")
    assert "/help — показать возможности и список команд" in text
    assert "/test_reminder — создать одноразовое тестовое напоминание" in text
