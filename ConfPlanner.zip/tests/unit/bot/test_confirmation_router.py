from types import SimpleNamespace

import pytest

from conference_planner.agent.actions import ActionUnavailable
from conference_planner.bot.confirmation_router import cancel_action, confirm_action
from conference_planner.schemas.agent import (
    ActionResult,
    DeleteConferenceAction,
    DeleteSourceAction,
    DeleteTopicAction,
    ImportConferenceCandidateAction,
    SaveMemoryAction,
)
from conference_planner.schemas.common import MemoryKind, MemoryScope


class Callback:
    def __init__(self, data):
        self.data = data
        self.message = self
        self.answers = []

    async def answer(self, text=None, **kwargs):
        self.answers.append((text, kwargs))


@pytest.mark.asyncio
async def test_confirmation_is_owner_bound_and_duplicate_is_harmless() -> None:
    calls = []

    class Service:
        async def confirm(self, user_id, action_id):
            calls.append((user_id, action_id))
            if len(calls) > 1:
                raise ActionUnavailable("action already completed")
            return ActionResult(action_id=action_id, success=True, message="done")

    first, duplicate = Callback("action:confirm:12"), Callback("action:confirm:12")
    await confirm_action(first, Service(), owner_user_id=7)
    await confirm_action(duplicate, Service(), owner_user_id=7)

    assert calls == [(7, 12), (7, 12)]
    assert "уже" in duplicate.answers[-1][0].casefold()


@pytest.mark.asyncio
async def test_malformed_action_id_is_rejected_without_repository_access() -> None:
    service = SimpleNamespace()
    callback = Callback("action:confirm:" + "9" * 100)

    await confirm_action(callback, service, owner_user_id=7)

    assert "некоррект" in callback.answers[-1][0].casefold()


@pytest.mark.asyncio
async def test_cancel_calls_owner_scoped_service() -> None:
    calls = []

    class Service:
        async def cancel(self, user_id, action_id):
            calls.append((user_id, action_id))

    callback = Callback("action:cancel:4")
    await cancel_action(callback, Service(), owner_user_id=7)
    assert calls == [(7, 4)]


@pytest.mark.asyncio
async def test_confirmed_candidate_import_advances_queue() -> None:
    class Service:
        async def get_payload(self, user_id, action_id):
            assert (user_id, action_id) == (7, 12)
            return ImportConferenceCandidateAction(candidate_id=4)

        async def confirm(self, user_id, action_id):
            return ActionResult(action_id=action_id, success=True, message="Кандидат добавлен.")

    candidate = SimpleNamespace(
        id=5,
        title="Next candidate",
        source_url="https://next.example/event",
        summary="Next",
        verification_status=SimpleNamespace(value="UNVERIFIABLE"),
    )

    class Repository:
        async def list_candidates(self, _user_id, _status, *, limit):
            return [candidate][:limit]

    callback = Callback("action:confirm:12")
    await confirm_action(
        callback,
        Service(),
        owner_user_id=7,
        conference_research_repository=Repository(),
    )

    assert any("Next candidate" in text for text, _kwargs in callback.answers)


@pytest.mark.asyncio
async def test_execution_failure_has_candidate_specific_message() -> None:
    class Service:
        async def get_payload(self, _user_id, _action_id):
            return ImportConferenceCandidateAction(candidate_id=4)

        async def confirm(self, _user_id, _action_id):
            raise ActionUnavailable("action execution failed")

    callback = Callback("action:confirm:12")
    await confirm_action(callback, Service(), owner_user_id=7)

    assert "проверить или сохранить" in callback.answers[-1][0].casefold()


@pytest.mark.asyncio
async def test_execution_failure_has_memory_specific_message() -> None:
    class Service:
        async def get_payload(self, _user_id, _action_id):
            return SaveMemoryAction(
                kind=MemoryKind.PREFERENCE,
                scope=MemoryScope.GLOBAL,
                original_text="Мне интересна звёздная спектроскопия",
                rule_data={"statement": "Мне интересна звёздная спектроскопия"},
                provenance={"source": "owner_message"},
            )

        async def confirm(self, _user_id, _action_id):
            raise ActionUnavailable("action execution failed")

    callback = Callback("action:confirm:12")
    await confirm_action(callback, Service(), owner_user_id=7)

    assert "памят" in callback.answers[-1][0].casefold()
    assert "конференц" not in callback.answers[-1][0].casefold()


@pytest.mark.asyncio
async def test_missing_topic_has_specific_message() -> None:
    class Service:
        async def get_payload(self, _user_id, _action_id):
            return DeleteTopicAction(topic_id=8, name="Астрохимия")

        async def confirm(self, _user_id, _action_id):
            raise ActionUnavailable("topic not found")

    callback = Callback("action:confirm:12")
    await confirm_action(callback, Service(), owner_user_id=7)

    assert "уже удалена или недоступна" in callback.answers[-1][0].casefold()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("payload", "error", "expected"),
    [
        (
            DeleteSourceAction(source_id=3, name="ESO Meetings"),
            "source not found",
            "источник уже удалён или недоступен",
        ),
        (
            DeleteConferenceAction(conference_id=5, name="IMBASE 2027"),
            "conference not found",
            "конференция уже удалена или недоступна",
        ),
    ],
)
async def test_missing_deleted_object_has_specific_message(payload, error, expected) -> None:
    class Service:
        async def get_payload(self, _user_id, _action_id):
            return payload

        async def confirm(self, _user_id, _action_id):
            raise ActionUnavailable(error)

    callback = Callback("action:confirm:12")
    await confirm_action(callback, Service(), owner_user_id=7)

    assert expected in callback.answers[-1][0].casefold()
