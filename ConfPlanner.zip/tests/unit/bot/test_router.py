from types import SimpleNamespace

import pytest
from aiogram import Router
from pydantic import ValidationError

from conference_planner.ai.gateway import ModelGatewayError
from conference_planner.ai.service import AIResponseError
from conference_planner.bot import router as bot_router
from conference_planner.bot.keyboards import topic_management
from conference_planner.bot.router import build_router
from conference_planner.schemas.agent import DeleteTopicAction
from conference_planner.schemas.topics import TopicNormalization


@pytest.mark.asyncio
async def test_topic_normalization_uses_successful_model_result() -> None:
    expected = TopicNormalization(
        name="Астрохимия",
        description="Химические процессы в космосе",
        keywords=["астрохимия", "молекулы"],
    )

    class AIService:
        async def normalize_topic(self, raw_text):
            assert raw_text == "Астрохимия"
            return expected

    result = await bot_router.normalize_topic_or_fallback(AIService(), "Астрохимия")

    assert result is expected


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "error",
    [AIResponseError("invalid JSON"), ModelGatewayError("temporarily unavailable")],
)
async def test_topic_normalization_falls_back_for_expected_model_errors(error) -> None:
    class AIService:
        async def normalize_topic(self, _raw_text):
            raise error

    result = await bot_router.normalize_topic_or_fallback(AIService(), "  Астрохимия  ")

    assert result == TopicNormalization(
        name="Астрохимия",
        description="Астрохимия",
        keywords=["Астрохимия"],
    )


@pytest.mark.asyncio
async def test_topic_normalization_does_not_hide_programming_errors() -> None:
    class AIService:
        async def normalize_topic(self, _raw_text):
            raise RuntimeError("bug")

    with pytest.raises(RuntimeError, match="bug"):
        await bot_router.normalize_topic_or_fallback(AIService(), "Астрохимия")


@pytest.mark.asyncio
async def test_topic_normalization_does_not_create_blank_fallback() -> None:
    class AIService:
        async def normalize_topic(self, _raw_text):
            raise AIResponseError("invalid JSON")

    with pytest.raises(ValidationError):
        await bot_router.normalize_topic_or_fallback(AIService(), "   ")


@pytest.mark.asyncio
async def test_topic_normalization_bounds_long_fallback_text() -> None:
    class AIService:
        async def normalize_topic(self, _raw_text):
            raise AIResponseError("invalid JSON")

    result = await bot_router.normalize_topic_or_fallback(AIService(), "А" * 2_101)

    assert len(result.name) == 200
    assert len(result.description) == 2_000
    assert result.keywords == ["А" * 200]


def test_router_registers_owner_management_flows() -> None:
    router = build_router(owner_telegram_id=123)
    assert isinstance(router, Router)
    assert router.message.handlers
    assert router.callback_query.handlers
    assert "ollama-usage" in [child.name for child in router.sub_routers]
    assert "conference-views" in [child.name for child in router.sub_routers]
    assert [child.name for child in router.sub_routers][-2:] == [
        "agent-chat",
        "callback-fallback",
    ]


def test_topic_management_has_delete_button_for_each_topic_and_add_button() -> None:
    topics = [
        SimpleNamespace(id=7, name="Астрохимия"),
        SimpleNamespace(id=8, name="Очень длинная тема " * 10),
    ]

    keyboard = topic_management(topics)
    buttons = [button for row in keyboard.inline_keyboard for button in row]

    assert buttons[0].text == "Удалить: Астрохимия"
    assert buttons[0].callback_data == "topic:delete:7"
    assert buttons[1].callback_data == "topic:delete:8"
    assert len(buttons[1].text) <= 48
    assert buttons[-1].text == "Добавить"
    assert buttons[-1].callback_data == "topic:add"


def test_flow_input_does_not_capture_bot_commands() -> None:
    assert bot_router.is_flow_text("астрономия") is True
    assert bot_router.is_flow_text("/model") is False
    assert bot_router.is_flow_text("  /help") is False
    assert bot_router.is_flow_text("") is False


def test_flow_input_does_not_capture_any_main_menu_button() -> None:
    for label in bot_router.MAIN_MENU_BUTTONS:
        assert bot_router.is_flow_text(label) is False


@pytest.mark.parametrize(
    "label",
    ["Дальше", "Следующий кандидат", "начинай верификацию", "давай дальше"],
)
def test_candidate_queue_commands_bypass_chat_agent(label: str) -> None:
    assert bot_router.is_next_candidate_text(label) is True
    assert bot_router.is_flow_text(label) is False


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("https://example.org/events", ("PAGE", "https://example.org/events")),
        ("PAGE https://example.org/events", ("PAGE", "https://example.org/events")),
        ("domain iau.org", ("DOMAIN", "iau.org")),
        ("iau.org", ("DOMAIN", "iau.org")),
        ("not a source", None),
    ],
)
def test_source_input_accepts_bare_url_and_domain(raw, expected) -> None:
    parsed = bot_router.parse_source_input(raw)

    if expected is None:
        assert parsed is None
    else:
        assert parsed is not None
        assert (parsed[0].value, parsed[1]) == expected


@pytest.mark.asyncio
async def test_opening_menu_clears_stale_input_state() -> None:
    class State:
        cleared = False

        async def clear(self):
            self.cleared = True

    state = State()

    await bot_router.open_menu(state)

    assert state.cleared is True


@pytest.mark.asyncio
async def test_cancel_command_clears_flow_state() -> None:
    class State:
        cleared = False

        async def clear(self):
            self.cleared = True

    class Message:
        def __init__(self):
            self.answers = []

        async def answer(self, text, **kwargs):
            self.answers.append((text, kwargs))

    state, message = State(), Message()

    await bot_router.cancel_flow(message, state)

    assert state.cleared is True
    assert "отмен" in message.answers[0][0].casefold()
    assert message.answers[0][1]["reply_markup"].is_persistent is True


@pytest.mark.asyncio
async def test_topics_renders_ampersand_through_html() -> None:
    class State:
        async def clear(self):
            return None

    class Message:
        def __init__(self):
            self.answers = []

        async def answer(self, text, **kwargs):
            self.answers.append((text, kwargs))

    class TopicRepository:
        owner_user_id = 123

        async def list_for_user(self, user_id):
            assert user_id == 123
            return [SimpleNamespace(id=9, name="Astro-ML & Stellar Physics")]

    router = build_router(owner_telegram_id=123)
    handler = next(
        item.callback
        for item in router.message.handlers
        if item.callback.__name__ == "topics"
    )
    message = Message()

    await handler(message, State(), TopicRepository())

    text, kwargs = message.answers[0]
    assert text == "⭐ Astro-ML &amp; Stellar Physics"
    assert kwargs["parse_mode"] == "HTML"
    delete_button = kwargs["reply_markup"].inline_keyboard[0][0]
    assert delete_button.callback_data == "topic:delete:9"


@pytest.mark.asyncio
async def test_topic_delete_callback_only_proposes_owner_scoped_action() -> None:
    class Message:
        def __init__(self):
            self.answers = []

        async def answer(self, text, **kwargs):
            self.answers.append((text, kwargs))

    class Callback:
        data = "topic:delete:9"

        def __init__(self):
            self.message = Message()
            self.answered = False

        async def answer(self, *_args, **_kwargs):
            self.answered = True

    class TopicRepository:
        async def get_for_user(self, user_id, topic_id):
            assert (user_id, topic_id) == (123, 9)
            return SimpleNamespace(id=9, name="Astro-ML & Stellar Physics")

    class ConfirmationService:
        def __init__(self):
            self.payload = None

        async def propose(self, user_id, payload):
            assert user_id == 123
            self.payload = payload
            return SimpleNamespace(id=41, summary=payload.confirmation_summary())

    router = build_router(owner_telegram_id=123)
    handler = next(
        item.callback
        for item in router.callback_query.handlers
        if item.callback.__name__ == "topic_delete"
    )
    callback = Callback()
    confirmation = ConfirmationService()

    await handler(callback, confirmation, TopicRepository(), 123)

    assert confirmation.payload == DeleteTopicAction(
        topic_id=9,
        name="Astro-ML & Stellar Physics",
    )
    assert callback.message.answers[0][0] == "Удалить тему «Astro-ML & Stellar Physics»"
    confirm_button = callback.message.answers[0][1]["reply_markup"].inline_keyboard[0][0]
    assert confirm_button.callback_data == "action:confirm:41"
    assert callback.answered is True


@pytest.mark.asyncio
async def test_sources_use_friendly_title_for_legacy_cadc_url_name() -> None:
    class State:
        async def clear(self):
            return None

    class Message:
        def __init__(self):
            self.answers = []

        async def answer(self, text, **kwargs):
            self.answers.append((text, kwargs))

    url = "https://www.cadc-ccda.hia-iha.nrc-cnrc.gc.ca/en/meetings/"

    class SourceRepository:
        async def list_all(self):
            return [SimpleNamespace(id=5, name=url, url=url, enabled=True)]

    router = build_router(owner_telegram_id=123)
    handler = next(
        item.callback
        for item in router.message.handlers
        if item.callback.__name__ == "sources"
    )
    message = Message()

    await handler(message, State(), SourceRepository())

    assert message.answers[0][0] == (
        "✅ International Astronomy Meetings — Canadian Astronomy Data Centre — " + url
    )
    delete_button = message.answers[0][1]["reply_markup"].inline_keyboard[0][0]
    assert delete_button.callback_data == "source:delete:5"


@pytest.mark.asyncio
async def test_source_delete_callback_only_creates_confirmation() -> None:
    class Message:
        def __init__(self):
            self.answers = []

        async def answer(self, text, **kwargs):
            self.answers.append((text, kwargs))

    class Callback:
        data = "source:delete:5"

        def __init__(self):
            self.message = Message()

        async def answer(self, *_args, **_kwargs):
            return None

    class SourceRepository:
        async def get(self, source_id):
            assert source_id == 5
            return SimpleNamespace(
                id=5,
                name="ESO Meetings 2027",
                url="https://www.eso.org/sci/meetings/2027.html",
            )

    class ConfirmationService:
        async def propose(self, user_id, payload):
            assert user_id == 123
            assert payload.action == "delete_source"
            return SimpleNamespace(id=44, summary=payload.confirmation_summary())

    router = build_router(owner_telegram_id=123)
    handler = next(
        item.callback
        for item in router.callback_query.handlers
        if item.callback.__name__ == "source_delete"
    )
    callback = Callback()

    await handler(callback, ConfirmationService(), SourceRepository(), 123)

    assert callback.message.answers[0][0] == "Удалить источник «ESO Meetings 2027»"
    button = callback.message.answers[0][1]["reply_markup"].inline_keyboard[0][0]
    assert button.callback_data == "action:confirm:44"
