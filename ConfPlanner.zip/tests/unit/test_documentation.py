from pathlib import Path

ROOT = Path(__file__).parents[2]


def test_readme_contains_required_operator_sections() -> None:
    readme = (ROOT / "README.md").read_text()
    for heading in (
        "Возможности",
        "Архитектура",
        "Мультиагентная система",
        "Требования",
        "Быстрый запуск",
        "Создание Telegram-бота",
        "Подключение моделей",
        "Команды Telegram",
        "Примеры запросов",
        "Память и граф знаний",
        "Поиск конференций",
        "Карточки кандидатов",
        "Проверка данных",
        "Отслеживание дедлайнов",
        "Автоматическое расписание",
        "Резервное копирование",
        "Безопасность",
        "Диагностика",
        "Ограничения",
        "Лицензия",
    ):
        assert f"## {heading}" in readme
    assert "docker compose up -d" in readme
    assert "/data/conference_planner.db" in readme
    assert "LLM_LOCAL_BASE_URL" in readme
    assert "Free usage" in readme
    assert "обычным сообщением" in readme
    assert "MONITORING_INTERVAL_HOURS" in readme
    assert "AGENT_RESEARCH_MODEL" in readme
    assert "AGENT_VERIFIER_MODEL" in readme
    assert "AGENT_WORKFLOWS_ENABLED" in readme
    assert "72 часа" in readme
    assert "долговечные многошаговые workflow" in readme
    assert "APP_TIMEZONE=Europe/Moscow" in readme
    assert "Каждый понедельник" in readme
    assert "Отслеживать" in readme
    assert "Пропустить" in readme
    assert "Отклонить" in readme
    assert "REMINDER_HOUR" in readme
    assert "30,14,7,3,1,0" in readme
    assert "раз в час" not in readme
    assert "OpenRouter" not in readme


def test_example_environment_contains_no_real_secrets() -> None:
    example = (ROOT / ".env.example").read_text()
    assert "YOUR_TELEGRAM_BOT_TOKEN" in example
    assert "YOUR_OLLAMA_CLOUD_API_KEY" in example
    assert "YOUR_LLM_LOCAL_API_KEY" in example
    assert "sk-or-" not in example
    assert "hub_" not in example
