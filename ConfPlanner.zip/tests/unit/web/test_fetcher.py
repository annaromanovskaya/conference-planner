import ipaddress

import httpx
import pytest

from conference_planner.web.fetcher import FetchError, PageFetcher, normalized_content_hash
from conference_planner.web.url_safety import URLSafetyPolicy


async def public_resolver(_host: str, _port: int):
    return [ipaddress.ip_address("93.184.216.34")]


@pytest.mark.asyncio
async def test_fetcher_returns_bounded_html() -> None:
    transport = httpx.MockTransport(
        lambda _: httpx.Response(200, headers={"content-type": "text/html"}, text="<h1>Event</h1>")
    )
    async with httpx.AsyncClient(transport=transport) as client:
        page = await PageFetcher(client, URLSafetyPolicy(public_resolver)).fetch(
            "https://event.example", max_bytes=100
        )
    assert page.url == "https://event.example/"
    assert page.html == "<h1>Event</h1>"


@pytest.mark.asyncio
async def test_fetcher_rejects_non_html() -> None:
    transport = httpx.MockTransport(
        lambda _: httpx.Response(200, headers={"content-type": "application/pdf"}, content=b"pdf")
    )
    async with httpx.AsyncClient(transport=transport) as client:
        with pytest.raises(FetchError):
            await PageFetcher(client, URLSafetyPolicy(public_resolver)).fetch(
                "https://event.example", max_bytes=100
            )


@pytest.mark.asyncio
async def test_fetcher_exposes_safe_http_status_code_without_response_body() -> None:
    transport = httpx.MockTransport(
        lambda _: httpx.Response(403, text="private anti-bot diagnostics")
    )
    async with httpx.AsyncClient(transport=transport) as client:
        with pytest.raises(FetchError) as caught:
            await PageFetcher(client, URLSafetyPolicy(public_resolver)).fetch(
                "https://event.example", max_bytes=100
            )

    assert caught.value.code == "ACCESS_DENIED"
    assert "403" in caught.value.user_message
    assert "private" not in caught.value.user_message


@pytest.mark.asyncio
async def test_fetcher_sends_validators_and_accepts_not_modified() -> None:
    requests: list[httpx.Request] = []

    def handle(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(
            304,
            headers={"etag": '"new"', "last-modified": "Thu, 15 Oct 2026 08:00:00 GMT"},
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handle)) as client:
        page = await PageFetcher(client, URLSafetyPolicy(public_resolver)).fetch(
            "https://event.example",
            max_bytes=100,
            etag='"old"',
            last_modified="Wed, 14 Oct 2026 08:00:00 GMT",
        )

    assert requests[0].headers["if-none-match"] == '"old"'
    assert requests[0].headers["if-modified-since"] == "Wed, 14 Oct 2026 08:00:00 GMT"
    assert page.status_code == 304
    assert page.not_modified is True
    assert page.html == ""
    assert page.etag == '"new"'


def test_normalized_content_hash_ignores_layout_whitespace_but_detects_changes() -> None:
    assert normalized_content_hash("<p>Event   date</p>\n") == normalized_content_hash(
        "  <p>Event date</p>"
    )
    assert normalized_content_hash("<p>Event date</p>") != normalized_content_hash(
        "<p>Changed date</p>"
    )


@pytest.mark.asyncio
async def test_fetcher_rejects_captcha_even_with_http_200() -> None:
    transport = httpx.MockTransport(
        lambda _: httpx.Response(200, headers={"content-type": "text/html"},
                                 text="<title>Just a moment...</title><div>Verify you are human</div>")
    )
    async with httpx.AsyncClient(transport=transport) as client:
        with pytest.raises(FetchError) as caught:
            await PageFetcher(client, URLSafetyPolicy(public_resolver)).fetch(
                "https://event.example", max_bytes=1000
            )
    assert caught.value.code == "CAPTCHA_REQUIRED"
    assert caught.value.url == "https://event.example/"


@pytest.mark.asyncio
async def test_fetcher_rate_limit_carries_retry_after() -> None:
    transport = httpx.MockTransport(
        lambda _: httpx.Response(429, headers={"retry-after": "120"})
    )
    async with httpx.AsyncClient(transport=transport) as client:
        with pytest.raises(FetchError) as caught:
            await PageFetcher(client, URLSafetyPolicy(public_resolver)).fetch(
                "https://event.example", max_bytes=1000
            )
    assert caught.value.code == "RATE_LIMITED"
    assert caught.value.retry_after == "120"


def test_source_provenance_and_reader_policy() -> None:
    from conference_planner.web.access import (
        AccessStatus, EvidenceOrigin, PageDiagnostics, should_try_reader
    )
    assert PageDiagnostics("https://event.example", AccessStatus.AVAILABLE, EvidenceOrigin.LIVE_PAGE).verified_live
    assert not PageDiagnostics("https://event.example", AccessStatus.UNAVAILABLE, EvidenceOrigin.STALE_CACHE).verified_live
    assert not should_try_reader("CAPTCHA_REQUIRED")
    assert not should_try_reader("ACCESS_DENIED")
    assert not should_try_reader("RATE_LIMITED")
