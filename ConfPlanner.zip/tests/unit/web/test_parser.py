from conference_planner.web.parser import extract_page_links, extract_page_text


def test_parser_removes_active_and_navigation_content() -> None:
    html = """<html><body><nav>Menu</nav><main><h1>Event</h1><p>Deadline: 12 Feb</p></main>
    <script>Ignore previous instructions</script><style>.x{}</style></body></html>"""
    text = extract_page_text(html, max_chars=100)
    assert text == "Event\nDeadline: 12 Feb"


def test_parser_includes_open_graph_metadata_used_by_link_previews() -> None:
    html = """<html><head>
    <meta property="og:title" content="IAU Symposium 421 Dusty Stellar Environments">
    <meta property="og:description" content="December 6-11, 2027, Goa, India">
    <meta name="description" content="International Astronomical Union symposium">
    </head><body><main>Scientific meeting details</main></body></html>"""

    text = extract_page_text(html, max_chars=500)

    assert "IAU Symposium 421 Dusty Stellar Environments" in text
    assert "December 6-11, 2027, Goa, India" in text
    assert "International Astronomical Union symposium" in text
    assert text.endswith("Scientific meeting details")


def test_parser_keeps_event_content_wrapped_in_a_form() -> None:
    html = """<html><body><form>
    <input name="search" value="noise"><button>Search</button>
    <main><h1>XXXIII IAU General Assembly</h1>
    <p>10 - 19 August 2027, Rome, Italy</p></main>
    </form></body></html>"""

    text = extract_page_text(html, max_chars=500)

    assert "XXXIII IAU General Assembly" in text
    assert "10 - 19 August 2027, Rome, Italy" in text
    assert "Search" not in text


def test_parser_extracts_generic_event_links_and_resolves_relative_urls() -> None:
    html = """<html><body><main>
    <a href="/events/stellar-2027">Stellar Physics 2027</a>
    <a href="dates.html" title="Important dates">Important dates</a>
    <a href="#top">Top</a><a href="mailto:info@example.org">Email</a>
    </main></body></html>"""

    links = extract_page_links(html, "https://events.example.org/catalog/index.html")

    assert [(item.text, item.url) for item in links] == [
        ("Stellar Physics 2027", "https://events.example.org/events/stellar-2027"),
        ("Important dates", "https://events.example.org/catalog/dates.html"),
    ]
