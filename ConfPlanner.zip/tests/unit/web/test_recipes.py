import pytest

from conference_planner.schemas.parser_recipes import PageKind, ParserRecipe
from conference_planner.web.recipes import RecipeValidationError, apply_recipe, validate_recipe


def detail_recipe(**overrides) -> ParserRecipe:
    values = {
        "domain": "events.example",
        "page_kind": PageKind.DETAIL,
        "field_selectors": {
            "name": "main h1",
            "event_dates": ".event-dates",
            "deadlines": ".deadline",
        },
        "link_labels": ("important dates", "registration"),
        "regex_patterns": {"year": r"\b20\d{2}\b"},
    }
    values.update(overrides)
    return ParserRecipe.model_validate(values)


def test_recipe_extracts_detail_fields_and_labeled_links_without_network() -> None:
    html = """
    <main>
      <h1>Stellar Physics 2027</h1>
      <p class="event-dates">12–16 July 2027</p>
      <p class="deadline">Abstracts close January 2027</p>
      <a href="/dates">Important dates</a>
      <a href="/news">News</a>
    </main>
    """

    result = apply_recipe(detail_recipe(), html, "https://events.example/meeting")

    assert result.fields["name"] == ("Stellar Physics 2027",)
    assert result.fields["event_dates"] == ("12–16 July 2027",)
    assert result.regex_matches["year"] == ("2027",)
    assert [(item.text, item.url) for item in result.links] == [
        ("Important dates", "https://events.example/dates")
    ]


def test_recipe_extracts_each_catalog_card_in_document_order() -> None:
    recipe = ParserRecipe(
        domain="iau.example",
        page_kind=PageKind.CATALOG,
        card_selector="article.meeting",
        field_selectors={"name": "h2", "event_dates": ".date"},
        link_labels=("details",),
    )
    html = """
    <article class="meeting"><h2>Meeting A</h2><span class="date">May 2027</span>
      <a href="/a">Details</a></article>
    <article class="meeting"><h2>Meeting B</h2><span class="date">June 2027</span>
      <a href="/b">Details</a></article>
    """

    result = apply_recipe(recipe, html, "https://iau.example/future")

    assert [item.fields["name"] for item in result.cards] == [
        ("Meeting A",),
        ("Meeting B",),
    ]
    assert [item.links[0].url for item in result.cards] == [
        "https://iau.example/a",
        "https://iau.example/b",
    ]


@pytest.mark.parametrize(
    "recipe",
    [
        detail_recipe(field_selectors={"unknown": "h1"}),
        detail_recipe(field_selectors={"name": "script"}),
        detail_recipe(field_selectors={"name": "a:has(img)"}),
        detail_recipe(regex_patterns={"bad": r"(a+)+$"}),
        detail_recipe(regex_patterns={"bad": r"(?=secret).*"}),
    ],
)
def test_recipe_rejects_unknown_fields_code_like_selectors_and_expensive_regex(
    recipe: ParserRecipe,
) -> None:
    with pytest.raises(RecipeValidationError):
        validate_recipe(recipe)


def test_recipe_rejects_invalid_css_before_execution() -> None:
    recipe = detail_recipe(field_selectors={"name": "main["})

    with pytest.raises(RecipeValidationError):
        apply_recipe(recipe, "<main>Event</main>", "https://events.example/")
