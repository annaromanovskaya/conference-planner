import httpx
import pytest

from conference_planner.web.reader import JinaPageReader, ReaderError


@pytest.mark.asyncio
async def test_jina_reader_returns_text_for_original_public_url() -> None:
    requests: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(
            200,
            headers={"content-type": "text/plain; charset=utf-8"},
            text="January 2027: oral abstract submission closes",
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        text = await JinaPageReader(client).read(
            "https://meetings.iac.es/imbase2027/pages/important-dates.php",
            max_bytes=10_000,
        )

    assert text == "January 2027: oral abstract submission closes"
    assert str(requests[0].url) == (
        "https://r.jina.ai/https://meetings.iac.es/imbase2027/pages/important-dates.php"
    )


@pytest.mark.asyncio
async def test_jina_reader_rejects_non_text_response() -> None:
    transport = httpx.MockTransport(
        lambda _request: httpx.Response(
            200, headers={"content-type": "application/octet-stream"}, content=b"data"
        )
    )
    async with httpx.AsyncClient(transport=transport) as client:
        with pytest.raises(ReaderError, match="not text"):
            await JinaPageReader(client).read("https://example.org/event", max_bytes=10_000)
