from conference_planner.conferences.evidence import (
    EvidenceDocument,
    EvidenceValidator,
    VerificationContext,
    verification_required,
)
from conference_planner.schemas.common import ArtifactValidationState
from conference_planner.schemas.research import ConferenceResearch, DeadlineClaim, FactClaim


def fact(**overrides) -> FactClaim:
    values = {
        "kind": "start_date",
        "value": "2027-07-12",
        "source_url": "https://event.example/dates",
        "source_class": "OFFICIAL_CONFERENCE",
        "excerpt": "The meeting takes place July 12-16, 2027.",
        "verification_status": "OFFICIAL_CONFIRMED",
    }
    values.update(overrides)
    return FactClaim.model_validate(values)


def deadline(**overrides) -> DeadlineClaim:
    values = {
        "deadline_type": "ABSTRACT_SUBMISSION",
        "exact_date": "2027-01-31",
        "source_url": "https://event.example/dates",
        "source_class": "OFFICIAL_CONFERENCE",
        "excerpt": "Abstract submission closes January 31, 2027.",
        "verification_status": "OFFICIAL_CONFIRMED",
    }
    values.update(overrides)
    return DeadlineClaim.model_validate(values)


def research(*, facts=(), deadlines=()) -> ConferenceResearch:
    return ConferenceResearch(
        name="Stellar Meeting 2027",
        source_url="https://event.example/dates",
        source_class="OFFICIAL_CONFERENCE",
        facts=facts,
        deadlines=deadlines,
    )


def test_validator_accepts_exact_quotes_and_official_deterministic_dates() -> None:
    claim = fact()
    document = EvidenceDocument(
        url="https://event.example/dates",
        text="Important dates. The meeting takes place July 12-16, 2027.",
    )

    report = EvidenceValidator().validate(research(facts=(claim,)), (document,))

    assert report.results[0].state == ArtifactValidationState.ACCEPTED
    assert report.validated.facts == (claim,)
    assert verification_required(
        claim,
        VerificationContext(excerpt_found=True, deterministic_date=True),
    ) is False


def test_validator_rejects_claim_when_quote_is_not_in_the_cited_document() -> None:
    report = EvidenceValidator().validate(
        research(facts=(fact(excerpt="Invented date"),)),
        (
            EvidenceDocument(
                url="https://event.example/dates",
                text="The meeting takes place July 12-16, 2027.",
            ),
        ),
    )

    assert report.results[0].state == ArtifactValidationState.REJECTED
    assert report.results[0].reason == "EXCERPT_NOT_FOUND"
    assert report.validated.facts == ()


def test_validator_rejects_event_start_mislabeled_as_deadline() -> None:
    claim = deadline(
        deadline_type="OTHER",
        exact_date="2027-07-12",
        excerpt="The conference starts July 12, 2027.",
    )
    document = EvidenceDocument(
        url="https://event.example/dates",
        text="The conference starts July 12, 2027.",
    )

    report = EvidenceValidator().validate(research(deadlines=(claim,)), (document,))

    assert report.results[0].state == ArtifactValidationState.REJECTED
    assert report.results[0].reason == "EVENT_DATE_IS_NOT_DEADLINE"


def test_validator_keeps_approximate_month_tentative_without_inventing_day() -> None:
    claim = deadline(
        exact_date=None,
        approximate_year=2027,
        approximate_month=5,
        tentative=True,
        excerpt="May 2027: registration and payment deadline (tentative).",
    )
    document = EvidenceDocument(
        url="https://event.example/dates",
        text="May 2027: registration and payment deadline (tentative).",
    )

    report = EvidenceValidator().validate(research(deadlines=(claim,)), (document,))

    assert report.results[0].state == ArtifactValidationState.TENTATIVE
    assert report.validated.deadlines[0].exact_date is None
    assert verification_required(
        claim,
        VerificationContext(excerpt_found=True, deterministic_date=True),
    ) is True


def test_validator_preserves_conflict_in_report_but_excludes_it_from_persistence() -> None:
    first = fact()
    second = fact(
        value="2027-07-13",
        excerpt="A second official page says the meeting starts July 13, 2027.",
        verification_status="CONFLICT",
    )
    documents = (
        EvidenceDocument(
            url="https://event.example/dates",
            text=(
                "The meeting takes place July 12-16, 2027. "
                "A second official page says the meeting starts July 13, 2027."
            ),
        ),
    )

    report = EvidenceValidator().validate(
        research(facts=(first, second)),
        documents,
    )

    assert [item.state for item in report.results] == [
        ArtifactValidationState.ACCEPTED,
        ArtifactValidationState.CONFLICT,
    ]
    assert report.validated.facts == (first,)


def test_secondary_and_changed_deadline_require_independent_verifier() -> None:
    secondary = fact(source_class="SECONDARY", verification_status="SECONDARY_UNVERIFIED")
    official_deadline = deadline()

    assert verification_required(
        secondary,
        VerificationContext(excerpt_found=True, deterministic_date=True),
    ) is True
    assert verification_required(
        official_deadline,
        VerificationContext(
            excerpt_found=True,
            deterministic_date=True,
            changes_saved_deadline=True,
        ),
    ) is True
