import pytest

from conference_planner.conferences.research import ConferenceResearchService


class Translator:
    async def translate_search_query(self, query: str) -> str:
        assert query == "астрофизика 2027"
        return "astrophysics conferences Europe 2027 official deadlines"


class EchoTranslator:
    async def translate_search_query(self, query: str) -> str:
        return query


class FailingTranslator:
    async def translate_search_query(self, _query: str) -> str:
        raise RuntimeError("translator unavailable")


class EmptyRetryService(ConferenceResearchService):
    def __init__(
        self,
        diagnostics: tuple[str, ...] = (),
        translator=None,
    ) -> None:
        self.ai = translator or Translator()
        self.application_clock = None
        self.calls: list[tuple[str, int, str | None]] = []
        self.waits: list[float] = []
        self.last_search_new_ids = ()
        self.last_search_duplicate_count = 0
        self.last_search_result_count = 0
        self.last_search_unresponsive_engines = diagnostics

    async def _wait_before_search_retry(self, seconds: float) -> None:
        self.waits.append(seconds)

    async def search(
        self,
        _user_id: int,
        query: str,
        limit: int = 10,
        *,
        page: int = 1,
        search_query: str | None = None,
    ):
        assert limit == 20
        self.calls.append((query, page, search_query))
        return []


@pytest.mark.asyncio
async def test_unavailable_search_uses_alternative_queries_with_backoff() -> None:
    service = EmptyRetryService(("duckduckgo: CAPTCHA",))

    report = await service.search_fresh(
        7,
        "астрофизика 2027",
        page_limit=1,
        results_per_page=20,
    )

    translated = "astrophysics conferences Europe 2027 official deadlines"
    assert service.calls == [
        ("астрофизика 2027", 1, None),
        ("астрофизика 2027", 1, translated),
        ("астрофизика 2027", 2, translated),
    ]
    assert service.waits == [1.0, 2.0]
    assert report.error_code == "SEARCH_UNAVAILABLE"
    assert report.search_attempts == 3
    assert report.unresponsive_engines == ("duckduckgo: CAPTCHA",)


@pytest.mark.asyncio
async def test_empty_search_without_engine_failures_reports_search_empty() -> None:
    service = EmptyRetryService()

    report = await service.search_fresh(
        7,
        "астрофизика 2027",
        page_limit=1,
        results_per_page=20,
    )

    assert report.error_code == "SEARCH_EMPTY"
    assert report.unresponsive_engines == ()


@pytest.mark.asyncio
@pytest.mark.parametrize("translator", [EchoTranslator(), FailingTranslator()])
async def test_english_retry_is_deterministic_when_translator_is_unusable(
    translator,
) -> None:
    service = EmptyRetryService(translator=translator)

    query = await service._english_search_query(
        "Найди конференции по астрохимии и звездообразованию в Европе на 2027 год"
    )

    assert "астрохим" not in query.casefold()
    assert "astrochemistry" in query
    assert "star formation" in query
    assert "Europe" in query
    assert "2027" in query
