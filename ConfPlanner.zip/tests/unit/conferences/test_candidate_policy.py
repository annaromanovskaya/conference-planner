from datetime import date

from conference_planner.conferences.candidate_policy import (
    TopicRelevanceContext,
    evaluate_keyword_relevance,
    is_expired_research,
    research_event_range,
)
from conference_planner.schemas.research import VerifiedConferenceResearch


def _topic() -> TopicRelevanceContext:
    return TopicRelevanceContext(
        name="Звёздная астрофизика и ML",
        description="Спектры звёзд и машинное обучение в астрономии",
        keywords=("звёздная спектроскопия", "machine learning astronomy"),
    )


def _research(*facts: tuple[str, str]) -> VerifiedConferenceResearch:
    return VerifiedConferenceResearch.model_validate(
        {
            "name": "Stellar meeting",
            "source_url": "https://event.example/",
            "source_class": "OFFICIAL_CONFERENCE",
            "facts": [
                {
                    "kind": kind,
                    "value": value,
                    "source_url": "https://event.example/",
                    "source_class": "OFFICIAL_CONFERENCE",
                    "excerpt": value,
                    "verification_status": "OFFICIAL_CONFIRMED",
                }
                for kind, value in facts
            ],
        }
    )


def test_keyword_relevance_normalizes_russian_yo_and_matches_english_phrase() -> None:
    russian = evaluate_keyword_relevance(
        "Звездная спектроскопия высокого разрешения", "", (_topic(),)
    )
    english = evaluate_keyword_relevance(
        "Machine-learning methods", "Astronomy conference", (_topic(),)
    )

    assert russian.score == 1.0
    assert "звёздная спектроскопия" in russian.matched_phrases
    assert english.score > 0
    assert english.explicitly_irrelevant is False


def test_keyword_relevance_keeps_borderline_and_rejects_clear_zero_match() -> None:
    borderline = evaluate_keyword_relevance(
        "Astronomy data methods", "New analysis workshop", (_topic(),)
    )
    unrelated = evaluate_keyword_relevance(
        "Marine biology symposium", "Ocean ecology and fisheries", (_topic(),)
    )

    assert 0 < borderline.score < 1
    assert borderline.explicitly_irrelevant is False
    assert unrelated.score == 0
    assert unrelated.explicitly_irrelevant is True


def test_event_range_and_expiration_use_end_then_single_start_date() -> None:
    ranged = _research(("start_date", "2026-10-10"), ("end_date", "2026-10-20"))
    ended = _research(("start_date", "2026-10-10"), ("end_date", "2026-10-18"))
    started_without_end = _research(("start_date", "2026-10-18"))
    unknown = _research()

    assert research_event_range(ranged) == (date(2026, 10, 10), date(2026, 10, 20))
    assert is_expired_research(ranged, date(2026, 10, 19)) is False
    assert is_expired_research(ended, date(2026, 10, 19)) is True
    assert is_expired_research(started_without_end, date(2026, 10, 19)) is True
    assert is_expired_research(unknown, date(2026, 10, 19)) is False
