from conference_planner.conferences import temporal
from conference_planner.conferences.temporal import (
    extract_catalog_link_events,
    extract_temporal_research,
)
from conference_planner.schemas.common import DeadlineType, VerificationStatus
from conference_planner.schemas.research import ConferenceCatalogResearch
from conference_planner.web.parser import PageLink

SOURCE_URL = "https://example.org/event"


def test_extracts_english_event_date_range_with_exact_evidence() -> None:
    research = extract_temporal_research(
        SOURCE_URL,
        "XXXIII IAU General Assembly\n10 - 19 August 2027, Rome, Italy",
        "XXXIII IAU General Assembly",
    )

    assert [(item.kind, item.value) for item in research.facts] == [
        ("start_date", "2027-08-10"),
        ("end_date", "2027-08-19"),
    ]
    assert all(item.excerpt == "10 - 19 August 2027, Rome, Italy" for item in research.facts)


def test_extracts_russian_event_date_range() -> None:
    research = extract_temporal_research(
        SOURCE_URL,
        "Конференция «Звёздная астрономия» состоится 3-5 ноября 2026 г. в Ташкенте.",
        "Звёздная астрономия",
    )

    assert [(item.kind, item.value) for item in research.facts] == [
        ("start_date", "2026-11-03"),
        ("end_date", "2026-11-05"),
    ]


def test_extracts_month_only_deadlines_and_tentative_start() -> None:
    research = extract_temporal_research(
        SOURCE_URL,
        """Important dates
November 2026: Registration and abstract submission opens
January 2027: Abstract submission for oral contributions closes
March 2027: Notification of acceptance of oral contributions
May 2027: Deadline for registration, poster contributions, and payment
12th of July 2027: ImBaSE2027 starts
(These dates, aside from the conference week, are tentative)""",
        "ImBaSE 2027",
    )

    assert [(item.kind, item.value) for item in research.facts] == [("start_date", "2027-07-12")]
    assert [item.deadline_type for item in research.deadlines] == [
        DeadlineType.REGISTRATION_OPEN,
        DeadlineType.ORAL_ABSTRACT_SUBMISSION,
        DeadlineType.ACCEPTANCE_NOTIFICATION,
        DeadlineType.REGISTRATION,
    ]
    assert [(item.approximate_year, item.approximate_month) for item in research.deadlines] == [
        (2026, 11),
        (2027, 1),
        (2027, 3),
        (2027, 5),
    ]
    assert all(item.tentative for item in research.deadlines)
    assert all(
        item.verification_status == VerificationStatus.TENTATIVE for item in research.deadlines
    )


def test_catalog_links_create_distinct_events_without_model_output() -> None:
    source_url = "https://www.eso.org/sci/meetings/2027.html"
    catalog = extract_catalog_link_events(
        source_url,
        "ESO Meetings 2027",
        (
            PageLink("Conferences 2027", source_url),
            PageLink(
                "Probing the cosmos with white dwarf binaries",
                "https://www.eso.org/sci/meetings/2027/whitedwarfbinaries.html",
            ),
            PageLink(
                "When galaxies meet",
                "https://www.eso.org/sci/meetings/2027/galmeet.html",
            ),
            PageLink("Privacy", "https://www.eso.org/public/privacy/"),
        ),
    )

    assert [item.name for item in catalog.events] == [
        "Probing the cosmos with white dwarf binaries",
        "When galaxies meet",
    ]
    assert [str(item.source_url) for item in catalog.events] == [
        "https://www.eso.org/sci/meetings/2027/whitedwarfbinaries.html",
        "https://www.eso.org/sci/meetings/2027/galmeet.html",
    ]


def test_catalog_without_year_uses_current_and_future_event_links() -> None:
    source_url = "https://www.sai.msu.ru/conference/annconf/index.html"
    catalog = extract_catalog_link_events(
        source_url,
        "Объявления о конференциях - ГАИШ - МГУ",
        (
            PageLink("Новости", "https://www.sai.msu.ru/news/index.html"),
            PageLink(
                "http://www.inasan.ru/scientific_activities/conferences/"
                "modern_stellar_astronomy_2026/",
                "http://www.inasan.ru/scientific_activities/conferences/"
                "modern_stellar_astronomy_2026/",
            ),
            PageLink(
                "dez2025.pdf",
                "https://www.sai.msu.ru/conference/annconf/dez2025.pdf",
            ),
            PageLink(
                "https://forms.yandex.ru/cloud/2026-registration/",
                "https://forms.yandex.ru/cloud/2026-registration/",
            ),
        ),
        min_year=2026,
    )

    assert [item.name for item in catalog.events] == ["modern stellar astronomy 2026"]
    assert str(catalog.events[0].source_url) == (
        "http://www.inasan.ru/scientific_activities/conferences/modern_stellar_astronomy_2026/"
    )


def test_enriches_each_catalog_event_from_its_own_block() -> None:
    source_url = "https://www.sai.msu.ru/conference/annconf/index.html"
    official_url = "https://indico.icranet.org/event/11/"
    ayss_url = "https://indico.jinr.ru/event/5891/"
    catalog = ConferenceCatalogResearch.model_validate(
        {
            "events": [
                {
                    "name": "Sixth Zeldovich meeting",
                    "source_url": source_url,
                    "source_class": "SECONDARY",
                    "facts": [],
                    "deadlines": [
                        {
                            "deadline_type": "OTHER",
                            "exact_date": "2026-04-30",
                            "source_url": source_url,
                            "source_class": "SECONDARY",
                            "excerpt": "early bird regular fee: 300 Euros (up to April 30, 2026)",
                            "verification_status": "SECONDARY_UNVERIFIED",
                        },
                        {
                            "deadline_type": "OTHER",
                            "exact_date": "2026-06-15",
                            "source_url": source_url,
                            "source_class": "SECONDARY",
                            "excerpt": "Abstract submission deadline: June 15, 2026",
                            "verification_status": "SECONDARY_UNVERIFIED",
                        },
                    ],
                },
                {
                    "name": "30-я Международная научная конференция молодых ученых и специалистов",
                    "source_url": source_url,
                    "source_class": "SECONDARY",
                    "facts": [],
                    "deadlines": [],
                },
            ]
        }
    )
    text = """Sixth Zeldovich meeting (Pescara, Italy, July 13-17, 2026)
The conference will be held in Pescara, Italy, on July 13-17, 2026.
early bird regular fee: 300 Euros (up to April 30, 2026)
Abstract submission deadline: June 15, 2026
All information is posted on the official website:
https://indico.icranet.org/event/11/
30-я Международная научная конференция молодых ученых и специалистов
Мероприятие будет проходить в г. Ташкенте, Республика Узбекистан,
с 17 по 21 октября 2026 года.
Регистрация и прием аннотаций докладов осуществляется до 8 мая 2026 года.
Подача работ для публикации материалов конференции — до 1 ноября 2026 года.
Более подробная информация на сайте: https://indico.jinr.ru/event/5891/."""

    enriched = temporal.enrich_catalog_events(
        catalog,
        source_url,
        text,
        (
            PageLink(official_url, official_url),
            PageLink(ayss_url, ayss_url),
        ),
    )

    sixth, ayss = enriched.events
    assert [(item.kind, item.value) for item in sixth.facts] == [
        ("start_date", "2026-07-13"),
        ("end_date", "2026-07-17"),
        ("location", "Pescara, Italy"),
        ("official_url", official_url),
    ]
    assert [item.deadline_type for item in sixth.deadlines] == [
        DeadlineType.EARLY_REGISTRATION,
        DeadlineType.ABSTRACT_SUBMISSION,
    ]
    assert str(sixth.source_url) == official_url
    assert [(item.kind, item.value) for item in ayss.facts] == [
        ("start_date", "2026-10-17"),
        ("end_date", "2026-10-21"),
        ("location", "Ташкенте, Республика Узбекистан"),
        ("official_url", ayss_url),
    ]
    assert [item.deadline_type for item in ayss.deadlines] == [
        DeadlineType.REGISTRATION,
        DeadlineType.ABSTRACT_SUBMISSION,
        DeadlineType.OTHER,
    ]
    assert str(ayss.source_url) == ayss_url
