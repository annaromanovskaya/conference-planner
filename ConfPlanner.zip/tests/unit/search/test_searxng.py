import httpx
import pytest

from conference_planner.search.searxng import SearchProviderError, SearXNGSearchProvider


@pytest.mark.asyncio
async def test_searxng_normalizes_results() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.params["q"] == "stars 2027 conference"
        assert request.url.params["pageno"] == "3"
        return httpx.Response(
            200,
            json={
                "results": [
                    {
                        "title": "Stars 2027",
                        "url": "https://event.example/",
                        "content": "Scientific meeting",
                        "engine": "duckduckgo",
                    }
                ]
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        provider = SearXNGSearchProvider("http://searxng:8080", client)
        results = await provider.search("stars 2027 conference", page=3)

    assert results[0].title == "Stars 2027"
    assert str(results[0].url) == "https://event.example/"


@pytest.mark.asyncio
async def test_searxng_search_page_returns_safe_engine_diagnostics() -> None:
    transport = httpx.MockTransport(
        lambda _: httpx.Response(
            200,
            json={
                "results": [],
                "unresponsive_engines": [
                    ["duckduckgo", "CAPTCHA"],
                    ["brave", "Too many request"],
                    ["invalid"],
                    {"private": "details"},
                ],
            },
        )
    )
    async with httpx.AsyncClient(transport=transport) as client:
        page = await SearXNGSearchProvider(
            "http://searxng:8080", client
        ).search_page("query")

    assert page.results == ()
    assert page.unresponsive_engines == (
        "duckduckgo: CAPTCHA",
        "brave: Too many request",
    )


@pytest.mark.asyncio
async def test_searxng_rejects_malformed_response() -> None:
    transport = httpx.MockTransport(lambda _: httpx.Response(200, json={"results": "bad"}))
    async with httpx.AsyncClient(transport=transport) as client:
        with pytest.raises(SearchProviderError):
            await SearXNGSearchProvider("http://searxng:8080", client).search("query")
