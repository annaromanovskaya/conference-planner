from pathlib import Path

import yaml


def test_searxng_enables_independent_general_search_engines() -> None:
    project_root = Path(__file__).resolve().parents[3]
    settings = yaml.safe_load(
        (project_root / "deploy/searxng/settings.yml").read_text(encoding="utf-8")
    )

    enabled = {
        engine["name"]
        for engine in settings.get("engines", [])
        if engine.get("disabled") is False
    }

    assert {"bing", "google", "qwant", "startpage"} <= enabled
