from datetime import UTC, date, datetime
from zoneinfo import ZoneInfo

from conference_planner.runtime_clock import ApplicationClock


def test_application_clock_uses_local_date_across_utc_day_boundary() -> None:
    instant = datetime(2026, 10, 18, 21, 30, tzinfo=UTC)
    clock = ApplicationClock.start(
        ZoneInfo("Europe/Moscow"),
        now_provider=lambda: instant,
    )

    assert clock.started_at == datetime(
        2026, 10, 19, 0, 30, tzinfo=ZoneInfo("Europe/Moscow")
    )
    assert clock.now() == clock.started_at
    assert clock.today() == date(2026, 10, 19)
