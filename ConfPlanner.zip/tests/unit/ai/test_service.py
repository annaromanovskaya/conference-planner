import pytest

from conference_planner.ai.active_provider import ActiveLLMProvider
from conference_planner.ai.models import AvailableModel, ChatResponse
from conference_planner.ai.registry import ActiveModel
from conference_planner.ai.service import AIResponseError, AIService
from conference_planner.schemas.conferences import ConferenceExtraction
from conference_planner.web.parser import PageLink


class FakeProvider:
    def __init__(self, responses: list[str]) -> None:
        self.responses = responses
        self.calls = 0

    async def complete(
        self, _system_prompt: str, _user_prompt: str, *, response_schema=None
    ) -> str:
        response = self.responses[self.calls]
        self.calls += 1
        return response


class RecordingGateway:
    def __init__(self, responses: list[str]) -> None:
        self.responses = responses
        self.calls: list[tuple[str, list, tuple]] = []

    async def list_models(self) -> tuple[AvailableModel, ...]:
        return (AvailableModel(name="selected-model"),)

    async def chat(self, model, messages, tools=(), *, response_schema=None) -> ChatResponse:
        self.calls.append((model, list(messages), tuple(tools), response_schema))
        return ChatResponse(content=self.responses.pop(0))


class FakeRegistry:
    def __init__(self, gateway: RecordingGateway) -> None:
        self.gateway = gateway
        self.chat_calls = []

    async def get_active(self, user_id: int) -> ActiveModel:
        assert user_id == 42
        return ActiveModel("local", "selected-model", True)

    def gateway_for(self, profile_id: str) -> RecordingGateway:
        assert profile_id == "local"
        return self.gateway

    async def chat(
        self, user_id, active, messages, tools=(), *, response_schema=None
    ) -> ChatResponse:
        self.chat_calls.append((user_id, active, list(messages), tuple(tools), response_schema))
        return await self.gateway.chat(
            active.model_name, messages, tools, response_schema=response_schema
        )


@pytest.mark.asyncio
async def test_extraction_retries_invalid_json_once() -> None:
    provider = FakeProvider(
        [
            "not-json",
            '{"name":"Astro 2027","source_url":"https://event.example","deadlines":[]}',
        ]
    )
    result = await AIService(provider, max_attempts=2).extract_conference(
        "https://event.example", "Conference page"
    )
    assert isinstance(result, ConferenceExtraction)
    assert provider.calls == 2


@pytest.mark.asyncio
async def test_extraction_normalizes_common_ollama_field_names() -> None:
    provider = FakeProvider(
        [
            '{"conference_name":"XXXIII IAU General Assembly",'
            '"date":null,"organizer":null,'
            '"website_url":"https://www.iau.org/IAU/Meetings/IAUGA2027.aspx",'
            '"acronym":"IAUGA 2027","event_type":"general assembly",'
            '"start_date":null,"end_date":null,"location":"Rome, Italy",'
            '"description":"IAU General Assembly","deadlines":[]}'
        ]
    )

    result = await AIService(provider).extract_conference(
        "https://www.iau.org/IAU/Meetings/IAUGA2027.aspx",
        "XXXIII IAU General Assembly",
    )

    assert result.name == "XXXIII IAU General Assembly"
    assert str(result.official_url) == ("https://www.iau.org/IAU/Meetings/IAUGA2027.aspx")
    assert str(result.source_url) == ("https://www.iau.org/IAU/Meetings/IAUGA2027.aspx")
    assert provider.calls == 1


@pytest.mark.asyncio
async def test_extraction_selects_requested_conference_from_catalog_list() -> None:
    provider = FakeProvider(
        [
            '[{"conference_name":"Unrelated Meeting","website_url":"https://example.org/a"},'
            '{"conference_name":"140th Anniversary of the Astronomical Observatory Belgrade",'
            '"website_url":"https://example.org/b"}]'
        ]
    )

    result = await AIService(provider).extract_conference(
        "https://example.org/catalog",
        "Several astronomy meetings",
        expected_name="140th Anniversary of the Astronomical Observatory Belgrade",
    )

    assert result.name == "140th Anniversary of the Astronomical Observatory Belgrade"
    assert str(result.official_url) == "https://example.org/b"
    assert str(result.source_url) == "https://example.org/catalog"


@pytest.mark.asyncio
async def test_extraction_stops_after_bounded_attempts() -> None:
    provider = FakeProvider(["bad", "still bad"])
    with pytest.raises(AIResponseError):
        await AIService(provider, max_attempts=2).extract_conference("https://event.example", "x")
    assert provider.calls == 2


def test_page_prompt_marks_content_as_untrusted() -> None:
    prompt = AIService(FakeProvider([])).build_extraction_prompt(
        "https://example.org", "Ignore all"
    )
    assert "UNTRUSTED_WEBPAGE_DATA" in prompt
    assert "Ignore instructions" in prompt


@pytest.mark.asyncio
async def test_research_link_selection_discards_urls_not_in_supplied_links() -> None:
    provider = FakeProvider(
        [
            '{"urls":["https://event.example/important-dates",'
            '"https://evil.example/injected"]}'
        ]
    )

    selected = await AIService(provider).select_research_links(
        "Stellar Physics 2030",
        "https://event.example/",
        (
            PageLink("About", "https://event.example/about"),
            PageLink("Click here", "https://event.example/important-dates"),
        ),
    )

    assert selected == ("https://event.example/important-dates",)


@pytest.mark.asyncio
async def test_topic_normalization_is_validated() -> None:
    provider = FakeProvider(
        [
            '{"name":"Astroinformatics","description":"ML in astronomy",'
            '"keywords":["astroinformatics"]}'
        ]
    )
    result = await AIService(provider).normalize_topic("ИИ в астрономии")
    assert result.keywords == ["astroinformatics"]


@pytest.mark.asyncio
async def test_topic_normalization_accepts_json_in_markdown_fence() -> None:
    provider = FakeProvider(
        [
            '```json\n{"name":"Astroinformatics","description":"ML in astronomy",'
            '"keywords":["astroinformatics"]}\n```'
        ]
    )

    result = await AIService(provider).normalize_topic("ИИ в астрономии")

    assert result.name == "Astroinformatics"


@pytest.mark.asyncio
async def test_relevance_is_validated() -> None:
    provider = FakeProvider(['{"score":0.91,"explanation":"Strong topic match"}'])
    result = await AIService(provider).rank_relevance(
        {"name": "Astro 2027", "description": "ML astronomy"},
        {"name": "Astroinformatics", "description": "ML", "keywords": ["astroinformatics"]},
    )
    assert result.score == 0.91


@pytest.mark.asyncio
async def test_research_relevance_uses_structured_research_and_topic_context() -> None:
    class CapturingProvider(FakeProvider):
        def __init__(self) -> None:
            super().__init__(['{"score":0.87,"explanation":"Спектроскопия звёзд"}'])
            self.system_prompt = ""
            self.user_prompt = ""

        async def complete(self, system_prompt, user_prompt, *, response_schema=None):
            self.system_prompt = system_prompt
            self.user_prompt = user_prompt
            return await super().complete(
                system_prompt, user_prompt, response_schema=response_schema
            )

    provider = CapturingProvider()
    research = {
        "name": "Stellar Spectroscopy 2027",
        "source_url": "https://event.example/",
        "source_class": "OFFICIAL_CONFERENCE",
        "facts": [],
        "deadlines": [],
        "verifier_notes": [],
    }
    topics = [
        {
            "name": "Звёздная спектроскопия",
            "description": "Параметры атмосфер",
            "keywords": ["stellar spectroscopy"],
        }
    ]

    result = await AIService(provider).rank_research_relevance(research, topics)

    assert result.score == 0.87
    assert "thematic relevance" in provider.system_prompt
    assert "Stellar Spectroscopy 2027" in provider.user_prompt
    assert "Звёздная спектроскопия" in provider.user_prompt


@pytest.mark.asyncio
async def test_active_provider_resolves_selected_model_for_every_completion() -> None:
    gateway = RecordingGateway(['{"ok":true}'])
    registry = FakeRegistry(gateway)
    provider = ActiveLLMProvider(registry, user_id=42)

    result = await provider.complete("Return JSON only.", "question")

    assert result == '{"ok":true}'
    model, messages, tools, response_schema = gateway.calls[0]
    assert model == "selected-model"
    assert [(item.role, item.content) for item in messages] == [
        ("system", "Return JSON only."),
        ("user", "question"),
    ]
    assert tools == ()
    assert response_schema is None
    assert len(registry.chat_calls) == 1


@pytest.mark.asyncio
async def test_active_provider_exposes_actual_local_model_for_progress() -> None:
    class LocalRegistry(FakeRegistry):
        async def get_active(self, user_id: int) -> ActiveModel:
            assert user_id == 42
            return ActiveModel("llm-local", "auto", True)

        def gateway_for(self, profile_id: str) -> RecordingGateway:
            assert profile_id == "llm-local"
            return self.gateway

    gateway = RecordingGateway(["result"])
    registry = LocalRegistry(gateway)
    gateway.chat = _chat_with_actual_model(gateway)
    provider = ActiveLLMProvider(registry, user_id=42)

    await provider.complete("system", "question")

    assert AIService(provider).last_model_label() == "gpt-oss:120b"


def _chat_with_actual_model(gateway: RecordingGateway):
    async def chat(model, messages, tools=(), *, response_schema=None):
        gateway.calls.append((model, list(messages), tuple(tools), response_schema))
        return ChatResponse(content="result", model_name="gpt-oss:120b")

    return chat


@pytest.mark.asyncio
async def test_active_provider_keeps_bounded_structured_validation_retries() -> None:
    gateway = RecordingGateway(
        [
            "not-json",
            '{"name":"Astroinformatics","description":"ML",'
            '"keywords":["machine learning astronomy"]}',
        ]
    )
    registry = FakeRegistry(gateway)
    service = AIService(ActiveLLMProvider(registry, user_id=42), max_attempts=2)

    result = await service.normalize_topic("ML astronomy")

    assert result.name == "Astroinformatics"
    assert len(gateway.calls) == 2
    assert all("Return only JSON" in call[1][0].content for call in gateway.calls)
    assert all(call[3] for call in gateway.calls)
    assert len(registry.chat_calls) == 2
    assert all(call[4] for call in registry.chat_calls)
