import logging
from collections.abc import Sequence
from datetime import UTC, date, datetime
from typing import Any

import httpx
import pytest
from pydantic import SecretStr
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from conference_planner.ai.gateway import ModelGateway, ModelGatewayError
from conference_planner.ai.models import (
    AvailableModel,
    ChatMessage,
    ChatResponse,
    ToolCall,
    ToolDefinition,
)
from conference_planner.ai.registry import (
    ActiveModel,
    ModelRegistry,
    ModelSelectionRequired,
    UnknownModel,
    build_provider_profiles,
)
from conference_planner.config import Settings
from conference_planner.db.models import Topic
from conference_planner.db.repositories.agent_state import AgentStateRepository
from conference_planner.db.repositories.ollama_usage import OllamaUsageRepository
from conference_planner.db.repositories.users import UserRepository
from conference_planner.schemas.common import ModelRole, ProviderUsageStatus


class FakeGateway(ModelGateway):
    def __init__(
        self,
        names: Sequence[str],
        *,
        probe_response: ChatResponse | None = None,
        error: ModelGatewayError | None = None,
    ) -> None:
        self.names = names
        self.probe_response = probe_response or ChatResponse(content="chat only")
        self.error = error
        self.chat_models: list[str] = []
        self.response_schemas: list[dict[str, Any] | None] = []

    async def list_models(self) -> Sequence[AvailableModel]:
        return tuple(AvailableModel(name=name) for name in self.names)

    async def chat(
        self,
        model: str,
        messages: Sequence[ChatMessage],
        tools: Sequence[ToolDefinition] = (),
        *,
        response_schema: dict[str, Any] | None = None,
    ) -> ChatResponse:
        self.chat_models.append(model)
        self.response_schemas.append(response_schema)
        if self.error is not None:
            raise self.error
        return self.probe_response


async def _owner_id(session: AsyncSession) -> int:
    owner = await UserRepository(session).get_or_create_by_telegram_id(123)
    await session.flush()
    return owner.id


@pytest.mark.asyncio
async def test_build_profiles_includes_only_configured_services() -> None:
    settings = Settings(
        _env_file=None,
        telegram_bot_token="token",
        owner_telegram_id=123,
        ollama_cloud_api_key=SecretStr("cloud-key"),
        llm_local_base_url="http://models.internal:1337/v1",
        llm_local_api_key=SecretStr("local-key"),
    )
    async with httpx.AsyncClient() as client:
        profiles = build_provider_profiles(settings, client)

    assert [profile.id for profile in profiles] == ["ollama-cloud", "llm-local"]
    assert [profile.display_name for profile in profiles] == ["Ollama Cloud", "Local LLM API"]
    assert profiles[0].allowed_models == settings.ollama_cloud_free_models
    assert profiles[1].allowed_models is None


@pytest.mark.asyncio
async def test_cloud_models_are_filtered_in_allowlist_order(session: AsyncSession) -> None:
    gateway = FakeGateway(["other", "gemma4:31b", "gpt-oss:20b"])
    registry = ModelRegistry.for_testing(
        AgentStateRepository(session),
        cloud_gateway=gateway,
        cloud_allowlist=("gpt-oss:20b", "missing", "gemma4:31b"),
    )

    models = await registry.list_models("ollama-cloud")

    assert [model.name for model in models] == ["gpt-oss:20b", "gemma4:31b"]


@pytest.mark.asyncio
async def test_local_llm_models_are_not_filtered(session: AsyncSession) -> None:
    registry = ModelRegistry.for_testing(
        AgentStateRepository(session), llm_local_gateway=FakeGateway(["qwen3", "private-model"])
    )

    models = await registry.list_models("llm-local")

    assert [model.name for model in models] == ["qwen3", "private-model"]


@pytest.mark.asyncio
async def test_selection_rejects_stale_model_and_persists_valid_choice(
    session: AsyncSession,
) -> None:
    owner_id = await _owner_id(session)
    registry = ModelRegistry.for_testing(
        AgentStateRepository(session), llm_local_gateway=FakeGateway(["qwen3"])
    )

    with pytest.raises(UnknownModel):
        await registry.select(owner_id, "llm-local", "removed-model")

    selected = await registry.select(owner_id, "llm-local", "qwen3")
    await session.commit()
    active = await registry.get_active(owner_id)
    assert selected.profile_id == "llm-local"
    assert active.profile_id == "llm-local"
    assert active.model_name == "qwen3"


@pytest.mark.asyncio
async def test_missing_selection_has_explicit_error(session: AsyncSession) -> None:
    owner_id = await _owner_id(session)
    registry = ModelRegistry.for_testing(
        AgentStateRepository(session), llm_local_gateway=FakeGateway(["qwen3"])
    )

    with pytest.raises(ModelSelectionRequired) as captured:
        await registry.get_active(owner_id)

    assert captured.value.code == "selection_required"


@pytest.mark.asyncio
async def test_role_model_override_uses_same_profile_and_active_model_is_default(
    session: AsyncSession,
) -> None:
    owner_id = await _owner_id(session)
    registry = ModelRegistry.for_testing(
        AgentStateRepository(session),
        llm_local_gateway=FakeGateway(["default-model", "research-model"]),
        role_models={ModelRole.RESEARCH: "research-model"},
    )
    await registry.select(owner_id, "llm-local", "default-model")

    assert (await registry.get_for_role(owner_id, ModelRole.SUPERVISOR)).model_name == (
        "default-model"
    )
    assert (await registry.get_for_role(owner_id, ModelRole.RESEARCH)).model_name == (
        "research-model"
    )


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("response", "expected"),
    [
        (
            ChatResponse(
                tool_calls=(ToolCall(name="capability_probe", arguments={"value": "ok"}),)
            ),
            True,
        ),
        (ChatResponse(content="I cannot use tools"), False),
    ],
)
async def test_capability_probe_is_persisted(
    session: AsyncSession, response: ChatResponse, expected: bool
) -> None:
    owner_id = await _owner_id(session)
    repository = AgentStateRepository(session)
    gateway = FakeGateway(["qwen3"], probe_response=response)
    registry = ModelRegistry.for_testing(
        repository, llm_local_gateway=gateway, capability_timeout=1
    )
    await registry.select(owner_id, "llm-local", "qwen3")

    active = await registry.refresh_capability(owner_id)
    stored = await repository.get_capability("llm-local", "qwen3")

    assert active.supports_tools is expected
    assert stored is not None and stored.supports_tools is expected


@pytest.mark.asyncio
async def test_cloud_chat_records_usage(session: AsyncSession) -> None:
    owner_id = await _owner_id(session)
    usage = OllamaUsageRepository(session)
    gateway = FakeGateway(
        ["gemma4:31b"],
        probe_response=ChatResponse(
            content="ok", prompt_tokens=12, cached_prompt_tokens=5, output_tokens=3
        ),
    )
    registry = ModelRegistry.for_testing(
        AgentStateRepository(session),
        usage_repository=usage,
        cloud_gateway=gateway,
        cloud_allowlist=("gemma4:31b",),
    )

    response = await registry.chat(
        owner_id,
        ActiveModel("ollama-cloud", "gemma4:31b", None),
        [ChatMessage(role="user", content="hello")],
    )

    rows = await usage.get_daily_totals(owner_id, "ollama-cloud", datetime.now(UTC).date())
    assert response.content == "ok"
    assert len(rows) == 1
    assert rows[0].request_count == 1
    assert rows[0].prompt_tokens == 12
    assert rows[0].cached_prompt_tokens == 5
    assert rows[0].output_tokens == 3


@pytest.mark.asyncio
async def test_non_cloud_chat_is_not_recorded(session: AsyncSession) -> None:
    owner_id = await _owner_id(session)
    usage = OllamaUsageRepository(session)
    registry = ModelRegistry.for_testing(
        AgentStateRepository(session),
        usage_repository=usage,
        llm_local_gateway=FakeGateway(["qwen3"]),
    )

    await registry.chat(
        owner_id,
        ActiveModel("llm-local", "qwen3", None),
        [ChatMessage(role="user", content="hello")],
    )

    assert await usage.get_daily_totals(owner_id, "ollama-cloud", date.today()) == ()
    assert await usage.get_status(owner_id, "ollama-cloud") is None


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("error_code", "expected_status"),
    [
        ("authentication", ProviderUsageStatus.AUTH_ERROR),
        ("rate_limited", ProviderUsageStatus.RATE_LIMITED),
        ("free_exhausted", ProviderUsageStatus.FREE_EXHAUSTED),
        ("upstream_error", ProviderUsageStatus.UNKNOWN),
    ],
)
async def test_cloud_chat_records_status_and_reraises_gateway_error(
    session: AsyncSession,
    error_code: str,
    expected_status: ProviderUsageStatus,
) -> None:
    owner_id = await _owner_id(session)
    usage = OllamaUsageRepository(session)
    original = ModelGatewayError("safe", code=error_code)
    registry = ModelRegistry.for_testing(
        AgentStateRepository(session),
        usage_repository=usage,
        cloud_gateway=FakeGateway(["gemma4:31b"], error=original),
        cloud_allowlist=("gemma4:31b",),
    )

    with pytest.raises(ModelGatewayError) as captured:
        await registry.chat(
            owner_id,
            ActiveModel("ollama-cloud", "gemma4:31b", None),
            [ChatMessage(role="user", content="hello")],
        )

    status = await usage.get_status(owner_id, "ollama-cloud")
    assert captured.value is original
    assert status is not None
    assert status.status is expected_status
    assert status.detail_code == error_code


@pytest.mark.asyncio
async def test_cloud_chat_isolates_usage_recording_failure(
    session: AsyncSession, caplog: pytest.LogCaptureFixture
) -> None:
    registry_logger = logging.getLogger("conference_planner.ai.registry")
    registry_logger.disabled = False
    caplog.set_level(logging.WARNING, logger=registry_logger.name)

    class BrokenUsageRepository:
        async def record_success(self, *_args, **_kwargs) -> None:
            raise RuntimeError("usage database unavailable")

    owner_id = await _owner_id(session)
    topic = Topic(
        user_id=owner_id,
        name="Astro",
        description="Stars",
        keywords=["spectra"],
        enabled=True,
    )
    session.add(topic)
    registry = ModelRegistry.for_testing(
        AgentStateRepository(session),
        usage_repository=BrokenUsageRepository(),
        cloud_gateway=FakeGateway(
            ["gemma4:31b"], probe_response=ChatResponse(content="successful response")
        ),
        cloud_allowlist=("gemma4:31b",),
    )

    response = await registry.chat(
        owner_id,
        ActiveModel("ollama-cloud", "gemma4:31b", None),
        [ChatMessage(role="user", content="hello")],
    )
    await session.flush()

    assert response.content == "successful response"
    assert await session.scalar(select(Topic.name).where(Topic.id == topic.id)) == "Astro"
    assert "usage recording failed" in caplog.text
