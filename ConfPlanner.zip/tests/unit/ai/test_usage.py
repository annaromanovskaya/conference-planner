from collections.abc import Sequence
from datetime import UTC, datetime
from typing import Any

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from conference_planner.ai.gateway import ModelGatewayError
from conference_planner.ai.models import (
    AvailableModel,
    ChatMessage,
    ChatResponse,
    ToolDefinition,
)
from conference_planner.ai.registry import ModelRegistry
from conference_planner.ai.usage import OllamaUsageService
from conference_planner.db.repositories.agent_state import AgentStateRepository
from conference_planner.db.repositories.ollama_usage import OllamaUsageRepository
from conference_planner.db.repositories.users import UserRepository
from conference_planner.schemas.common import ProviderUsageStatus

NOW = datetime(2026, 10, 14, 12, 0, tzinfo=UTC)


class Gateway:
    def __init__(
        self,
        names: Sequence[str],
        *,
        list_error: ModelGatewayError | None = None,
    ) -> None:
        self.names = tuple(names)
        self.list_error = list_error
        self.list_calls = 0

    async def list_models(self) -> Sequence[AvailableModel]:
        self.list_calls += 1
        if self.list_error is not None:
            raise self.list_error
        return tuple(AvailableModel(name=name) for name in self.names)

    async def chat(
        self,
        model: str,
        messages: Sequence[ChatMessage],
        tools: Sequence[ToolDefinition] = (),
        *,
        response_schema: dict[str, Any] | None = None,
    ) -> ChatResponse:
        return ChatResponse(content="ok")


async def _user_id(session: AsyncSession, telegram_id: int = 700) -> int:
    user = await UserRepository(session).get_or_create_by_telegram_id(telegram_id)
    await session.flush()
    return user.id


def _registry(
    session: AsyncSession,
    usage: OllamaUsageRepository,
    cloud: Gateway,
    hub: Gateway | None = None,
) -> ModelRegistry:
    return ModelRegistry.for_testing(
        AgentStateRepository(session),
        usage_repository=usage,
        cloud_gateway=cloud,
        cloud_allowlist=("gemma4:31b", "gpt-oss:20b"),
        llm_local_gateway=hub,
    )


@pytest.mark.asyncio
async def test_snapshot_lists_configured_models_without_claiming_unobserved_balance(
    session: AsyncSession,
) -> None:
    user_id = await _user_id(session)
    usage = OllamaUsageRepository(session)
    registry = _registry(session, usage, Gateway(["gemma4:31b", "gpt-oss:20b"]), Gateway(["qwen3"]))
    await registry.select(user_id, "llm-local", "qwen3")
    service = OllamaUsageService(usage, registry, clock=lambda: NOW)

    snapshot = await service.snapshot(user_id, refresh_models=False)

    assert snapshot.active_profile_id == "llm-local"
    assert snapshot.active_model_name == "qwen3"
    assert snapshot.status is ProviderUsageStatus.UNKNOWN
    assert [item.model_name for item in snapshot.models] == ["gemma4:31b", "gpt-oss:20b"]
    assert all(not item.observed for item in snapshot.models)
    assert all(item.today.request_count == 0 for item in snapshot.models)
    assert all(item.month.request_count == 0 for item in snapshot.models)


@pytest.mark.asyncio
async def test_snapshot_keeps_today_and_calendar_month_totals_per_model(
    session: AsyncSession,
) -> None:
    user_id = await _user_id(session)
    usage = OllamaUsageRepository(session)
    registry = _registry(session, usage, Gateway(["gemma4:31b", "gpt-oss:20b"]))
    await usage.record_success(
        user_id,
        "ollama-cloud",
        "gemma4:31b",
        ChatResponse(prompt_tokens=10, cached_prompt_tokens=4, output_tokens=2),
        datetime(2026, 10, 1, 8, 0, tzinfo=UTC),
    )
    await usage.record_success(
        user_id,
        "ollama-cloud",
        "gemma4:31b",
        ChatResponse(prompt_tokens=20, cached_prompt_tokens=8, output_tokens=3),
        NOW,
    )
    await usage.record_success(
        user_id,
        "ollama-cloud",
        "gpt-oss:20b",
        ChatResponse(prompt_tokens=7, output_tokens=1),
        NOW,
    )
    service = OllamaUsageService(usage, registry, clock=lambda: NOW)

    snapshot = await service.snapshot(user_id, refresh_models=False)
    gemma, gpt = snapshot.models

    assert gemma.today.request_count == 1
    assert gemma.today.prompt_tokens == 20
    assert gemma.month.request_count == 2
    assert gemma.month.prompt_tokens == 30
    assert gemma.month.cached_prompt_tokens == 12
    assert gpt.today.request_count == 1
    assert gpt.month.output_tokens == 1
    assert gemma.observed and gpt.observed


@pytest.mark.asyncio
@pytest.mark.parametrize("status", list(ProviderUsageStatus))
async def test_snapshot_exposes_every_provider_status(
    session: AsyncSession, status: ProviderUsageStatus
) -> None:
    user_id = await _user_id(session)
    usage = OllamaUsageRepository(session)
    registry = _registry(session, usage, Gateway(["gemma4:31b"]))
    await usage.record_status(
        user_id,
        "ollama-cloud",
        status,
        model_name="gemma4:31b",
        observed_at=NOW,
        detail_code="safe_code",
    )

    snapshot = await OllamaUsageService(usage, registry, clock=lambda: NOW).snapshot(
        user_id, refresh_models=False
    )

    assert snapshot.status is status
    assert snapshot.status_model_name == "gemma4:31b"
    assert snapshot.status_observed_at == NOW
    assert snapshot.detail_code == "safe_code"


@pytest.mark.asyncio
async def test_refresh_returns_only_available_allowlisted_models_without_resetting_status(
    session: AsyncSession,
) -> None:
    user_id = await _user_id(session)
    usage = OllamaUsageRepository(session)
    cloud = Gateway(["paid-model", "gpt-oss:20b", "gemma4:31b"])
    registry = _registry(session, usage, cloud)
    await usage.record_status(
        user_id,
        "ollama-cloud",
        ProviderUsageStatus.RATE_LIMITED,
        model_name="gemma4:31b",
        observed_at=NOW,
        detail_code="rate_limited",
    )

    snapshot = await OllamaUsageService(usage, registry, clock=lambda: NOW).snapshot(
        user_id, refresh_models=True
    )

    assert cloud.list_calls == 1
    assert snapshot.available_models == ("gemma4:31b", "gpt-oss:20b")
    assert snapshot.status is ProviderUsageStatus.RATE_LIMITED


@pytest.mark.asyncio
async def test_refresh_failure_records_status_and_keeps_local_totals(
    session: AsyncSession,
) -> None:
    user_id = await _user_id(session)
    usage = OllamaUsageRepository(session)
    cloud = Gateway(
        ["gemma4:31b"],
        list_error=ModelGatewayError("secret body", code="authentication"),
    )
    registry = _registry(session, usage, cloud)
    await usage.record_success(
        user_id,
        "ollama-cloud",
        "gemma4:31b",
        ChatResponse(prompt_tokens=11, output_tokens=2),
        NOW,
    )

    snapshot = await OllamaUsageService(usage, registry, clock=lambda: NOW).snapshot(
        user_id, refresh_models=True
    )

    assert snapshot.available_models == ()
    assert snapshot.models[0].today.prompt_tokens == 11
    assert snapshot.status is ProviderUsageStatus.AUTH_ERROR
    assert snapshot.detail_code == "authentication"
