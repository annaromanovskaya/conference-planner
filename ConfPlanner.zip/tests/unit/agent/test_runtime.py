import asyncio
from collections import deque
from datetime import UTC, datetime
from types import SimpleNamespace
from zoneinfo import ZoneInfo

import pytest

from conference_planner.agent.memory import MemoryService
from conference_planner.agent.runtime import AgentRuntime
from conference_planner.ai.gateway import ModelGatewayError
from conference_planner.ai.models import ChatResponse, ToolCall, ToolDefinition
from conference_planner.ai.registry import ActiveModel
from conference_planner.db.repositories.users import UserRepository
from conference_planner.mcp.client import ToolResult
from conference_planner.runtime_clock import ApplicationClock
from conference_planner.schemas.agent import DomainReference
from conference_planner.schemas.common import AgentRunStatus


class FakeGateway:
    def __init__(self, *responses):
        self.responses = deque(responses)
        self.calls = []

    async def chat(self, model, messages, tools=()):
        self.calls.append((model, tuple(messages), tuple(tools)))
        response = self.responses.popleft()
        if isinstance(response, Exception):
            raise response
        if callable(response):
            return await response()
        return response


class FakeRegistry:
    def __init__(self, gateway, *, supports_tools=True):
        self.gateway = gateway
        self.active = ActiveModel("local", "test-model", supports_tools)
        self.chat_calls = []

    async def get_active(self, _user_id):
        return self.active

    def gateway_for(self, _profile_id):
        return self.gateway

    async def chat(self, user_id, active, messages, tools=(), *, response_schema=None):
        self.chat_calls.append((user_id, active, tuple(messages), tuple(tools), response_schema))
        return await self.gateway.chat(active.model_name, messages, tools)


class FakeTools:
    def __init__(self, result=None):
        self.calls = []
        self.result = result or ToolResult(content='{"items": []}')

    async def list_tools(self):
        return (
            ToolDefinition(
                name="search_knowledge",
                description="Search knowledge",
                input_schema={
                    "type": "object",
                    "properties": {"query": {"type": "string"}},
                    "required": ["query"],
                    "additionalProperties": False,
                },
            ),
        )

    async def call_tool(self, name, arguments):
        self.calls.append((name, arguments))
        return self.result


async def _runtime(session, gateway, tools=None, *, supports_tools=True, **limits):
    user = await UserRepository(session).get_or_create_by_telegram_id(101)
    await session.flush()
    memory = MemoryService(session, max_context_chars=limits.get("max_context_chars", 4_000))
    runtime = AgentRuntime(
        FakeRegistry(gateway, supports_tools=supports_tools),
        memory,
        tools or FakeTools(),
        max_steps=limits.get("max_steps", 6),
        max_tool_calls_per_step=limits.get("max_tool_calls_per_step", 3),
        timeout_seconds=limits.get("timeout_seconds", 2),
        tracked_check_timeout_seconds=limits.get(
            "tracked_check_timeout_seconds", 300
        ),
        max_tool_result_chars=limits.get("max_tool_result_chars", 2_000),
        application_clock=limits.get("application_clock"),
    )
    return user.id, memory, runtime


@pytest.mark.asyncio
async def test_system_prompt_contains_local_search_date_without_secrets(session) -> None:
    clock = ApplicationClock.start(
        ZoneInfo("Europe/Moscow"),
        now_provider=lambda: datetime(2026, 10, 18, 21, 30, tzinfo=UTC),
    )
    gateway = FakeGateway(ChatResponse(content="Готово."))
    user_id, _memory, runtime = await _runtime(
        session, gateway, application_clock=clock
    )

    await runtime.respond(user_id, "Что ты умеешь?")

    system_prompt = gateway.calls[0][1][0].content
    assert "Текущая локальная дата: 2026-10-19" in system_prompt
    assert "Временная зона: Europe/Moscow" in system_prompt
    assert "hub_secret" not in system_prompt


@pytest.mark.asyncio
async def test_plain_response_is_persisted(session) -> None:
    gateway = FakeGateway(
        ChatResponse(content="Здравствуйте!", model_name="gpt-oss:120b")
    )
    user_id, memory, runtime = await _runtime(session, gateway)

    reply = await runtime.respond(user_id, "Привет")
    context = await memory.get_context(user_id, "")

    assert reply.text == "Здравствуйте!"
    assert reply.model_profile_id == "local"
    assert reply.requested_model_name == "test-model"
    assert reply.model_name == "gpt-oss:120b"
    assert [(item.role, item.content) for item in context.messages] == [
        ("user", "Привет"),
        ("assistant", "Здравствуйте!"),
    ]
    assert len(runtime.registry.chat_calls) == 1


@pytest.mark.asyncio
async def test_research_request_uses_configured_durable_workflow_instead_of_chat_model(
    session,
) -> None:
    gateway = FakeGateway(ChatResponse(content="не должен вызываться"))
    user_id, memory, runtime = await _runtime(session, gateway)

    class Planner:
        async def plan(self, owner_id, text):
            assert owner_id == user_id
            assert "конференции" in text
            return "bounded-plan"

    class Run:
        id = 17
        status = AgentRunStatus.COMPLETED
        error_code = None

    class Engine:
        async def start(self, owner_id, text, plan, progress):
            assert (owner_id, plan) == (user_id, "bounded-plan")
            await progress.emit(17, SimpleNamespace(message="Открыл страницу конференции."))
            return Run()

    updates = []
    async def record_update(message):
        updates.append(message)

    runtime.workflow_planner = Planner()
    runtime.workflow_engine = Engine()

    reply = await runtime.respond(
        user_id,
        "Найди конференции по звёздной астрономии",
        progress=record_update,
    )
    context = await memory.get_context(user_id, "")

    assert reply.text == "Исследование завершено. Номер запуска: 17."
    assert updates == ["Открыл страницу конференции."]
    assert gateway.calls == []
    assert context.messages[-1].content == reply.text


@pytest.mark.asyncio
async def test_refresh_tracked_conferences_bypasses_candidate_workflow_and_reports_each_result(
    session,
) -> None:
    class TrackedTools(FakeTools):
        async def list_tools(self):
            return (
                ToolDefinition(
                    name="list_conferences",
                    description="List conferences",
                    input_schema={"type": "object"},
                ),
                ToolDefinition(
                    name="check_tracked_conference",
                    description="Check conference",
                    input_schema={"type": "object"},
                ),
            )

        async def call_tool(self, name, arguments):
            self.calls.append((name, arguments))
            if name == "list_conferences":
                return ToolResult(
                    content="",
                    structured_content={
                        "items": [
                            {"id": 1, "name": "IMBASE 2027"},
                            {"id": 2, "name": "IAU GA 2027"},
                        ]
                    },
                )
            if arguments["conference_id"] == 1:
                return ToolResult(
                    content="",
                    structured_content={
                        "kind": "persistence_receipt",
                        "committed": True,
                        "summary": "Обновлено: start_date, deadline:ABSTRACT_SUBMISSION.",
                    },
                )
            return ToolResult(content="tool unavailable", is_error=True)

    gateway = FakeGateway(ChatResponse(content="не должен вызываться"))
    tools = TrackedTools()
    user_id, memory, runtime = await _runtime(session, gateway, tools)

    class Planner:
        async def plan(self, *_args):
            raise AssertionError("candidate workflow must not be used")

    class Engine:
        async def start(self, *_args):
            raise AssertionError("candidate workflow must not be used")

    runtime.workflow_planner = Planner()
    runtime.workflow_engine = Engine()
    progress = []

    reply = await runtime.respond(
        user_id,
        "Проверь отслеживаемые конференции и обнови информацию и дедлайны",
        progress=progress.append,
    )

    assert reply.error_code is None
    assert "Проверено: 2" in reply.text
    assert "IMBASE 2027" in reply.text
    assert "Обновлено: start_date, deadline:ABSTRACT_SUBMISSION." in reply.text
    assert "IAU GA 2027" in reply.text
    assert "проверить не удалось" in reply.text.casefold()
    assert tools.calls == [
        ("list_conferences", {"status": "TRACKING", "limit": 50}),
        ("check_tracked_conference", {"conference_id": 1}),
        ("check_tracked_conference", {"conference_id": 2}),
    ]
    assert any("IMBASE 2027" in item for item in progress)
    assert gateway.calls == []
    context = await memory.get_context(user_id, "")
    assert context.messages[-1].content == reply.text


@pytest.mark.asyncio
async def test_refresh_tracked_conferences_reports_safe_monitoring_failure_reason(
    session,
) -> None:
    class TrackedTools(FakeTools):
        async def list_tools(self):
            return (
                ToolDefinition(
                    name="list_conferences",
                    description="List conferences",
                    input_schema={"type": "object"},
                ),
                ToolDefinition(
                    name="check_tracked_conference",
                    description="Check conference",
                    input_schema={"type": "object"},
                ),
            )

        async def call_tool(self, name, arguments):
            if name == "list_conferences":
                return ToolResult(
                    content="",
                    structured_content={
                        "items": [{"id": 2, "name": "IMBASE 2027"}]
                    },
                )
            return ToolResult(
                content="",
                structured_content={
                    "kind": "monitoring_failure",
                    "committed": False,
                    "conference_id": arguments["conference_id"],
                    "error_code": "NETWORK_ERROR",
                    "summary": (
                        "Не удалось открыть источники. Используемого снимка или "
                        "поисковой карточки с датами нет. Код: NETWORK_ERROR."
                    ),
                },
            )

    gateway = FakeGateway(ChatResponse(content="не должен вызываться"))
    user_id, _, runtime = await _runtime(session, gateway, TrackedTools())

    reply = await runtime.respond(
        user_id,
        "Проверь отслеживаемые конференции и обнови информацию и дедлайны",
    )

    assert "IMBASE 2027" in reply.text
    assert "Не удалось открыть источники" in reply.text
    assert "NETWORK_ERROR" in reply.text
    assert "Проверить не удалось; данные не изменены" not in reply.text


@pytest.mark.asyncio
async def test_tracked_refresh_is_not_cancelled_by_regular_chat_timeout(session) -> None:
    class SlowTrackedTools(FakeTools):
        async def list_tools(self):
            return (
                ToolDefinition(
                    name="list_conferences",
                    description="List conferences",
                    input_schema={"type": "object"},
                ),
                ToolDefinition(
                    name="check_tracked_conference",
                    description="Check conference",
                    input_schema={"type": "object"},
                ),
            )

        async def call_tool(self, name, arguments):
            self.calls.append((name, arguments))
            if name == "list_conferences":
                return ToolResult(
                    content="",
                    structured_content={
                        "items": [{"id": 1, "name": "Медленная конференция"}]
                    },
                )
            await asyncio.sleep(0.03)
            return ToolResult(
                content="",
                structured_content={
                    "kind": "persistence_receipt",
                    "committed": True,
                    "summary": "Данные обновлены.",
                },
            )

    user_id, _, runtime = await _runtime(
        session,
        FakeGateway(ChatResponse(content="не должен вызываться")),
        SlowTrackedTools(),
        timeout_seconds=0.01,
        tracked_check_timeout_seconds=0.1,
    )

    reply = await runtime.respond(
        user_id,
        "Проверь отслеживаемые конференции и обнови информацию и дедлайны",
    )

    assert reply.error_code is None
    assert "Успешно: 1" in reply.text
    assert "Данные обновлены" in reply.text


@pytest.mark.asyncio
async def test_tracked_refresh_times_out_only_one_conference_and_continues(session) -> None:
    class PartlyHangingTools(FakeTools):
        async def list_tools(self):
            return (
                ToolDefinition(
                    name="list_conferences",
                    description="List conferences",
                    input_schema={"type": "object"},
                ),
                ToolDefinition(
                    name="check_tracked_conference",
                    description="Check conference",
                    input_schema={"type": "object"},
                ),
            )

        async def call_tool(self, name, arguments):
            self.calls.append((name, arguments))
            if name == "list_conferences":
                return ToolResult(
                    content="",
                    structured_content={
                        "items": [
                            {"id": 1, "name": "Зависший сайт"},
                            {"id": 2, "name": "Рабочий сайт"},
                        ]
                    },
                )
            if arguments["conference_id"] == 1:
                await asyncio.sleep(0.1)
            return ToolResult(
                content="",
                structured_content={
                    "kind": "persistence_receipt",
                    "committed": True,
                    "summary": "Проверка завершена.",
                },
            )

    tools = PartlyHangingTools()
    progress: list[str] = []
    user_id, _, runtime = await _runtime(
        session,
        FakeGateway(ChatResponse(content="не должен вызываться")),
        tools,
        timeout_seconds=1,
        tracked_check_timeout_seconds=0.01,
    )

    reply = await runtime.respond(
        user_id,
        "Проверь отслеживаемые конференции и обнови информацию и дедлайны",
        progress=progress.append,
    )

    assert reply.error_code is None
    assert "Успешно: 1" in reply.text
    assert "С ошибкой: 1" in reply.text
    assert "Зависший сайт\nПревышено время проверки" in reply.text
    assert "Рабочий сайт\nПроверка завершена" in reply.text
    assert ("check_tracked_conference", {"conference_id": 2}) in tools.calls
    assert any("превысила допустимое время" in item for item in progress)


@pytest.mark.asyncio
async def test_failed_workflow_reply_includes_safe_error_code(session) -> None:
    gateway = FakeGateway(ChatResponse(content="не должен вызываться"))
    user_id, _, runtime = await _runtime(session, gateway)

    class Planner:
        async def plan(self, *_args):
            return "bounded-plan"

    class Run:
        id = 1
        status = AgentRunStatus.FAILED
        error_code = "NO_CANDIDATES"

    class Engine:
        async def start(self, *_args):
            return Run()

    runtime.workflow_planner = Planner()
    runtime.workflow_engine = Engine()

    reply = await runtime.respond(user_id, "Найди конференции и проверь дедлайны")

    assert reply.error_code == "NO_CANDIDATES"
    assert reply.text == (
        "Исследование не завершено. Номер запуска: 1. Код: NO_CANDIDATES."
    )


@pytest.mark.asyncio
async def test_conversation_summary_is_routed_through_registry(session) -> None:
    gateway = FakeGateway(
        ChatResponse(content="Основной ответ достаточно длинный."),
        ChatResponse(content="Краткое резюме."),
    )
    user_id, _, runtime = await _runtime(session, gateway, max_context_chars=40)

    reply = await runtime.respond(user_id, "Очень длинный пользовательский вопрос")

    assert reply.text == "Основной ответ достаточно длинный."
    assert len(runtime.registry.chat_calls) == 2
    assert runtime.registry.chat_calls[1][2][0].content.startswith("Кратко суммируй")


@pytest.mark.asyncio
async def test_single_tool_result_returns_references_and_pending_actions(session) -> None:
    pending = {
        "id": 42,
        "action_type": "track_conference",
        "summary": "Отслеживать конференцию 3",
        "status": "PENDING",
        "expires_at": "2026-10-13T12:00:00Z",
    }
    tools = FakeTools(
        ToolResult(
            content='{"id": 42}',
            structured_content=pending,
            references=(DomainReference(kind="conference", id=3, position=1),),
        )
    )
    gateway = FakeGateway(
        ChatResponse(
            tool_calls=(
                ToolCall(id="call-1", name="search_knowledge", arguments={"query": "astro"}),
            )
        )
    )
    user_id, _, runtime = await _runtime(session, gateway, tools)

    reply = await runtime.respond(user_id, "Найди astro")

    assert tools.calls == [("search_knowledge", {"query": "astro"})]
    assert reply.text == "Подтвердите действие кнопкой ниже."
    assert reply.references[0].id == 3
    assert reply.pending_actions[0].id == 42
    assert len(gateway.calls) == 1


@pytest.mark.asyncio
async def test_deadline_request_finds_conference_then_creates_pending_action(session) -> None:
    class DeadlineTools:
        def __init__(self) -> None:
            self.calls = []

        async def list_tools(self):
            common = {"type": "object", "additionalProperties": False}
            return (
                ToolDefinition(
                    name="find_conferences",
                    description="Find persisted conferences",
                    input_schema={
                        **common,
                        "properties": {
                            "query": {"type": "string"},
                            "limit": {"type": "integer"},
                        },
                        "required": ["query", "limit"],
                    },
                ),
                ToolDefinition(
                    name="propose_upsert_deadline",
                    description="Propose a deadline",
                    input_schema={
                        **common,
                        "properties": {
                            "conference_id": {"type": "integer"},
                            "deadline_type": {"type": "string"},
                            "approximate_year": {"type": "integer"},
                            "approximate_month": {"type": "integer"},
                            "tentative": {"type": "boolean"},
                        },
                        "required": [
                            "conference_id",
                            "deadline_type",
                            "approximate_year",
                            "approximate_month",
                            "tentative",
                        ],
                    },
                ),
            )

        async def call_tool(self, name, arguments):
            self.calls.append((name, arguments))
            if name == "find_conferences":
                return ToolResult(
                    content='{"items":[{"kind":"conference","id":17,"name":"IMBASE 2027"}]}'
                )
            return ToolResult(
                content='{"status":"PENDING"}',
                structured_content={
                    "id": 92,
                    "action_type": "upsert_deadline",
                    "summary": "Записать ориентировочный дедлайн регистрации IMBASE 2027",
                    "status": "PENDING",
                    "expires_at": "2026-10-19T20:00:00Z",
                },
            )

    gateway = FakeGateway(
        ChatResponse(
            tool_calls=(
                ToolCall(
                    id="find-imbase",
                    name="find_conferences",
                    arguments={"query": "IMBASE 2027", "limit": 10},
                ),
            )
        ),
        ChatResponse(
            tool_calls=(
                ToolCall(
                    id="deadline-imbase",
                    name="propose_upsert_deadline",
                    arguments={
                        "conference_id": 17,
                        "deadline_type": "REGISTRATION",
                        "approximate_year": 2027,
                        "approximate_month": 5,
                        "tentative": True,
                    },
                ),
            )
        ),
    )
    tools = DeadlineTools()
    user_id, _, runtime = await _runtime(session, gateway, tools)

    reply = await runtime.respond(
        user_id, "Для IMBASE 2027 установи дедлайн регистрации на май 2027"
    )

    assert [name for name, _arguments in tools.calls] == [
        "find_conferences",
        "propose_upsert_deadline",
    ]
    assert [item.id for item in reply.pending_actions] == [92]
    assert "find_conferences" in gateway.calls[0][1][0].content
    assert "не выбирай конференцию" in gateway.calls[0][1][0].content.casefold()


@pytest.mark.asyncio
async def test_chat_only_model_gets_no_tools_and_an_explicit_note(session) -> None:
    gateway = FakeGateway(ChatResponse(content="Ответ без инструментов"))
    user_id, _, runtime = await _runtime(session, gateway, supports_tools=False)

    await runtime.respond(user_id, "Вопрос")

    assert gateway.calls[0][2] == ()
    assert "недоступны" in gateway.calls[0][1][0].content


@pytest.mark.asyncio
async def test_unknown_and_schema_invalid_tools_are_not_executed(session) -> None:
    tools = FakeTools()
    gateway = FakeGateway(
        ChatResponse(tool_calls=(ToolCall(name="run_shell", arguments={}),)),
        ChatResponse(tool_calls=(ToolCall(name="search_knowledge", arguments={"query": 123}),)),
        ChatResponse(content="Не удалось использовать инструменты."),
    )
    user_id, _, runtime = await _runtime(session, gateway, tools)

    reply = await runtime.respond(user_id, "Сделай")

    assert reply.text == "Не удалось использовать инструменты."
    assert tools.calls == []
    assert "unknown tool" in gateway.calls[1][1][-1].content
    assert "invalid arguments" in gateway.calls[2][1][-1].content


@pytest.mark.asyncio
async def test_failed_mutation_tool_cannot_be_reported_as_saved(session) -> None:
    class FailedMutationTools:
        async def list_tools(self):
            return (
                ToolDefinition(
                    name="propose_import_conference_url",
                    description="Import conference URL",
                    input_schema={
                        "type": "object",
                        "properties": {
                            "title": {"type": "string"},
                            "source_url": {"type": "string"},
                        },
                        "required": ["title", "source_url"],
                        "additionalProperties": False,
                    },
                ),
            )

        async def call_tool(self, _name, _arguments):
            return ToolResult(content="candidate not found", is_error=True)

    gateway = FakeGateway(
        ChatResponse(
            tool_calls=(
                ToolCall(
                    name="propose_import_conference_url",
                    arguments={
                        "title": "IMBASE 2027",
                        "source_url": "https://meetings.iac.es/imbase2027/",
                    },
                ),
            )
        ),
        ChatResponse(content="Я вручную сохранил конференцию и буду её отслеживать."),
    )
    user_id, _, runtime = await _runtime(session, gateway, FailedMutationTools())

    reply = await runtime.respond(user_id, "Добавь IMBASE 2027")

    assert reply.error_code == "mutation_tool_failure"
    assert "ничего не сохранено" in reply.text.casefold()
    assert "отслеживание не включено" in reply.text.casefold()
    assert len(gateway.calls) == 1


@pytest.mark.asyncio
async def test_failed_memory_proposal_has_memory_specific_error(session) -> None:
    class FailedMemoryTools:
        async def list_tools(self):
            return (
                ToolDefinition(
                    name="propose_save_memory",
                    description="Save memory",
                    input_schema={
                        "type": "object",
                        "properties": {
                            "kind": {"type": "string"},
                            "scope": {"type": "string"},
                            "original_text": {"type": "string"},
                            "rule_data": {"type": "object"},
                        },
                        "required": ["kind", "scope", "original_text", "rule_data"],
                        "additionalProperties": False,
                    },
                ),
            )

        async def call_tool(self, _name, _arguments):
            return ToolResult(content="invalid memory", is_error=True)

    gateway = FakeGateway(
        ChatResponse(
            tool_calls=(
                ToolCall(
                    name="propose_save_memory",
                    arguments={
                        "kind": "PREFERENCE",
                        "scope": "GLOBAL",
                        "original_text": "Мне интересна спектроскопия",
                        "rule_data": {"statement": "Мне интересна спектроскопия"},
                    },
                ),
            )
        )
    )
    user_id, _, runtime = await _runtime(session, gateway, FailedMemoryTools())

    reply = await runtime.respond(user_id, "Запомни, что мне интересна спектроскопия")

    assert reply.error_code == "mutation_tool_failure"
    assert "памят" in reply.text.casefold()
    assert "официальную ссылку конференции" not in reply.text.casefold()


@pytest.mark.asyncio
async def test_model_cannot_claim_database_update_without_receipt(session) -> None:
    gateway = FakeGateway(ChatResponse(content="Я обновил дедлайны и сохранил конференцию."))
    user_id, _, runtime = await _runtime(session, gateway, supports_tools=False)

    reply = await runtime.respond(user_id, "Проверь конференцию")

    assert "не изменялись" in reply.text.casefold()
    assert "сохранил" not in reply.text.casefold()


@pytest.mark.asyncio
async def test_unreceipted_mutation_sentence_does_not_destroy_search_results(session) -> None:
    gateway = FakeGateway(
        ChatResponse(
            content=(
                "Найдена конференция IMBASE 2027: https://meetings.iac.es/imbase2027/. "
                "Я сохранил её и теперь отслеживаю."
            )
        )
    )
    user_id, _, runtime = await _runtime(session, gateway, supports_tools=False)

    reply = await runtime.respond(user_id, "Найди конференцию")

    assert "IMBASE 2027" in reply.text
    assert "https://meetings.iac.es/imbase2027/" in reply.text
    assert "сохранил" not in reply.text.casefold()
    assert "ничего не записано" not in reply.text.casefold()


@pytest.mark.asyncio
async def test_capability_answer_does_not_claim_or_report_database_mutation(session) -> None:
    gateway = FakeGateway(
        ChatResponse(
            content=(
                "Я отслеживаю дедлайны конференций и показываю ближайшие даты. "
                "Также я могу искать официальные источники."
            )
        )
    )
    user_id, _, runtime = await _runtime(session, gateway, supports_tools=False)

    reply = await runtime.respond(user_id, "Что ты умеешь?")

    assert reply.text.startswith("Я отслеживаю дедлайны конференций")
    assert "ничего не записано" not in reply.text.casefold()


@pytest.mark.asyncio
async def test_mutation_request_without_receipt_reports_that_nothing_was_written(session) -> None:
    gateway = FakeGateway(ChatResponse(content="Я сохранил конференцию."))
    user_id, _, runtime = await _runtime(session, gateway, supports_tools=False)

    reply = await runtime.respond(user_id, "Сохрани конференцию")

    assert "сохранил" not in reply.text.casefold()
    assert "не изменялись" in reply.text.casefold()


@pytest.mark.asyncio
async def test_runtime_reports_truthful_tool_progress(session) -> None:
    class CandidateTools:
        async def list_tools(self):
            return (
                ToolDefinition(
                    name="search_conference_candidates",
                    description="Search candidates",
                    input_schema={
                        "type": "object",
                        "properties": {
                            "query": {"type": "string"},
                            "limit": {"type": "integer"},
                            "page": {"type": "integer"},
                        },
                        "required": ["query", "limit", "page"],
                        "additionalProperties": False,
                    },
                ),
            )

        async def call_tool(self, _name, _arguments):
            return ToolResult(
                content='{"items": [{"id": 1}]}',
                structured_content={
                    "items": [{"kind": "event_candidate", "id": 1}],
                    "new_count": 1,
                    "page": 2,
                    "next_page": 3,
                },
            )

    gateway = FakeGateway(
        ChatResponse(
            tool_calls=(
                ToolCall(
                    name="search_conference_candidates",
                    arguments={"query": "stars", "limit": 10, "page": 2},
                ),
            )
        ),
        ChatResponse(content="Найден один кандидат."),
    )
    user_id, _, runtime = await _runtime(session, gateway, CandidateTools())
    progress: list[str] = []

    async def collect(text: str) -> None:
        progress.append(text)

    reply = await runtime.respond(user_id, "Ищи", progress=collect)

    assert reply.text == "Найден один кандидат."
    assert any("страница 2" in item.casefold() for item in progress)
    assert any("получено кандидатов: 1, новых: 1" in item.casefold() for item in progress)


@pytest.mark.asyncio
async def test_committed_receipt_replaces_model_success_copy(session) -> None:
    class ReceiptTools(FakeTools):
        async def list_tools(self):
            return (
                ToolDefinition(
                    name="check_tracked_conference",
                    description="Check tracked conference",
                    input_schema={
                        "type": "object",
                        "properties": {"conference_id": {"type": "integer"}},
                        "required": ["conference_id"],
                        "additionalProperties": False,
                    },
                ),
            )

    tools = ReceiptTools(
        ToolResult(
            content='{"committed":true}',
            structured_content={
                "kind": "persistence_receipt",
                "committed": True,
                "summary": "Обновлено: start_date, deadline:REGISTRATION.",
            },
        )
    )
    gateway = FakeGateway(
        ChatResponse(
            tool_calls=(
                ToolCall(
                    name="check_tracked_conference",
                    arguments={"conference_id": 1},
                ),
            )
        ),
        ChatResponse(content="Я всё сохранил, обновил и исправил."),
    )
    user_id, _, runtime = await _runtime(session, gateway, tools)

    reply = await runtime.respond(user_id, "Проверь")

    assert reply.text == "Обновлено: start_date, deadline:REGISTRATION."


@pytest.mark.asyncio
async def test_tool_call_limit_chunks_all_calls_and_lets_model_continue(session) -> None:
    calls = tuple(
        ToolCall(name="search_knowledge", arguments={"query": str(index)}) for index in range(4)
    )
    gateway = FakeGateway(
        ChatResponse(tool_calls=calls),
        ChatResponse(content="Поиск завершён по обработанным источникам."),
    )
    tools = FakeTools()
    user_id, _, runtime = await _runtime(session, gateway, tools, max_tool_calls_per_step=3)

    reply = await runtime.respond(user_id, "loop")

    assert reply.error_code is None
    assert reply.text == "Поиск завершён по обработанным источникам."
    assert tools.calls == [
        ("search_knowledge", {"query": "0"}),
        ("search_knowledge", {"query": "1"}),
        ("search_knowledge", {"query": "2"}),
        ("search_knowledge", {"query": "3"}),
    ]
    tool_messages = [item for item in gateway.calls[1][1] if item.role == "tool"]
    assert len(tool_messages) == 4
    assert "deferred" not in tool_messages[-1].content


@pytest.mark.asyncio
async def test_deferred_proposals_are_collected_before_confirmation(session) -> None:
    class ProposalTools:
        def __init__(self) -> None:
            self.calls = []

        async def list_tools(self):
            return (
                ToolDefinition(
                    name="propose_add_source",
                    description="Add source",
                    input_schema={
                        "type": "object",
                        "properties": {"value": {"type": "string"}},
                        "required": ["value"],
                        "additionalProperties": False,
                    },
                ),
            )

        async def call_tool(self, name, arguments):
            self.calls.append((name, arguments))
            action_id = len(self.calls)
            return ToolResult(
                content='{"status":"PENDING"}',
                structured_content={
                    "id": action_id,
                    "action_type": "add_source",
                    "summary": f"Добавить источник {arguments['value']}",
                    "status": "PENDING",
                    "expires_at": "2026-10-15T20:00:00Z",
                },
            )

    first_batch = tuple(
        ToolCall(
            id=f"call-{index}",
            name="propose_add_source",
            arguments={"value": f"source-{index}.org"},
        )
        for index in range(4)
    )
    gateway = FakeGateway(ChatResponse(tool_calls=first_batch))
    tools = ProposalTools()
    user_id, _, runtime = await _runtime(
        session, gateway, tools, max_tool_calls_per_step=3
    )

    reply = await runtime.respond(user_id, "Добавь четыре источника")

    assert [item.summary for item in reply.pending_actions] == [
        "Добавить источник source-0.org",
        "Добавить источник source-1.org",
        "Добавить источник source-2.org",
        "Добавить источник source-3.org",
    ]
    assert len(gateway.calls) == 1


@pytest.mark.asyncio
async def test_mutation_request_gets_one_corrective_tool_step(session) -> None:
    class ProposalTools:
        async def list_tools(self):
            return (
                ToolDefinition(
                    name="propose_add_source",
                    description="Add source",
                    input_schema={
                        "type": "object",
                        "properties": {"value": {"type": "string"}},
                        "required": ["value"],
                        "additionalProperties": False,
                    },
                ),
            )

        async def call_tool(self, _name, arguments):
            return ToolResult(
                content='{"status":"PENDING"}',
                structured_content={
                    "id": 91,
                    "action_type": "add_source",
                    "summary": f"Добавить источник {arguments['value']}",
                    "status": "PENDING",
                    "expires_at": "2026-10-15T20:00:00Z",
                },
            )

    gateway = FakeGateway(
        ChatResponse(content="Я добавлю сайт ИНАСАН в список источников."),
        ChatResponse(
            tool_calls=(
                ToolCall(
                    id="call-source",
                    name="propose_add_source",
                    arguments={"value": "inasan.ru"},
                ),
            )
        ),
    )
    user_id, _, runtime = await _runtime(session, gateway, ProposalTools())

    reply = await runtime.respond(user_id, "Добавь сайт ИНАСАН inasan.ru")

    assert len(gateway.calls) == 2
    assert [item.id for item in reply.pending_actions] == [91]


@pytest.mark.asyncio
async def test_web_search_claim_gets_one_corrective_tool_step(session) -> None:
    class SearchTools:
        def __init__(self) -> None:
            self.calls = []

        async def list_tools(self):
            return (
                ToolDefinition(
                    name="search_conference_candidates",
                    description="Search the internet",
                    input_schema={
                        "type": "object",
                        "properties": {
                            "query": {"type": "string"},
                            "limit": {"type": "integer"},
                            "page": {"type": "integer"},
                        },
                        "required": ["query", "limit", "page"],
                        "additionalProperties": False,
                    },
                ),
            )

        async def call_tool(self, name, arguments):
            self.calls.append((name, arguments))
            return ToolResult(content='{"items": []}')

    gateway = FakeGateway(
        ChatResponse(content="Я поискал и конференций больше нет."),
        ChatResponse(
            tool_calls=(
                ToolCall(
                    id="call-search",
                    name="search_conference_candidates",
                    arguments={"query": "stellar astronomy 2027", "limit": 20, "page": 1},
                ),
            )
        ),
        ChatResponse(content="По проверенным результатам новых конференций не найдено."),
    )
    tools = SearchTools()
    user_id, _, runtime = await _runtime(session, gateway, tools)

    reply = await runtime.respond(user_id, "Поищи конференции по звёздной астрономии 2027")

    assert len(gateway.calls) == 3
    assert tools.calls == [
        (
            "search_conference_candidates",
            {"query": "stellar astronomy 2027", "limit": 20, "page": 1},
        )
    ]
    assert reply.text == "По проверенным результатам новых конференций не найдено."


@pytest.mark.asyncio
async def test_step_limit_and_oversized_result_are_controlled(session) -> None:
    response = ChatResponse(
        tool_calls=(ToolCall(name="search_knowledge", arguments={"query": "x"}),)
    )
    gateway = FakeGateway(response, response)
    tools = FakeTools(ToolResult(content="x" * 5_000))
    user_id, _, runtime = await _runtime(
        session, gateway, tools, max_steps=2, max_tool_result_chars=100
    )

    reply = await runtime.respond(user_id, "loop")

    assert reply.error_code == "step_limit"
    assert len(gateway.calls[1][1][-1].content) <= 100


@pytest.mark.asyncio
async def test_total_timeout_is_a_safe_russian_error(session) -> None:
    async def hang():
        await asyncio.sleep(1)

    gateway = FakeGateway(hang)
    user_id, _, runtime = await _runtime(session, gateway, timeout_seconds=0.01)

    reply = await runtime.respond(user_id, "Ждать")

    assert reply.error_code == "timeout"
    assert "время" in reply.text.casefold()


@pytest.mark.asyncio
async def test_provider_failure_does_not_expose_exception(session) -> None:
    gateway = FakeGateway(RuntimeError("secret upstream body"))
    user_id, _, runtime = await _runtime(session, gateway)

    reply = await runtime.respond(user_id, "Вопрос")

    assert reply.error_code == "provider_failure"
    assert "secret" not in reply.text


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("code", "expected"),
    [
        (
            "free_exhausted",
            "Ollama Free usage исчерпан. Выберите другую бесплатную модель через /model.",
        ),
        (
            "rate_limited",
            "Ollama временно ограничила запросы. Попробуйте позже или выберите "
            "другую бесплатную модель через /model.",
        ),
    ],
)
async def test_ollama_limit_failures_have_deterministic_messages(
    session, code: str, expected: str
) -> None:
    gateway = FakeGateway(ModelGatewayError("secret upstream body", code=code))
    user_id, _, runtime = await _runtime(session, gateway)

    reply = await runtime.respond(user_id, "Вопрос")

    assert reply.error_code == code
    assert reply.text == expected
    assert "secret" not in reply.text
