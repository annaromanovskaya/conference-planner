import importlib

import pytest

from conference_planner.db.models import User
from conference_planner.schemas.workflows import WorkflowBudget, WorkflowPlan, WorkflowTaskSpec


def _progress_api():
    return importlib.import_module("conference_planner.workflows.progress")


def _plan() -> WorkflowPlan:
    return WorkflowPlan(
        tasks=(WorkflowTaskSpec(task_id="read", task_type="READ_DATABASE"),)
    )


@pytest.mark.asyncio
async def test_progress_events_are_ordered_and_scoped_by_run(session) -> None:
    progress_module = _progress_api()
    repository_module = importlib.import_module(
        "conference_planner.db.repositories.agent_workflows"
    )
    repository = repository_module.AgentWorkflowRepository(session)
    user = User(telegram_id=505)
    session.add(user)
    await session.flush()
    first_run = await repository.create_run(user.id, "Первый", _plan(), WorkflowBudget())
    second_run = await repository.create_run(user.id, "Второй", _plan(), WorkflowBudget())
    progress = progress_module.WorkflowProgress(repository)

    await progress.emit(
        first_run.id,
        progress_module.ProgressEvent(
            event_type="TOOL_STARTED",
            message="Открываю страницу",
            safe_data={"url": "https://example.org"},
        ),
    )
    await progress.emit(
        second_run.id,
        progress_module.ProgressEvent(
            event_type="FACTS_FOUND",
            message="Другой запуск",
        ),
    )
    await progress.emit(
        first_run.id,
        progress_module.ProgressEvent(
            event_type="TOOL_COMPLETED",
            message="Страница обработана",
        ),
    )

    events = await progress.list_after(first_run.id, sequence=0)
    tail = await progress.list_after(first_run.id, sequence=1)

    assert [(event.sequence, event.message) for event in events] == [
        (1, "Открываю страницу"),
        (2, "Страница обработана"),
    ]
    assert [event.message for event in tail] == ["Страница обработана"]


def test_progress_data_removes_secrets_and_limits_values() -> None:
    progress_module = _progress_api()

    sanitized = progress_module.sanitize_progress_data(
        {
            "url": "https://example.org/events",
            "api_key": "hub-secret",
            "Authorization": "Bearer private",
            "system_prompt": "hidden instructions",
            "result": "x" * 700,
            "count": 3,
        }
    )

    assert sanitized == {
        "url": "https://example.org/events",
        "result": "x" * 500,
        "count": "3",
    }

