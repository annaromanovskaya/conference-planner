from datetime import date
from unittest.mock import AsyncMock

import pytest
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from conference_planner.conferences.persistence import ConferencePersistenceService
from conference_planner.db.models import (
    Conference,
    ConferenceChange,
    ConferenceEvidence,
    Deadline,
    Subscription,
)
from conference_planner.db.repositories.users import UserRepository
from conference_planner.schemas.research import VerifiedConferenceResearch

SOURCE = "https://meetings.iac.es/imbase2027/pages/important-dates.php"


def _verified(
    *,
    source_class: str = "OFFICIAL_CONFERENCE",
    start_date: str = "2027-07-12",
    location: str = "Tenerife, Canary Islands, Spain",
) -> VerifiedConferenceResearch:
    status = {
        "OFFICIAL_CONFERENCE": "OFFICIAL_CONFIRMED",
        "OFFICIAL_ORGANIZER": "ORGANIZER_CONFIRMED",
        "SECONDARY": "SECONDARY_UNVERIFIED",
    }[source_class]
    return VerifiedConferenceResearch.model_validate(
        {
            "name": "ImBaSE 2027",
            "aliases": [
                "International Meeting on Binary Stars, Exoplanets and Stellar Astrophysics"
            ],
            "source_url": SOURCE,
            "source_class": source_class,
            "facts": [
                {
                    "kind": "official_url",
                    "value": "https://meetings.iac.es/imbase2027/",
                    "source_url": SOURCE,
                    "source_class": source_class,
                    "excerpt": "ImBaSE2027",
                    "verification_status": status,
                },
                {
                    "kind": "start_date",
                    "value": start_date,
                    "source_url": SOURCE,
                    "source_class": source_class,
                    "excerpt": f"Conference starts {start_date}",
                    "verification_status": status,
                },
                {
                    "kind": "end_date",
                    "value": "2027-07-16",
                    "source_url": SOURCE,
                    "source_class": source_class,
                    "excerpt": "Conference ends 2027-07-16",
                    "verification_status": status,
                },
                {
                    "kind": "location",
                    "value": location,
                    "source_url": SOURCE,
                    "source_class": source_class,
                    "excerpt": location,
                    "verification_status": status,
                },
            ],
            "deadlines": [
                {
                    "deadline_type": "OTHER",
                    "exact_date": "2027-07-12",
                    "source_url": SOURCE,
                    "source_class": source_class,
                    "excerpt": "12th of July 2027: ImBaSE2027 starts",
                    "verification_status": status,
                },
                {
                    "deadline_type": "REGISTRATION",
                    "approximate_year": 2027,
                    "approximate_month": 5,
                    "tentative": True,
                    "source_url": SOURCE,
                    "source_class": source_class,
                    "excerpt": "May 2027: registration deadline (tentative)",
                    "verification_status": "TENTATIVE",
                },
            ],
        }
    )


@pytest.mark.asyncio
async def test_persist_creates_facts_evidence_deadlines_subscription_and_receipt(
    session: AsyncSession,
) -> None:
    owner = await UserRepository(session).get_or_create_by_telegram_id(1001)

    receipt = await ConferencePersistenceService(session).persist(owner.id, _verified(), track=True)

    conference = await session.get(Conference, receipt.conference_id)
    assert receipt.committed is True
    assert receipt.created is True
    assert receipt.subscription_id is not None
    assert conference is not None
    assert conference.website == "https://meetings.iac.es/imbase2027/"
    assert conference.start_date == date(2027, 7, 12)
    assert conference.end_date == date(2027, 7, 16)
    assert conference.location == "Tenerife, Canary Islands, Spain"
    assert len(receipt.deadlines) == 2
    assert any(item.exact_date == date(2027, 7, 12) for item in receipt.deadlines)
    assert any(
        (item.approximate_year, item.approximate_month, item.tentative) == (2027, 5, True)
        for item in receipt.deadlines
    )
    assert len(receipt.evidence_ids) == 6
    assert await session.scalar(select(func.count()).select_from(Subscription)) == 1
    assert "сохранена" in receipt.telegram_summary().lower()


@pytest.mark.asyncio
async def test_official_replaces_secondary_and_secondary_cannot_replace_official(
    session: AsyncSession,
) -> None:
    owner = await UserRepository(session).get_or_create_by_telegram_id(1001)
    service = ConferencePersistenceService(session)
    first = await service.persist(
        owner.id,
        _verified(
            source_class="SECONDARY",
            start_date="2027-07-13",
            location="Santa Cruz de Tenerife",
        ),
        track=True,
    )

    official = await service.persist(owner.id, _verified(), track=True)
    ignored = await service.persist(
        owner.id,
        _verified(
            source_class="SECONDARY",
            start_date="2027-07-14",
            location="Madrid",
        ),
        track=True,
    )

    conference = await session.get(Conference, first.conference_id)
    assert conference is not None
    assert conference.start_date == date(2027, 7, 12)
    assert conference.location == "Tenerife, Canary Islands, Spain"
    assert {"start_date", "location"} <= set(official.updated_fields)
    assert ignored.updated_fields == ()
    changes = list(await session.scalars(select(ConferenceChange)))
    assert any(
        item.old_value == "2027-07-13" and item.new_value == "2027-07-12" for item in changes
    )
    evidence = list(await session.scalars(select(ConferenceEvidence)))
    assert any(item.fact_value == "2027-07-13" for item in evidence)
    assert any(item.fact_value == "2027-07-12" for item in evidence)


@pytest.mark.asyncio
async def test_repeated_verified_research_is_idempotent(session: AsyncSession) -> None:
    owner = await UserRepository(session).get_or_create_by_telegram_id(1001)
    service = ConferencePersistenceService(session)
    first = await service.persist(owner.id, _verified(), track=True)
    before = {
        "conference": await session.scalar(select(func.count()).select_from(Conference)),
        "deadline": await session.scalar(select(func.count()).select_from(Deadline)),
        "evidence": await session.scalar(select(func.count()).select_from(ConferenceEvidence)),
        "change": await session.scalar(select(func.count()).select_from(ConferenceChange)),
    }

    second = await service.persist(owner.id, _verified(), track=True)
    after = {
        "conference": await session.scalar(select(func.count()).select_from(Conference)),
        "deadline": await session.scalar(select(func.count()).select_from(Deadline)),
        "evidence": await session.scalar(select(func.count()).select_from(ConferenceEvidence)),
        "change": await session.scalar(select(func.count()).select_from(ConferenceChange)),
    }

    assert second.conference_id == first.conference_id
    assert second.created is False
    assert second.updated_fields == ()
    assert before == after
    assert second.telegram_summary() == "Изменений нет. Данные конференции уже актуальны."


@pytest.mark.asyncio
async def test_failure_before_receipt_rolls_back_everything(session: AsyncSession) -> None:
    owner = await UserRepository(session).get_or_create_by_telegram_id(1001)
    await session.commit()
    service = ConferencePersistenceService(session)
    service._reread = AsyncMock(side_effect=RuntimeError("forced read-back failure"))

    with pytest.raises(RuntimeError, match="forced read-back failure"):
        await service.persist(owner.id, _verified(), track=True)

    assert await session.scalar(select(func.count()).select_from(Conference)) == 0
    assert await session.scalar(select(func.count()).select_from(Deadline)) == 0
    assert await session.scalar(select(func.count()).select_from(Subscription)) == 0
