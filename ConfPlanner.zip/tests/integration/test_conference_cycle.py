import asyncio
from datetime import UTC, datetime
from types import SimpleNamespace
from zoneinfo import ZoneInfo

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from conference_planner.conferences.cycle import (
    ConferenceCycleService,
    CycleMode,
    CycleRequest,
)
from conference_planner.conferences.research import (
    CandidateExpiredError,
    CandidateSearchReport,
    CandidateUnusableError,
)
from conference_planner.db.repositories.agent_workflows import AgentWorkflowRepository
from conference_planner.db.repositories.users import UserRepository
from conference_planner.runtime_clock import ApplicationClock
from conference_planner.schemas.common import (
    AgentRunStatus,
    AgentTaskType,
    ArtifactValidationState,
    CandidateDecisionReason,
    CandidateStatus,
)
from conference_planner.workflows.engine import TaskArtifact


class CandidateRepository:
    def __init__(self, order: list[str]) -> None:
        self.order = order
        self.skipped = SimpleNamespace(
            id=21,
            status=CandidateStatus.SKIPPED,
            decision_reason=CandidateDecisionReason.USER_DEFERRED,
        )

    async def list_candidates_by_statuses(self, _user_id, statuses, *, limit=100):
        self.order.append("decisions")
        if CandidateStatus.SKIPPED in statuses:
            return [self.skipped]
        return []


class Monitoring:
    def __init__(self, order: list[str], *, fail: bool = False, gate=None) -> None:
        self.order = order
        self.fail = fail
        self.gate = gate
        self.calls = 0

    async def run(self, _user_id, *, force=False):
        self.calls += 1
        self.order.append("tracked")
        assert force is True
        if self.gate is not None:
            self.gate.set()
            await asyncio.sleep(0.05)
        if self.fail:
            raise RuntimeError("monitoring unavailable")
        return SimpleNamespace(
            created=[],
            changed=[SimpleNamespace(conference_id=1)],
            conflicts=[],
            unchanged=[],
            changes=[],
            errors=[],
            catalogs=[],
        )


class Research:
    def __init__(
        self,
        order: list[str],
        *,
        new_ids=(31,),
        recheck_error: Exception | None = None,
        search_error: str | None = None,
    ) -> None:
        self.order = order
        self.repository = CandidateRepository(order)
        self.new_ids = new_ids
        self.recheck_error = recheck_error
        self.search_error = search_error
        self.queries: list[str] = []

    async def recheck_skipped(self, _user_id, candidate_id):
        self.order.append(f"recheck:{candidate_id}")
        if self.recheck_error is not None:
            raise self.recheck_error
        return True

    async def search_fresh(
        self, _user_id, query, *, page_limit, results_per_page
    ):
        self.order.append("search")
        self.queries.append(query)
        assert page_limit == 3
        assert results_per_page == 20
        return CandidateSearchReport(
            active_ids=self.new_ids,
            new_ids=self.new_ids,
            pages_checked=2,
            duplicates=4,
            exhausted=not self.new_ids,
            error_code=self.search_error,
        )


def clock() -> ApplicationClock:
    return ApplicationClock.start(
        ZoneInfo("Europe/Moscow"),
        now_provider=lambda: datetime(2026, 10, 20, 9, tzinfo=UTC),
    )


@pytest.mark.asyncio
async def test_cycle_runs_stages_in_order_and_keeps_partial_results(
    session: AsyncSession,
) -> None:
    user = await UserRepository(session).get_or_create_by_telegram_id(8_001)
    order: list[str] = []
    service = ConferenceCycleService(
        AgentWorkflowRepository(session),
        Monitoring(order, fail=True),
        Research(order),
        application_clock=clock(),
    )

    report = await service.run(
        user.id,
        CycleRequest(
            mode=CycleMode.MANUAL,
            query="stellar astronomy 2027",
            page_limit=3,
            results_per_page=20,
        ),
    )

    assert order == ["tracked", "decisions", "recheck:21", "search"]
    assert report.status == AgentRunStatus.COMPLETED
    assert report.reactivated_candidates == 1
    assert report.new_candidate_ids == (31,)
    assert report.duplicates == 4
    assert report.errors == ("TRACKED_CHECK_FAILED",)
    assert report.monitoring_errors == ("TRACKED_CHECK_FAILED",)
    assert report.search_errors == ()
    assert service.research.queries == ["stellar astronomy 2027"]


@pytest.mark.asyncio
async def test_cycle_keeps_search_errors_separate_from_monitoring_errors(
    session: AsyncSession,
) -> None:
    user = await UserRepository(session).get_or_create_by_telegram_id(8_007)
    order: list[str] = []
    service = ConferenceCycleService(
        AgentWorkflowRepository(session),
        Monitoring(order, fail=True),
        Research(order, new_ids=(), search_error="SEARCH_UNAVAILABLE"),
        application_clock=clock(),
    )

    report = await service.run(
        user.id,
        CycleRequest(
            mode=CycleMode.MANUAL,
            query="stellar astronomy 2027",
            page_limit=3,
            results_per_page=20,
        ),
    )

    assert report.monitoring_errors == ("TRACKED_CHECK_FAILED",)
    assert report.search_errors == ("SEARCH_UNAVAILABLE",)
    assert report.errors == ("TRACKED_CHECK_FAILED", "SEARCH_UNAVAILABLE")


@pytest.mark.asyncio
async def test_synthesis_classifies_errors_from_legacy_dependency_artifacts(
    session: AsyncSession,
) -> None:
    service = ConferenceCycleService(
        AgentWorkflowRepository(session),
        Monitoring([]),
        Research([]),
        application_clock=clock(),
    )
    context = SimpleNamespace(
        dependencies={
            "check_tracked": SimpleNamespace(
                artifact_kind="tracked_conference_check",
                payload={"errors": ["ModelGatewayError"]},
            ),
            "search_new": SimpleNamespace(
                artifact_kind="fresh_candidate_search",
                payload={"errors": ["SearchProviderError"]},
            ),
        }
    )
    handler = service._handlers(
        SimpleNamespace(
            user_id=7,
            request=CycleRequest(mode=CycleMode.MANUAL, query="astronomy"),
            queries=("astronomy",),
        )
    )[AgentTaskType.SYNTHESIZE_RESPONSE]

    artifact: TaskArtifact = await handler(context)

    assert artifact.validation_state == ArtifactValidationState.ACCEPTED
    assert artifact.payload["monitoring_errors"] == ["ModelGatewayError"]
    assert artifact.payload["search_errors"] == ["SearchProviderError"]


@pytest.mark.asyncio
async def test_cycle_with_no_new_candidates_completes_successfully(
    session: AsyncSession,
) -> None:
    user = await UserRepository(session).get_or_create_by_telegram_id(8_002)
    order: list[str] = []
    service = ConferenceCycleService(
        AgentWorkflowRepository(session),
        Monitoring(order),
        Research(order, new_ids=()),
        application_clock=clock(),
    )

    report = await service.run(
        user.id,
        CycleRequest(
            mode=CycleMode.MANUAL,
            query="stellar astronomy 2027",
            page_limit=3,
            results_per_page=20,
        ),
    )

    assert report.status == AgentRunStatus.COMPLETED
    assert report.new_candidate_ids == ()
    assert report.errors == ()


@pytest.mark.asyncio
async def test_cycle_replaces_my_topics_instruction_with_saved_topic_terms(
    session: AsyncSession,
) -> None:
    class Topics:
        async def list_for_user(self, _user_id):
            return [
                SimpleNamespace(
                    enabled=True,
                    name="Звёздная спектроскопия",
                    keywords=["stellar atmospheres", "binary stars"],
                ),
                SimpleNamespace(
                    enabled=True,
                    name="Машинное обучение в астрономии",
                    keywords=["astro ML", "spectroscopic binaries"],
                ),
            ]

    user = await UserRepository(session).get_or_create_by_telegram_id(8_005)
    order: list[str] = []
    research = Research(order)
    service = ConferenceCycleService(
        AgentWorkflowRepository(session),
        Monitoring(order),
        research,
        application_clock=clock(),
        topics=Topics(),
    )

    report = await service.run(
        user.id,
        CycleRequest(
            mode=CycleMode.MANUAL,
            query=(
                "Найди релевантные моим темам конференции и добавь их в список "
                "кандидатов, остальные удалить"
            ),
            page_limit=3,
            results_per_page=20,
        ),
    )

    assert report.status == AgentRunStatus.COMPLETED
    assert report.new_candidate_ids == (31,)
    assert research.queries == [
        (
            "Научные конференции 2026-2027: Звёздная спектроскопия; "
            "stellar atmospheres; binary stars"
        ),
        (
            "Научные конференции 2026-2027: Машинное обучение в астрономии; "
            "astro ML; spectroscopic binaries"
        ),
    ]
    assert report.pages_checked == 4


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "expected_outcome",
    [
        CandidateExpiredError("event ended"),
        CandidateUnusableError("candidate is still unusable"),
    ],
)
async def test_cycle_does_not_report_expected_skipped_candidate_outcomes_as_errors(
    session: AsyncSession,
    expected_outcome: Exception,
) -> None:
    user = await UserRepository(session).get_or_create_by_telegram_id(8_006)
    order: list[str] = []
    service = ConferenceCycleService(
        AgentWorkflowRepository(session),
        Monitoring(order),
        Research(order, new_ids=(), recheck_error=expected_outcome),
        application_clock=clock(),
    )

    report = await service.run(
        user.id,
        CycleRequest(
            mode=CycleMode.MANUAL,
            query="stellar astronomy 2027",
            page_limit=3,
            results_per_page=20,
        ),
    )

    assert report.status == AgentRunStatus.COMPLETED
    assert report.reactivated_candidates == 0
    assert report.errors == ()


@pytest.mark.asyncio
async def test_cycle_is_single_flight_per_owner_but_independent_between_owners(
    session: AsyncSession,
) -> None:
    first = await UserRepository(session).get_or_create_by_telegram_id(8_003)
    second = await UserRepository(session).get_or_create_by_telegram_id(8_004)
    gate = asyncio.Event()
    order: list[str] = []
    monitoring = Monitoring(order, gate=gate)
    service = ConferenceCycleService(
        AgentWorkflowRepository(session),
        monitoring,
        Research(order),
        application_clock=clock(),
    )
    request = CycleRequest(
        mode=CycleMode.MANUAL,
        query="stellar astronomy 2027",
        page_limit=3,
        results_per_page=20,
    )

    first_call = asyncio.create_task(service.run(first.id, request))
    await gate.wait()
    duplicate_call = asyncio.create_task(service.run(first.id, request))
    first_report, duplicate_report = await asyncio.gather(
        first_call, duplicate_call
    )
    second_report = await service.run(second.id, request)

    assert first_report.run_id == duplicate_report.run_id
    assert second_report.run_id != first_report.run_id
    assert monitoring.calls == 2
