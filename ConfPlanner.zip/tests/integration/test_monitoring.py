import asyncio
from datetime import UTC, date, datetime, timedelta
from typing import Any

import pytest
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from conference_planner.ai.active_provider import ActiveLLMProvider
from conference_planner.ai.gateway import ModelGatewayError
from conference_planner.ai.models import AvailableModel, ChatMessage, ChatResponse, ToolDefinition
from conference_planner.ai.registry import ProviderProfile
from conference_planner.ai.service import AIService
from conference_planner.app import _model_registry
from conference_planner.conferences.monitoring import MonitoringCheckError, MonitoringService
from conference_planner.db.base import utc_now
from conference_planner.db.migrations import run_migrations
from conference_planner.db.models import (
    Conference,
    ConferenceEvidence,
    Deadline,
    DeadlineHistory,
    EventCandidate,
    MonitoringAttempt,
    Subscription,
    TrustedSource,
    User,
)
from conference_planner.db.repositories.ollama_usage import OllamaUsageRepository
from conference_planner.db.repositories.parser_recipes import ParserRecipeRepository
from conference_planner.db.repositories.web_cache import WebDocumentCacheRepository
from conference_planner.db.session import create_engine_and_sessionmaker
from conference_planner.schemas.common import CandidateStatus, ConferenceStatus, DeadlineType
from conference_planner.schemas.integrations import SearchResult
from conference_planner.schemas.parser_recipes import PageKind, ParserRecipe
from conference_planner.schemas.research import (
    ConferenceCatalogResearch,
    ConferenceResearch,
    VerifiedConferenceResearch,
)
from conference_planner.web.fetcher import FetchedPage, FetchError


class MonitoringFetcher:
    async def fetch(self, url: str, *, max_bytes: int) -> FetchedPage:
        return FetchedPage(
            url,
            "<p>Abstract deadline: 2027-02-19</p>"
            "<p>July 12-16, 2027</p>"
            "<p>Tenerife, Canary Islands, Spain</p>"
            "<p>January 2027: oral contributions close (tentative)</p>"
            "<p>12th of July 2027: ImBaSE2027 starts</p>"
            "<p>13 July 2027</p>",
        )


class MonitoringAI:
    def __init__(self) -> None:
        self.extract_calls = 0
        self.verify_calls = 0

    async def extract_conference_research(self, source_url, _text, expected_name):
        self.extract_calls += 1
        return ConferenceResearch.model_validate(
            {
                "name": expected_name,
                "source_url": source_url,
                "source_class": "OFFICIAL_CONFERENCE",
                "facts": [],
                "deadlines": [
                    {
                        "deadline_type": "ABSTRACT_SUBMISSION",
                        "exact_date": "2027-02-19",
                        "source_url": source_url,
                        "source_class": "OFFICIAL_CONFERENCE",
                        "excerpt": "Abstract deadline: 2027-02-19",
                        "verification_status": "OFFICIAL_CONFIRMED",
                    }
                ],
            }
        )

    async def verify_conference_research(self, research):
        self.verify_calls += 1
        return VerifiedConferenceResearch.model_validate(research.model_dump(mode="json"))


class CapturingMonitoringAI(MonitoringAI):
    def __init__(self) -> None:
        super().__init__()
        self.text = ""

    async def extract_conference_research(self, source_url, text, expected_name):
        self.text = text
        return await super().extract_conference_research(source_url, text, expected_name)


@pytest.mark.asyncio
async def test_catalog_source_is_excluded_from_monitoring(session: AsyncSession) -> None:
    owner = User(telegram_id=7_799)
    catalog = Conference(
        name="Events Catalog",
        normalized_name="events catalog",
        website="https://example.org/events",
        is_catalog_source=True,
    )
    session.add_all([owner, catalog])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=catalog.id))
    await session.commit()
    service = MonitoringService(session, MonitoringFetcher(), MonitoringAI(), 100_000, 50_000)

    with pytest.raises(ValueError, match="tracked conference not found"):
        await service.check_conference(owner.id, catalog.id)

    report = await service.run(owner.id, force=True)
    assert report.created == []
    assert report.changed == []
    assert report.errors == []


class MonitoringGateway:
    async def list_models(self):
        return (AvailableModel(name="gemma4:31b"),)

    async def chat(
        self,
        _model: str,
        _messages: list[ChatMessage],
        _tools: list[ToolDefinition] = (),
        *,
        response_schema: dict[str, Any] | None = None,
    ) -> ChatResponse:
        return ChatResponse(
            content=(
                '{"name":"Astro 2027","aliases":[],'
                '"source_url":"https://event.example/",'
                '"source_class":"OFFICIAL_CONFERENCE","facts":[],"deadlines":['
                '{"deadline_type":"ABSTRACT_SUBMISSION","exact_date":"2027-02-19",'
                '"approximate_year":null,"approximate_month":null,"tentative":false,'
                '"source_url":"https://event.example/",'
                '"source_class":"OFFICIAL_CONFERENCE",'
                '"excerpt":"Abstract deadline: 2027-02-19",'
                '"verification_status":"OFFICIAL_CONFIRMED"}]}'
            ),
            prompt_tokens=13,
            output_tokens=5,
        )


class BootstrapMonitoringAI:
    def __init__(self) -> None:
        self.expected_names: list[str] = []

    async def extract_conference_research(self, source_url, _text, expected_name):
        self.expected_names.append(expected_name)
        return ConferenceResearch.model_validate(
            {
                "name": "ImBaSE 2027",
                "source_url": source_url,
                "source_class": "OFFICIAL_CONFERENCE",
                "facts": [
                    {
                        "kind": "start_date",
                        "value": "2027-07-12",
                        "source_url": source_url,
                        "source_class": "OFFICIAL_CONFERENCE",
                        "excerpt": "July 12-16, 2027",
                        "verification_status": "OFFICIAL_CONFIRMED",
                    },
                    {
                        "kind": "end_date",
                        "value": "2027-07-16",
                        "source_url": source_url,
                        "source_class": "OFFICIAL_CONFERENCE",
                        "excerpt": "July 12-16, 2027",
                        "verification_status": "OFFICIAL_CONFIRMED",
                    },
                    {
                        "kind": "location",
                        "value": "Tenerife, Canary Islands, Spain",
                        "source_url": source_url,
                        "source_class": "OFFICIAL_CONFERENCE",
                        "excerpt": "Tenerife, Canary Islands, Spain",
                        "verification_status": "OFFICIAL_CONFIRMED",
                    },
                ],
                "deadlines": [
                    {
                        "deadline_type": "ORAL_ABSTRACT_SUBMISSION",
                        "approximate_year": 2027,
                        "approximate_month": 1,
                        "tentative": True,
                        "source_url": source_url,
                        "source_class": "OFFICIAL_CONFERENCE",
                        "excerpt": "January 2027: oral contributions close (tentative)",
                        "verification_status": "TENTATIVE",
                    },
                    {
                        "deadline_type": "OTHER",
                        "exact_date": "2027-07-12",
                        "source_url": source_url,
                        "source_class": "OFFICIAL_CONFERENCE",
                        "excerpt": "12th of July 2027: ImBaSE2027 starts",
                        "verification_status": "OFFICIAL_CONFIRMED",
                    },
                ],
            }
        )

    async def verify_conference_research(self, research):
        return VerifiedConferenceResearch.model_validate(research.model_dump(mode="json"))


@pytest.mark.asyncio
async def test_monitoring_bootstraps_placeholder_facts_and_approximate_deadlines(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=900)
    conference = Conference(
        name="ImBaSE 2027",
        normalized_name="imbase 2027",
        website="https://meetings.iac.es/imbase2027/pages/important-dates.php",
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()
    ai = BootstrapMonitoringAI()
    service = MonitoringService(session, MonitoringFetcher(), ai, 100_000, 50_000)

    receipt = await service.check_conference(owner.id, conference.id)

    await session.refresh(conference)
    assert receipt.committed is True
    assert {"start_date", "end_date", "location"} <= set(receipt.created_fields)
    assert conference.start_date == date(2027, 7, 12)
    assert conference.end_date == date(2027, 7, 16)
    assert len(receipt.deadlines) == 2
    assert any(item.approximate_month == 1 and item.tentative for item in receipt.deadlines)
    assert await session.scalar(select(func.count()).select_from(ConferenceEvidence)) == 5
    assert await session.scalar(select(func.count()).select_from(MonitoringAttempt)) == 1
    assert ai.expected_names == ["ImBaSE 2027"]


@pytest.mark.asyncio
async def test_monitoring_updates_exact_tracked_record_when_extracted_identity_differs(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_002)
    conference = Conference(
        name=(
            "IMBASE 2027 (International Meeting on Binary Stars, Exoplanets and "
            "Stellar Astrophysics)"
        ),
        normalized_name=(
            "imbase 2027 international meeting on binary stars exoplanets and stellar astrophysics"
        ),
        website="https://meetings.iac.es/imbase2027/",
        source_url="https://meetings.iac.es/imbase2027/",
    )
    session.add_all([owner, conference])
    await session.flush()
    original_id = conference.id
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()

    class RedirectingFetcher(MonitoringFetcher):
        async def fetch(self, _url: str, *, max_bytes: int) -> FetchedPage:
            return FetchedPage(
                "https://meetings.iac.es/imbase2027/pages/important-dates.php",
                "<p>July 12-16, 2027; January 2027 deadline</p>",
            )

    receipt = await MonitoringService(
        session,
        RedirectingFetcher(),
        BootstrapMonitoringAI(),
        100_000,
        50_000,
    ).check_conference(owner.id, conference.id)

    await session.refresh(conference)
    assert receipt.conference_id == original_id
    assert conference.start_date == date(2027, 7, 12)
    assert await session.scalar(select(func.count()).select_from(Conference)) == 1
    assert "start_date" in receipt.telegram_summary()


class FallbackFetcher:
    def __init__(self, *, official_available: bool) -> None:
        self.official_available = official_available

    async def fetch(self, url: str, *, max_bytes: int):
        if "meetings.iac.es" in url and not self.official_available:
            raise FetchError("page request failed")
        return FetchedPage(
            url,
            "<p>July 12-16, 2027</p>"
            "<p>July 13-17, 2027</p>"
            "<p>Tenerife, Canary Islands, Spain</p>"
            "<p>January 2027: oral contributions close (tentative)</p>"
            "<p>12th of July 2027: ImBaSE2027 starts</p>",
        )


class FallbackSearch:
    def __init__(self) -> None:
        self.queries: list[str] = []

    async def search(self, query: str):
        self.queries.append(query)
        return [
            SearchResult(
                title="ImBaSE 2027",
                url="https://catalog.example/imbase2027",
                snippet="Secondary listing",
            )
        ]


class FallbackAI(BootstrapMonitoringAI):
    async def extract_conference_research(self, source_url, text, expected_name):
        research = await super().extract_conference_research(source_url, text, expected_name)
        if "catalog.example" not in source_url:
            return research
        payload = research.model_dump(mode="json")
        payload["source_class"] = "SECONDARY"
        for fact in payload["facts"]:
            fact["source_class"] = "SECONDARY"
            fact["verification_status"] = "SECONDARY_UNVERIFIED"
            if fact["kind"] == "start_date":
                fact["value"] = "2027-07-13"
                fact["excerpt"] = "July 13-17, 2027"
        for deadline in payload["deadlines"]:
            deadline["source_class"] = "SECONDARY"
            if not deadline["tentative"]:
                deadline["verification_status"] = "SECONDARY_UNVERIFIED"
        return ConferenceResearch.model_validate(payload)


@pytest.mark.asyncio
async def test_monitoring_continues_to_fallback_when_primary_has_no_temporal_data(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_011)
    conference = Conference(
        name="Incomplete Meeting 2027",
        normalized_name="incomplete meeting 2027",
        website="https://official.example/event",
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()

    class Search:
        def __init__(self) -> None:
            self.queries: list[str] = []

        async def search(self, query: str):
            self.queries.append(query)
            return [
                SearchResult(
                    title="Incomplete Meeting 2027 important dates",
                    url="https://dates.example/event",
                    snippet="July 12-16, 2027; abstract deadline January 2027",
                )
            ]

    class AI(BootstrapMonitoringAI):
        async def extract_conference_research(self, source_url, text, expected_name):
            if "official.example" in source_url:
                return ConferenceResearch.model_validate(
                    {
                        "name": expected_name,
                        "source_url": source_url,
                        "source_class": "OFFICIAL_CONFERENCE",
                        "facts": [],
                        "deadlines": [],
                    }
                )
            return await super().extract_conference_research(source_url, text, expected_name)

    search = Search()
    receipt = await MonitoringService(
        session,
        FallbackFetcher(official_available=True),
        AI(),
        100_000,
        50_000,
        search,
    ).check_conference(owner.id, conference.id)

    await session.refresh(conference)
    assert search.queries
    assert conference.start_date == date(2027, 7, 12)
    assert conference.end_date == date(2027, 7, 16)
    assert receipt.deadlines


@pytest.mark.asyncio
async def test_monitoring_does_not_call_non_temporal_result_current(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_012)
    conference = Conference(
        name="Undated Meeting",
        normalized_name="undated meeting",
        website="https://official.example/event",
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()

    class NoTemporalAI(BootstrapMonitoringAI):
        async def extract_conference_research(self, source_url, _text, expected_name):
            return ConferenceResearch.model_validate(
                {
                    "name": expected_name,
                    "source_url": source_url,
                    "source_class": "OFFICIAL_CONFERENCE",
                    "facts": [
                        {
                            "kind": "location",
                            "value": "Tenerife",
                            "source_url": source_url,
                            "source_class": "OFFICIAL_CONFERENCE",
                            "excerpt": "Tenerife",
                            "verification_status": "OFFICIAL_CONFIRMED",
                        }
                    ],
                    "deadlines": [],
                }
            )

    service = MonitoringService(
        session,
        FallbackFetcher(official_available=True),
        NoTemporalAI(),
        100_000,
        50_000,
    )

    with pytest.raises(MonitoringCheckError, match="NO_TEMPORAL_DATA"):
        await service.check_conference(owner.id, conference.id)

    attempt = await session.scalar(
        select(MonitoringAttempt).where(MonitoringAttempt.conference_id == conference.id)
    )
    assert attempt is not None
    assert attempt.status.value == "FAILED"
    assert attempt.error_code == "NO_TEMPORAL_DATA"


@pytest.mark.asyncio
async def test_monitoring_tries_common_important_dates_child_after_root_failure(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_013)
    conference = Conference(
        name="ImBaSE 2027",
        normalized_name="imbase 2027",
        website="https://meetings.iac.es/imbase2027/",
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()

    class ChildPageFetcher:
        def __init__(self) -> None:
            self.urls: list[str] = []

        async def fetch(self, url: str, *, max_bytes: int):
            self.urls.append(url)
            if not url.endswith("/pages/important-dates.php"):
                raise FetchError("TLS certificate failure", code="NETWORK_ERROR")
            return FetchedPage(
                url,
                "<p>July 12-16, 2027</p>"
                "<p>January 2027: oral contributions close (tentative)</p>"
                "<p>12th of July 2027: ImBaSE2027 starts</p>",
            )

    fetcher = ChildPageFetcher()
    receipt = await MonitoringService(
        session,
        fetcher,
        BootstrapMonitoringAI(),
        100_000,
        50_000,
    ).check_conference(owner.id, conference.id)

    await session.refresh(conference)
    assert fetcher.urls[:2] == [
        "https://meetings.iac.es/imbase2027/",
        "https://meetings.iac.es/imbase2027/pages/important-dates.php",
    ]
    assert conference.start_date == date(2027, 7, 12)
    assert receipt.deadlines


@pytest.mark.asyncio
async def test_monitoring_continues_from_event_dates_to_deadline_page(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_016)
    root_url = "https://meetings.iac.es/imbase2027/"
    conference = Conference(
        name="ImBaSE 2027",
        normalized_name="imbase 2027",
        website=root_url,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()

    class PagesFetcher:
        async def fetch(self, url: str, *, max_bytes: int):
            if url == root_url:
                return FetchedPage(url, "<p>July 12-16, 2027</p>")
            if url.endswith("/pages/important-dates.php"):
                return FetchedPage(
                    url,
                    "<p>January 2027: oral contributions close (tentative)</p>",
                )
            raise FetchError("not found", code="HTTP_404")

    class SplitPageAI(BootstrapMonitoringAI):
        async def extract_conference_research(self, source_url, text, expected_name):
            if source_url == root_url:
                return ConferenceResearch.model_validate(
                    {
                        "name": expected_name,
                        "source_url": source_url,
                        "source_class": "OFFICIAL_CONFERENCE",
                        "facts": [
                            {
                                "kind": "start_date",
                                "value": "2027-07-12",
                                "source_url": source_url,
                                "source_class": "OFFICIAL_CONFERENCE",
                                "excerpt": "July 12-16, 2027",
                                "verification_status": "OFFICIAL_CONFIRMED",
                            },
                            {
                                "kind": "end_date",
                                "value": "2027-07-16",
                                "source_url": source_url,
                                "source_class": "OFFICIAL_CONFERENCE",
                                "excerpt": "July 12-16, 2027",
                                "verification_status": "OFFICIAL_CONFIRMED",
                            },
                        ],
                        "deadlines": [],
                    }
                )
            return ConferenceResearch.model_validate(
                {
                    "name": expected_name,
                    "source_url": source_url,
                    "source_class": "OFFICIAL_CONFERENCE",
                    "facts": [],
                    "deadlines": [
                        {
                            "deadline_type": "ORAL_ABSTRACT_SUBMISSION",
                            "approximate_year": 2027,
                            "approximate_month": 1,
                            "tentative": True,
                            "source_url": source_url,
                            "source_class": "OFFICIAL_CONFERENCE",
                            "excerpt": ("January 2027: oral contributions close (tentative)"),
                            "verification_status": "TENTATIVE",
                        }
                    ],
                }
            )

    receipt = await MonitoringService(
        session,
        PagesFetcher(),
        SplitPageAI(),
        100_000,
        50_000,
    ).check_conference(owner.id, conference.id)

    await session.refresh(conference)
    assert conference.start_date == date(2027, 7, 12)
    assert conference.end_date == date(2027, 7, 16)
    assert any(
        item.deadline_type == DeadlineType.ORAL_ABSTRACT_SUBMISSION for item in receipt.deadlines
    )


@pytest.mark.asyncio
async def test_monitoring_uses_cached_official_text_when_live_tls_fails(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_014)
    url = "https://meetings.iac.es/imbase2027/"
    conference = Conference(
        name="ImBaSE 2027",
        normalized_name="imbase 2027",
        website=url,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    cache = WebDocumentCacheRepository(session)
    await cache.store(
        FetchedPage(url, "<p>cached</p>", content_hash="cached-hash"),
        "July 12-16, 2027\nJanuary 2027: oral contributions close (tentative)\n"
        "12th of July 2027: ImBaSE2027 starts",
    )
    await session.commit()

    class TLSFailingFetcher:
        async def fetch(self, _url: str, *, max_bytes: int, **_kwargs):
            raise FetchError("TLS certificate failure", code="NETWORK_ERROR")

    receipt = await MonitoringService(
        session,
        TLSFailingFetcher(),
        BootstrapMonitoringAI(),
        100_000,
        50_000,
        cache=cache,
    ).check_conference(owner.id, conference.id)

    await session.refresh(conference)
    assert conference.start_date == date(2027, 7, 12)
    assert receipt.deadlines


@pytest.mark.asyncio
async def test_monitoring_extracts_secondary_dates_from_search_card_when_pages_fail(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_015)
    url = "https://meetings.iac.es/imbase2027/"
    conference = Conference(
        name="ImBaSE 2027",
        normalized_name="imbase 2027",
        website=url,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()

    class TLSFailingFetcher:
        async def fetch(self, _url: str, *, max_bytes: int):
            raise FetchError("TLS certificate failure", code="NETWORK_ERROR")

    class Search:
        async def search(self, _query: str):
            return [
                SearchResult(
                    title="ImBaSE2027 – The Impact of Binaries on Stellar Evolution",
                    url=url,
                    snippet=(
                        "July 12-16, 2027. January 2027: oral contributions close "
                        "(tentative). 12th of July 2027: ImBaSE2027 starts."
                    ),
                )
            ]

    receipt = await MonitoringService(
        session,
        TLSFailingFetcher(),
        BootstrapMonitoringAI(),
        100_000,
        50_000,
        Search(),
    ).check_conference(owner.id, conference.id)

    await session.refresh(conference)
    assert conference.start_date == date(2027, 7, 12)
    assert receipt.deadlines


@pytest.mark.asyncio
async def test_monitoring_uses_secondary_fallback_then_official_source_wins(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=901)
    conference = Conference(
        name="ImBaSE 2027",
        normalized_name="imbase 2027",
        website="https://meetings.iac.es/imbase2027/",
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()
    search = FallbackSearch()
    ai = FallbackAI()

    await MonitoringService(
        session, FallbackFetcher(official_available=False), ai, 100_000, 50_000, search
    ).check_conference(owner.id, conference.id)
    await session.refresh(conference)
    assert conference.start_date == date(2027, 7, 13)
    assert "ImBaSE 2027" in search.queries[0]

    receipt = await MonitoringService(
        session, FallbackFetcher(official_available=True), ai, 100_000, 50_000, search
    ).check_conference(owner.id, conference.id)
    await session.refresh(conference)
    assert conference.start_date == date(2027, 7, 12)
    assert "start_date" in receipt.updated_fields


@pytest.mark.asyncio
async def test_monitoring_reuses_saved_evidence_and_deadline_sources(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=905)
    conference = Conference(name="Saved Sources", normalized_name="saved sources")
    session.add_all([owner, conference])
    await session.flush()
    session.add_all(
        [
            Subscription(user_id=owner.id, conference_id=conference.id),
            ConferenceEvidence(
                conference_id=conference.id,
                fact_kind="location",
                fact_value="Tenerife",
                source_url="https://evidence.example/event",
                source_class="OFFICIAL_ORGANIZER",
                excerpt="Tenerife",
                verification_status="ORGANIZER_CONFIRMED",
                observed_at=utc_now(),
            ),
            Deadline(
                conference_id=conference.id,
                deadline_type="ABSTRACT_SUBMISSION",
                approximate_year=2027,
                approximate_month=1,
                source_url="https://deadline.example/dates",
            ),
        ]
    )
    await session.commit()

    class RecordingFetcher(MonitoringFetcher):
        def __init__(self) -> None:
            self.urls: list[str] = []

        async def fetch(self, url: str, *, max_bytes: int) -> FetchedPage:
            self.urls.append(url)
            if "evidence.example" in url:
                raise FetchError("try the next saved source")
            return await super().fetch(url, max_bytes=max_bytes)

    fetcher = RecordingFetcher()
    await MonitoringService(session, fetcher, MonitoringAI(), 100_000, 50_000).check_conference(
        owner.id, conference.id
    )

    assert fetcher.urls == [
        "https://evidence.example/event",
        "https://deadline.example/dates",
    ]


@pytest.mark.asyncio
async def test_monitoring_report_separates_conflicts(session: AsyncSession) -> None:
    owner = User(telegram_id=906)
    conference = Conference(
        name="Conflict Meeting",
        normalized_name="conflict meeting",
        website="https://event.example/",
        start_date=date(2027, 7, 12),
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add_all(
        [
            Subscription(user_id=owner.id, conference_id=conference.id),
            ConferenceEvidence(
                conference_id=conference.id,
                fact_kind="start_date",
                fact_value="2027-07-12",
                source_url="https://first-official.example/",
                source_class="OFFICIAL_CONFERENCE",
                excerpt="12 July 2027",
                verification_status="OFFICIAL_CONFIRMED",
                observed_at=utc_now(),
            ),
        ]
    )
    await session.commit()

    class ConflictAI(MonitoringAI):
        async def extract_conference_research(self, source_url, _text, expected_name):
            return ConferenceResearch.model_validate(
                {
                    "name": expected_name,
                    "source_url": source_url,
                    "source_class": "OFFICIAL_CONFERENCE",
                    "facts": [
                        {
                            "kind": "start_date",
                            "value": "2027-07-13",
                            "source_url": source_url,
                            "source_class": "OFFICIAL_CONFERENCE",
                            "excerpt": "13 July 2027",
                            "verification_status": "OFFICIAL_CONFIRMED",
                        }
                    ],
                    "deadlines": [],
                }
            )

    report = await MonitoringService(
        session, MonitoringFetcher(), ConflictAI(), 100_000, 50_000
    ).run(owner.id)

    assert [item.conference_id for item in report.conflicts] == [conference.id]
    assert report.unchanged == []


@pytest.mark.asyncio
async def test_monitoring_counts_prolonged_sanitized_failures(session: AsyncSession) -> None:
    owner = User(telegram_id=902)
    other_owner = User(telegram_id=9_902)
    conference = Conference(
        name="Unavailable Meeting",
        normalized_name="unavailable meeting",
        website="https://unavailable.example/",
    )
    session.add_all([owner, other_owner, conference])
    await session.flush()
    session.add_all(
        [
            Subscription(user_id=owner.id, conference_id=conference.id),
            Subscription(user_id=other_owner.id, conference_id=conference.id),
            MonitoringAttempt(
                user_id=other_owner.id,
                conference_id=conference.id,
                status="FAILED",
                error_code="OTHER_OWNER_FAILURE",
            ),
        ]
    )
    await session.commit()
    service = MonitoringService(
        session, FallbackFetcher(official_available=False), BootstrapMonitoringAI(), 10_000, 10_000
    )
    service.fetcher.fetch = lambda *_args, **_kwargs: (_ for _ in ()).throw(
        FetchError("secret network detail")
    )

    reports = [await service.run(owner.id) for _ in range(3)]

    assert [item.errors[0].consecutive_failures for item in reports] == [1, 2, 3]
    assert all(item.errors[0].error_code == "FetchError" for item in reports)


@pytest.mark.asyncio
async def test_monitoring_preserves_safe_fetch_failure_code(session: AsyncSession) -> None:
    owner = User(telegram_id=9030)
    conference = Conference(
        name="Forbidden Meeting",
        normalized_name="forbidden meeting",
        website="https://forbidden.example/",
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()
    service = MonitoringService(
        session, FallbackFetcher(official_available=False), BootstrapMonitoringAI(), 10_000, 10_000
    )
    service.fetcher.fetch = lambda *_args, **_kwargs: (_ for _ in ()).throw(
        FetchError("request rejected", code="HTTP_403")
    )

    report = await service.run(owner.id)

    assert report.errors[0].error_code == "HTTP_403"


@pytest.mark.asyncio
async def test_manual_and_scheduled_checks_are_idempotent(tmp_path) -> None:
    database_url = f"sqlite+aiosqlite:///{tmp_path / 'monitoring-concurrent.db'}"
    run_migrations(database_url)
    engine, factory = create_engine_and_sessionmaker(database_url)
    try:
        async with factory() as setup:
            owner = User(telegram_id=903)
            conference = Conference(
                name="ImBaSE 2027",
                normalized_name="imbase 2027",
                website="https://meetings.iac.es/imbase2027/",
            )
            setup.add_all([owner, conference])
            await setup.flush()
            setup.add(Subscription(user_id=owner.id, conference_id=conference.id))
            await setup.commit()
            owner_id, conference_id = owner.id, conference.id

        async with factory() as manual_session, factory() as scheduled_session:
            manual = MonitoringService(
                manual_session, MonitoringFetcher(), BootstrapMonitoringAI(), 100_000, 50_000
            )
            scheduled = MonitoringService(
                scheduled_session, MonitoringFetcher(), BootstrapMonitoringAI(), 100_000, 50_000
            )
            await asyncio.gather(
                manual.check_conference(owner_id, conference_id),
                scheduled.check_conference(owner_id, conference_id),
            )

        async with factory() as verify:
            assert await verify.scalar(select(func.count()).select_from(Deadline)) == 2
            assert await verify.scalar(select(func.count()).select_from(DeadlineHistory)) == 0
    finally:
        await engine.dispose()


@pytest.mark.asyncio
async def test_monitoring_updates_deadline_history_and_requests_notification(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=123)
    conference = Conference(
        name="Astro 2027",
        normalized_name="astro 2027",
        website="https://event.example/",
        status=ConferenceStatus.TRACKING,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    session.add(
        Deadline(
            conference_id=conference.id,
            deadline_type=DeadlineType.ABSTRACT_SUBMISSION,
            deadline_date=date(2027, 2, 12),
            source_url="https://event.example/dates",
            verified=True,
        )
    )
    await session.commit()

    report = await MonitoringService(
        session, MonitoringFetcher(), MonitoringAI(), 10_000, 10_000
    ).run(owner.id)

    assert len(report.changes) == 1
    assert report.changes[0].old_date == date(2027, 2, 12)
    assert report.changes[0].new_date == date(2027, 2, 19)
    assert await session.scalar(select(func.count()).select_from(DeadlineHistory)) == 1


@pytest.mark.asyncio
async def test_ollama_usage_counts_only_required_monitoring_structured_calls(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=890)
    conference = Conference(
        name="Astro 2027",
        normalized_name="astro 2027",
        website="https://event.example/",
        status=ConferenceStatus.TRACKING,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    session.add(
        Deadline(
            conference_id=conference.id,
            deadline_type=DeadlineType.ABSTRACT_SUBMISSION,
            deadline_date=date(2027, 2, 12),
            source_url="https://event.example/dates",
            verified=True,
        )
    )
    gateway = MonitoringGateway()
    registry = _model_registry(
        session,
        (ProviderProfile("ollama-cloud", "Ollama Cloud", gateway, ("gemma4:31b",)),),
    )
    await registry.select(owner.id, "ollama-cloud", "gemma4:31b")

    await MonitoringService(
        session,
        MonitoringFetcher(),
        AIService(ActiveLLMProvider(registry, owner.id)),
        10_000,
        10_000,
    ).run(owner.id)
    rows = await OllamaUsageRepository(session).get_daily_totals(
        owner.id, "ollama-cloud", datetime.now(UTC).date()
    )

    assert rows[0].request_count == 1
    assert rows[0].prompt_tokens == 13


class ConditionalMonitoringFetcher:
    def __init__(self, pages: list[FetchedPage]) -> None:
        self.pages = pages
        self.calls: list[tuple[str | None, str | None]] = []

    async def fetch(
        self,
        _url: str,
        *,
        max_bytes: int,
        etag: str | None = None,
        last_modified: str | None = None,
    ) -> FetchedPage:
        self.calls.append((etag, last_modified))
        return self.pages.pop(0)


@pytest.mark.asyncio
async def test_monitoring_skips_model_for_http_304_and_unchanged_hash(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_100)
    conference = Conference(
        name="Cached Meeting",
        normalized_name="cached meeting",
        website="https://event.example/",
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()
    fetcher = ConditionalMonitoringFetcher(
        [
            FetchedPage(
                "https://event.example/",
                "<p>Abstract deadline: 2027-02-19</p>",
                etag='"v1"',
                content_hash="same-hash",
            ),
            FetchedPage(
                "https://event.example/",
                "",
                status_code=304,
                etag='"v1"',
                content_hash="",
                not_modified=True,
            ),
            FetchedPage(
                "https://event.example/",
                "<p>Abstract deadline: 2027-02-19</p>",
                etag='"v1"',
                content_hash="same-hash",
            ),
        ]
    )
    ai = MonitoringAI()
    cache = WebDocumentCacheRepository(session)
    service = MonitoringService(
        session,
        fetcher,
        ai,
        100_000,
        50_000,
        cache=cache,
    )

    await service.check_conference(owner.id, conference.id)
    second = await service.check_conference(owner.id, conference.id)
    third = await service.check_conference(owner.id, conference.id)

    assert ai.extract_calls == 1
    assert second.updated_fields == ()
    assert third.updated_fields == ()
    assert fetcher.calls == [(None, None), ('"v1"', None), ('"v1"', None)]


@pytest.mark.asyncio
async def test_monitoring_changed_html_with_same_etag_runs_model(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_101)
    conference = Conference(
        name="Changed Meeting",
        normalized_name="changed meeting",
        website="https://event.example/",
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()
    fetcher = ConditionalMonitoringFetcher(
        [
            FetchedPage(
                "https://event.example/",
                "<p>Old page. Abstract deadline: 2027-02-19</p>",
                etag='"v1"',
                content_hash="old-hash",
            ),
            FetchedPage(
                "https://event.example/",
                "<p>New page. Abstract deadline: 2027-02-19</p>",
                etag='"v1"',
                content_hash="new-hash",
            ),
        ]
    )
    ai = MonitoringAI()
    service = MonitoringService(
        session,
        fetcher,
        ai,
        100_000,
        50_000,
        cache=WebDocumentCacheRepository(session),
    )

    await service.check_conference(owner.id, conference.id)
    await service.check_conference(owner.id, conference.id)

    assert ai.extract_calls == 2


@pytest.mark.asyncio
async def test_unchanged_cache_is_reanalyzed_when_conference_has_no_temporal_data(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_106)
    url = "https://event.example/important-dates"
    conference = Conference(
        name="Cached Empty Meeting",
        normalized_name="cached empty meeting",
        website=url,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    cache = WebDocumentCacheRepository(session)
    await cache.store(
        FetchedPage(
            url,
            "<p>Abstract deadline: 2027-02-19</p>",
            etag='"v1"',
            content_hash="same-hash",
        ),
        "Abstract deadline: 2027-02-19",
    )
    await session.commit()
    fetcher = ConditionalMonitoringFetcher(
        [
            FetchedPage(
                url,
                "",
                status_code=304,
                etag='"v1"',
                not_modified=True,
            )
        ]
    )
    ai = MonitoringAI()

    receipt = await MonitoringService(
        session,
        fetcher,
        ai,
        100_000,
        50_000,
        cache=cache,
    ).check_conference(owner.id, conference.id)

    assert ai.extract_calls == 1
    assert len(receipt.deadlines) == 1


@pytest.mark.asyncio
async def test_cached_catalog_http_304_refetches_links_before_analysis(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_111)
    url = "https://www.eso.org/sci/meetings/2027.html"
    conference = Conference(
        name="ESO Meetings 2027",
        normalized_name="eso meetings 2027",
        website=url,
        status=ConferenceStatus.TRACKING,
        start_date=date(2027, 1, 1),
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    cache = WebDocumentCacheRepository(session)
    await cache.store(
        FetchedPage(
            url,
            "<main>cached catalog text</main>",
            etag='"v1"',
            content_hash="same-hash",
        ),
        "cached catalog text",
    )
    await session.commit()
    html = """<main>
        <a href="/sci/meetings/2027/white-dwarf-binaries.html">
        Probing the cosmos with white dwarf binaries</a>
        <a href="/sci/meetings/2027/galmeet.html">When galaxies meet</a>
    </main>"""
    fetcher = ConditionalMonitoringFetcher(
        [
            FetchedPage(
                url,
                "",
                status_code=304,
                etag='"v1"',
                not_modified=True,
            ),
            FetchedPage(url, html, etag='"v1"', content_hash="same-hash"),
        ]
    )

    class EmptyCatalogAI(MonitoringAI):
        async def extract_conference_catalog(self, _source_url: str, _text: str):
            return ConferenceCatalogResearch(events=())

    conversion = await MonitoringService(
        session,
        fetcher,
        EmptyCatalogAI(),
        100_000,
        50_000,
        cache=cache,
    ).check_conference(owner.id, conference.id)

    await session.refresh(conference)
    assert len(conversion.candidate_ids) == 2
    assert fetcher.calls == [('"v1"', None), (None, None)]
    assert conference.start_date is None
    assert conference.end_date is None


@pytest.mark.asyncio
async def test_catalog_is_never_persisted_as_one_conference_when_links_are_missing(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_112)
    url = "https://www.sai.msu.ru/conference/annconf/index.html"
    conference = Conference(
        name="Объявления о конференциях - ГАИШ - МГУ",
        normalized_name="объявления о конференциях гаиш мгу",
        website=url,
        status=ConferenceStatus.TRACKING,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()

    class CatalogWithoutLinksFetcher:
        async def fetch(self, source_url: str, *, max_bytes: int, **_kwargs):
            return FetchedPage(
                source_url,
                "<main><h1>Объявления о конференциях - ГАИШ - МГУ</h1>"
                "<p>Конференция состоится 3-5 ноября 2026 г.</p></main>",
            )

    class EmptyCatalogAI(MonitoringAI):
        async def extract_conference_catalog(self, _source_url: str, _text: str):
            return ConferenceCatalogResearch(events=())

    with pytest.raises(MonitoringCheckError, match="NO_TEMPORAL_DATA"):
        await MonitoringService(
            session,
            CatalogWithoutLinksFetcher(),
            EmptyCatalogAI(),
            100_000,
            50_000,
        ).check_conference(owner.id, conference.id)

    await session.refresh(conference)
    assert conference.start_date is None
    assert conference.end_date is None


@pytest.mark.asyncio
async def test_catalog_record_becomes_source_and_concrete_candidates(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_107)
    url = "https://www.eso.org/sci/meetings/2027.html"
    conference = Conference(
        name="ESO Meetings 2027",
        normalized_name="eso meetings 2027",
        website=url,
        source_url=url,
        status=ConferenceStatus.TRACKING,
    )
    session.add_all([owner, conference])
    await session.flush()
    subscription = Subscription(user_id=owner.id, conference_id=conference.id)
    session.add(subscription)
    await session.commit()

    class CatalogFetcher:
        async def fetch(self, source_url: str, *, max_bytes: int, **_kwargs):
            return FetchedPage(
                source_url,
                """<main>
                <a href="/sci/meetings/2027/white-dwarf-binaries.html">
                Probing the cosmos with white dwarf binaries</a>
                <p>26 - 30 July 2027</p>
                <a href="/sci/meetings/2027/weaving.html">Weaving the Cosmic Web</a>
                <p>24 - 27 May 2027</p>
                </main>""",
            )

    class CatalogAI(MonitoringAI):
        async def extract_conference_catalog(self, source_url: str, _text: str):
            def event(name: str, start: str, excerpt: str) -> dict[str, Any]:
                return {
                    "name": name,
                    "source_url": source_url,
                    "source_class": "OFFICIAL_ORGANIZER",
                    "facts": [
                        {
                            "kind": "start_date",
                            "value": start,
                            "source_url": source_url,
                            "source_class": "OFFICIAL_ORGANIZER",
                            "excerpt": excerpt,
                            "verification_status": "ORGANIZER_CONFIRMED",
                        }
                    ],
                    "deadlines": [],
                }

            return ConferenceCatalogResearch.model_validate(
                {
                    "events": [
                        event(
                            "Probing the cosmos with white dwarf binaries",
                            "2027-07-26",
                            "26 - 30 July 2027",
                        ),
                        event(
                            "Weaving the Cosmic Web",
                            "2027-05-24",
                            "24 - 27 May 2027",
                        ),
                    ]
                }
            )

    conversion = await MonitoringService(
        session,
        CatalogFetcher(),
        CatalogAI(),
        100_000,
        50_000,
    ).check_conference(owner.id, conference.id)

    await session.refresh(conference)
    candidates = list(
        await session.scalars(
            select(EventCandidate)
            .where(
                EventCandidate.user_id == owner.id,
                EventCandidate.status == CandidateStatus.ACTIVE,
            )
            .order_by(EventCandidate.id)
        )
    )
    source = await session.scalar(select(TrustedSource).where(TrustedSource.url == url))
    assert conversion.candidate_ids == tuple(item.id for item in candidates)
    assert [item.title for item in candidates] == [
        "Probing the cosmos with white dwarf binaries",
        "Weaving the Cosmic Web",
    ]
    assert candidates[0].source_url.endswith("white-dwarf-binaries.html")
    assert candidates[1].source_url.endswith("weaving.html")
    assert (candidates[0].start_date, candidates[0].end_date) == (
        date(2027, 7, 26),
        date(2027, 7, 30),
    )
    assert candidates[0].research_payload is not None
    assert candidates[0].researched_at is None
    assert candidates[0].summary == "26 - 30 July 2027"
    assert source is not None
    assert await session.get(Subscription, subscription.id) is None
    assert conference.status == ConferenceStatus.ARCHIVED
    assert conference.is_catalog_source is True


@pytest.mark.asyncio
async def test_monitoring_persists_dates_when_model_returns_empty_arrays(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_108)
    url = "https://www.iau.org/meeting/2027"
    conference = Conference(
        name="XXXIII IAU General Assembly",
        normalized_name="xxxiii iau general assembly",
        website=url,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()

    class IAUFetcher:
        async def fetch(self, source_url: str, *, max_bytes: int, **_kwargs):
            return FetchedPage(
                source_url,
                "<main><h1>XXXIII IAU General Assembly</h1>"
                "<p>10 - 19 August 2027, Rome, Italy</p></main>",
            )

    class EmptyAI(MonitoringAI):
        async def extract_conference_research(self, source_url, _text, expected_name):
            return ConferenceResearch.model_validate(
                {
                    "name": expected_name,
                    "source_url": source_url,
                    "source_class": "OFFICIAL_CONFERENCE",
                    "facts": [],
                    "deadlines": [],
                }
            )

    receipt = await MonitoringService(
        session, IAUFetcher(), EmptyAI(), 100_000, 50_000
    ).check_conference(owner.id, conference.id)

    await session.refresh(conference)
    assert receipt.committed is True
    assert conference.start_date == date(2027, 8, 10)
    assert conference.end_date == date(2027, 8, 19)


@pytest.mark.asyncio
async def test_monitoring_persists_explicit_deadlines_when_model_gateway_fails(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_109)
    url = "https://meetings.iac.es/imbase2027/pages/important-dates.php"
    conference = Conference(
        name="IMBASE 2027",
        normalized_name="imbase 2027",
        website=url,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()

    class ImportantDatesFetcher:
        async def fetch(self, source_url: str, *, max_bytes: int, **_kwargs):
            return FetchedPage(
                source_url,
                "<main><p>November 2026: Registration and abstract submission opens</p>"
                "<p>January 2027: Abstract submission for oral contributions closes</p>"
                "<p>12th of July 2027: ImBaSE2027 starts</p>"
                "<p>These dates, aside from the conference week, are tentative</p></main>",
            )

    class FailingAI(MonitoringAI):
        async def extract_conference_research(self, *_args):
            raise ModelGatewayError("private upstream failure")

    receipt = await MonitoringService(
        session, ImportantDatesFetcher(), FailingAI(), 100_000, 50_000
    ).check_conference(owner.id, conference.id)

    await session.refresh(conference)
    deadlines = await session.scalars(
        select(Deadline).where(Deadline.conference_id == conference.id)
    )
    assert receipt.committed is True
    assert conference.start_date == date(2027, 7, 12)
    assert [(item.approximate_year, item.approximate_month) for item in deadlines] == [
        (2026, 11),
        (2027, 1),
    ]


@pytest.mark.asyncio
async def test_catalog_links_become_candidates_when_model_catalog_is_empty(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_110)
    url = "https://www.eso.org/sci/meetings/2027.html"
    conference = Conference(
        name="ESO Meetings 2027",
        normalized_name="eso meetings 2027",
        website=url,
        status=ConferenceStatus.TRACKING,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()

    class CatalogFetcher:
        async def fetch(self, source_url: str, *, max_bytes: int, **_kwargs):
            return FetchedPage(
                source_url,
                """<main>
                <a href="/sci/meetings/2027/white-dwarf-binaries.html">
                Probing the cosmos with white dwarf binaries</a>
                <a href="/sci/meetings/2027/galmeet.html">When galaxies meet</a>
                </main>""",
            )

    class EmptyCatalogAI(MonitoringAI):
        async def extract_conference_catalog(self, _source_url: str, _text: str):
            return ConferenceCatalogResearch(events=())

    conversion = await MonitoringService(
        session, CatalogFetcher(), EmptyCatalogAI(), 100_000, 50_000
    ).check_conference(owner.id, conference.id)

    candidates = list(
        await session.scalars(
            select(EventCandidate)
            .where(EventCandidate.user_id == owner.id)
            .order_by(EventCandidate.id)
        )
    )
    assert conversion.candidate_ids == tuple(item.id for item in candidates)
    assert [item.title for item in candidates] == [
        "Probing the cosmos with white dwarf binaries",
        "When galaxies meet",
    ]


@pytest.mark.asyncio
async def test_scheduled_monitoring_checks_only_conferences_due_at_72_hours(
    session: AsyncSession,
) -> None:
    now = datetime(2026, 10, 18, 9, tzinfo=UTC)
    owner = User(telegram_id=9_102)
    recent = Conference(
        name="Recent Meeting",
        normalized_name="recent meeting",
        website="https://recent.example/",
        last_checked_at=now - timedelta(hours=71),
    )
    due = Conference(
        name="Due Meeting",
        normalized_name="due meeting",
        website="https://due.example/",
        last_checked_at=now - timedelta(hours=72),
    )
    session.add_all([owner, recent, due])
    await session.flush()
    session.add_all(
        [
            Subscription(user_id=owner.id, conference_id=recent.id),
            Subscription(user_id=owner.id, conference_id=due.id),
        ]
    )
    await session.commit()
    fetcher = ConditionalMonitoringFetcher(
        [
            FetchedPage(
                "https://due.example/",
                "<p>Abstract deadline: 2027-02-19</p>",
                content_hash="due-hash",
            )
        ]
    )
    service = MonitoringService(
        session,
        fetcher,
        MonitoringAI(),
        100_000,
        50_000,
        monitoring_interval_hours=72,
        now_factory=lambda: now,
    )

    report = await service.run(owner.id)

    assert len(report.created) == 1
    assert report.created[0].conference_id == due.id
    assert len(fetcher.calls) == 1


@pytest.mark.asyncio
async def test_manual_monitoring_bypasses_72_hour_interval(session: AsyncSession) -> None:
    now = datetime(2026, 10, 18, 9, tzinfo=UTC)
    owner = User(telegram_id=9_103)
    conference = Conference(
        name="Manual Meeting",
        normalized_name="manual meeting",
        website="https://manual.example/",
        last_checked_at=now,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()
    fetcher = ConditionalMonitoringFetcher(
        [
            FetchedPage(
                "https://manual.example/",
                "<p>Manual. Abstract deadline: 2027-02-19</p>",
                content_hash="manual-hash",
            )
        ]
    )
    service = MonitoringService(
        session,
        fetcher,
        MonitoringAI(),
        100_000,
        50_000,
        monitoring_interval_hours=72,
        now_factory=lambda: now,
    )

    await service.check_conference(owner.id, conference.id)

    assert len(fetcher.calls) == 1


@pytest.mark.asyncio
async def test_monitoring_reuses_active_parser_recipe(session: AsyncSession) -> None:
    owner = User(telegram_id=9_104)
    conference = Conference(
        name="Recipe Meeting",
        normalized_name="recipe meeting",
        website="https://event.example/",
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    recipes = ParserRecipeRepository(session)
    stored = await recipes.propose(
        ParserRecipe(
            domain="event.example",
            page_kind=PageKind.DETAIL,
            field_selectors={"deadlines": ".important-date"},
        )
    )
    await recipes.activate_after_validation(stored.id)
    await session.commit()
    fetcher = ConditionalMonitoringFetcher(
        [
            FetchedPage(
                "https://event.example/",
                '<div class="important-date">Abstract deadline: 2027-02-19</div>',
                content_hash="recipe-hash",
            )
        ]
    )
    ai = CapturingMonitoringAI()

    await MonitoringService(
        session,
        fetcher,
        ai,
        100_000,
        50_000,
        recipes=recipes,
    ).check_conference(owner.id, conference.id)

    assert "СТРУКТУРИРОВАННЫЕ ДАННЫЕ РЕЦЕПТА" in ai.text
    assert "Abstract deadline: 2027-02-19" in ai.text


@pytest.mark.asyncio
async def test_monitoring_skips_verifier_for_exact_official_citation(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=9_105)
    conference = Conference(
        name="Official Meeting",
        normalized_name="official meeting",
        website="https://event.example/",
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()
    ai = MonitoringAI()

    await MonitoringService(session, MonitoringFetcher(), ai, 100_000, 50_000).check_conference(
        owner.id, conference.id
    )

    assert ai.extract_calls == 1
    assert ai.verify_calls == 0
