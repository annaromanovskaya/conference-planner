from datetime import UTC, date, datetime, timedelta

import pytest

from conference_planner.app import _build_read_handlers
from conference_planner.db.migrations import run_migrations
from conference_planner.db.repositories.conference_research import (
    CandidateDraft,
    ConferenceResearchRepository,
)
from conference_planner.db.repositories.users import UserRepository
from conference_planner.db.session import create_engine_and_sessionmaker
from conference_planner.owner import OwnerContext
from conference_planner.schemas.common import CandidateStatus, VerificationStatus


@pytest.mark.asyncio
async def test_pending_candidate_handler_returns_only_owner_active_candidates(tmp_path) -> None:
    database_url = f"sqlite+aiosqlite:///{tmp_path / 'pending.db'}"
    run_migrations(database_url)
    engine, factory = create_engine_and_sessionmaker(database_url)
    try:
        async with factory() as session:
            owner = await UserRepository(session).get_or_create_by_telegram_id(71)
            other = await UserRepository(session).get_or_create_by_telegram_id(72)
            expires_at = datetime.now(UTC) + timedelta(days=2)
            repository = ConferenceResearchRepository(session)
            active = (
                await repository.create_candidates(
                    owner.id,
                    [
                        CandidateDraft(
                            title="Astrochemistry 2027",
                            source_url="https://event.example/astrochemistry-2027",
                            query="astrochemistry",
                            relevance_score=0.9,
                            summary="Molecular clouds",
                            verification_status=VerificationStatus.SECONDARY_UNVERIFIED,
                        )
                    ],
                    expires_at=expires_at,
                )
            )[0]
            active.start_date = date(2027, 6, 14)
            active.research_payload = {
                "deadlines": [
                    {
                        "deadline_type": "ABSTRACT_SUBMISSION",
                        "exact_date": "2027-02-01",
                    }
                ]
            }
            rejected = (
                await repository.create_candidates(
                    owner.id,
                    [
                        CandidateDraft(
                            title="Rejected meeting",
                            source_url="https://event.example/rejected",
                            query="stars",
                            relevance_score=0.8,
                            verification_status=VerificationStatus.UNVERIFIABLE,
                        )
                    ],
                    expires_at=expires_at,
                )
            )[0]
            rejected.status = CandidateStatus.REJECTED
            await repository.create_candidates(
                other.id,
                [
                    CandidateDraft(
                        title="Other owner's meeting",
                        source_url="https://event.example/other",
                        query="stars",
                        relevance_score=1.0,
                        verification_status=VerificationStatus.UNVERIFIABLE,
                    )
                ],
                expires_at=expires_at,
            )
            await session.commit()
            owner_context = OwnerContext(owner.id, owner.telegram_id)

        handlers = _build_read_handlers(
            factory,
            owner_context,
            None,
            search=None,
            fetcher=None,
            settings=None,
            application_clock=None,
        )
        result = await handlers["list_pending_candidates"](owner.id, {"limit": 20})

        assert result["count"] == 1
        assert result["provenance"] == {"source": "database", "status": "ACTIVE"}
        assert result["items"] == [
            {
                "kind": "event_candidate",
                "id": active.id,
                "title": "Astrochemistry 2027",
                "url": "https://event.example/astrochemistry-2027",
                "official_url": None,
                "summary": "Molecular clouds",
                "verification_status": "SECONDARY_UNVERIFIED",
                "start_date": date(2027, 6, 14),
                "end_date": None,
                "location": None,
                "deadlines": [
                    {
                        "deadline_type": "ABSTRACT_SUBMISSION",
                        "exact_date": "2027-02-01",
                    }
                ],
                "relevance_score": None,
                "relevance_reason": None,
                "researched_at": None,
            }
        ]
    finally:
        await engine.dispose()
