from datetime import date

import pytest
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from conference_planner.bot.conference_router import conference_details_text, deadline_list_text
from conference_planner.conferences.monitoring import MonitoringCheckError, MonitoringService
from conference_planner.db.models import (
    Conference,
    ConferenceEvidence,
    Deadline,
    Subscription,
    User,
)
from conference_planner.db.repositories.conference_research import ConferenceResearchRepository
from conference_planner.db.repositories.conferences import ConferenceRepository
from conference_planner.db.repositories.reminders import ReminderRepository
from conference_planner.schemas.research import ConferenceResearch, VerifiedConferenceResearch
from conference_planner.web.fetcher import FetchedPage, FetchError

IMPORTANT_DATES = "https://meetings.iac.es/imbase2027/pages/important-dates.php"


class ImbaseFetcher:
    async def fetch(self, url: str, *, max_bytes: int):
        return FetchedPage(
            url,
            "<main>Official ImBaSE 2027 important dates. "
            "12th of July 2027: ImBaSE2027 starts. July 12-16, 2027. "
            "Tenerife, Canary Islands, Spain. "
            "November 2026: registration opens (tentative). "
            "January 2027: oral abstract submission closes (tentative). "
            "March 2027: notification of acceptance (tentative). "
            "May 2027: registration, posters and payment deadline (tentative)."
            "</main>",
        )


class ImbaseAI:
    async def extract_conference_research(self, source_url, _text, expected_name):
        assert expected_name == "ImBaSE 2027"
        facts = [
            ("start_date", "2027-07-12", "12th of July 2027: ImBaSE2027 starts"),
            ("end_date", "2027-07-16", "July 12-16, 2027"),
            ("location", "Tenerife, Canary Islands, Spain", "Tenerife, Canary Islands, Spain"),
        ]
        periods = [
            ("REGISTRATION_OPEN", 2026, 11, "November 2026: registration opens"),
            (
                "ORAL_ABSTRACT_SUBMISSION",
                2027,
                1,
                "January 2027: oral abstract submission closes",
            ),
            (
                "ACCEPTANCE_NOTIFICATION",
                2027,
                3,
                "March 2027: notification of acceptance",
            ),
            (
                "REGISTRATION",
                2027,
                5,
                "May 2027: registration, posters and payment deadline",
            ),
        ]
        return ConferenceResearch.model_validate(
            {
                "name": "ImBaSE 2027",
                "source_url": source_url,
                "source_class": "OFFICIAL_CONFERENCE",
                "facts": [
                    {
                        "kind": kind,
                        "value": value,
                        "source_url": source_url,
                        "source_class": "OFFICIAL_CONFERENCE",
                        "excerpt": excerpt,
                        "verification_status": "OFFICIAL_CONFIRMED",
                    }
                    for kind, value, excerpt in facts
                ],
                "deadlines": [
                    {
                        "deadline_type": kind,
                        "approximate_year": year,
                        "approximate_month": month,
                        "tentative": True,
                        "source_url": source_url,
                        "source_class": "OFFICIAL_CONFERENCE",
                        "excerpt": excerpt + " (tentative)",
                        "verification_status": "TENTATIVE",
                    }
                    for kind, year, month, excerpt in periods
                ],
            }
        )

    async def verify_conference_research(self, research):
        return VerifiedConferenceResearch.model_validate(research.model_dump(mode="json"))


@pytest.mark.asyncio
async def test_imbase_placeholder_becomes_verified_card_and_deadline_list(
    session: AsyncSession,
) -> None:
    owner = User(telegram_id=1200)
    conference = Conference(
        name="ImBaSE 2027",
        normalized_name="imbase 2027",
        website=IMPORTANT_DATES,
        source_url=IMPORTANT_DATES,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()

    receipt = await MonitoringService(
        session, ImbaseFetcher(), ImbaseAI(), 100_000, 50_000
    ).check_conference(owner.id, conference.id)

    await session.refresh(conference)
    deadlines = await ConferenceRepository(session).list_deadlines(conference.id)
    evidence = await ConferenceResearchRepository(session).list_evidence(conference.id)
    changes = await ConferenceResearchRepository(session).list_changes(conference.id)
    upcoming = await ReminderRepository(session).upcoming(owner.id, date(2026, 10, 14))
    card = conference_details_text(conference, deadlines, evidence, changes)
    deadline_text = deadline_list_text(upcoming)

    assert receipt.committed is True
    assert receipt.conference_id == conference.id
    assert receipt.evidence_ids and all(value > 0 for value in receipt.evidence_ids)
    assert conference.start_date == date(2027, 7, 12)
    assert conference.end_date == date(2027, 7, 16)
    assert conference.location == "Tenerife, Canary Islands, Spain"
    assert len(deadlines) == 4
    assert all(item.deadline_date is None and item.tentative for item in deadlines)
    assert {(item.approximate_year, item.approximate_month) for item in deadlines} == {
        (2026, 11),
        (2027, 1),
        (2027, 3),
        (2027, 5),
    }
    assert all(item.source_url == IMPORTANT_DATES for item in evidence)
    assert "Tenerife" in card and "ориентировочно" in card
    assert "ноябрь 2026" in deadline_text and "май 2027" in deadline_text


@pytest.mark.asyncio
async def test_unavailable_official_page_never_creates_false_success(
    session: AsyncSession,
) -> None:
    class OfflineFetcher:
        async def fetch(self, _url: str, *, max_bytes: int):
            raise FetchError("private TLS diagnostics")

    owner = User(telegram_id=1201)
    conference = Conference(
        name="ImBaSE 2027",
        normalized_name="imbase 2027",
        website=IMPORTANT_DATES,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()

    with pytest.raises(MonitoringCheckError) as error:
        await MonitoringService(
            session, OfflineFetcher(), ImbaseAI(), 100_000, 50_000
        ).check_conference(owner.id, conference.id)

    assert "private" not in str(error.value)
    assert await session.scalar(select(func.count()).select_from(Deadline)) == 0
    assert await session.scalar(select(func.count()).select_from(ConferenceEvidence)) == 0


@pytest.mark.asyncio
async def test_network_failure_uses_reader_text_and_saves_imbase_deadlines(
    session: AsyncSession,
) -> None:
    class OfflineFetcher:
        async def fetch(self, _url: str, *, max_bytes: int, **_kwargs):
            raise FetchError("broken certificate", code="NETWORK_ERROR")

    class Reader:
        def __init__(self) -> None:
            self.urls: list[str] = []

        async def read(self, url: str, *, max_bytes: int) -> str:
            self.urls.append(url)
            return (
                "Important dates. July 12-16, 2027. "
                "November 2026: registration opens (tentative). "
                "January 2027: oral abstract submission closes (tentative). "
                "March 2027: notification of acceptance (tentative). "
                "May 2027: registration, posters and payment deadline (tentative)."
            )

    owner = User(telegram_id=1202)
    conference = Conference(
        name="ImBaSE 2027",
        normalized_name="imbase 2027",
        website=IMPORTANT_DATES,
    )
    session.add_all([owner, conference])
    await session.flush()
    session.add(Subscription(user_id=owner.id, conference_id=conference.id))
    await session.commit()
    reader = Reader()

    receipt = await MonitoringService(
        session,
        OfflineFetcher(),
        ImbaseAI(),
        100_000,
        50_000,
        reader=reader,
    ).check_conference(owner.id, conference.id)

    deadlines = await ConferenceRepository(session).list_deadlines(conference.id)
    assert receipt.committed is True
    assert len(deadlines) == 4
    assert reader.urls == [IMPORTANT_DATES]
