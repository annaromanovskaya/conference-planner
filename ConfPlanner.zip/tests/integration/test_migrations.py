from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from alembic.script import ScriptDirectory
from sqlalchemy import create_engine, inspect

from conference_planner.db.base import Base
from conference_planner.db.migrations import run_migrations


def _url(path: Path) -> str:
    return f"sqlite+aiosqlite:///{path}"


def _config(database: Path) -> Config:
    root = Path(__file__).resolve().parents[2]
    config = Config(str(root / "alembic.ini"))
    config.set_main_option("script_location", str(root / "migrations"))
    config.set_main_option("sqlalchemy.url", f"sqlite:///{database}")
    return config


def test_migration_history_is_one_baseline_and_one_compatibility_step(
    tmp_path: Path,
) -> None:
    scripts = ScriptDirectory.from_config(_config(tmp_path / "graph.db"))

    assert scripts.get_heads() == ["20261029_0016"]
    assert scripts.get_revision("20261024_0015").down_revision is None
    assert scripts.get_revision("20261029_0016").down_revision == "20261024_0015"


def test_fresh_database_has_complete_current_schema(tmp_path: Path) -> None:
    database = tmp_path / "fresh.db"

    run_migrations(_url(database))

    engine = create_engine(f"sqlite:///{database}")
    inspector = inspect(engine)
    assert set(Base.metadata.tables) | {"alembic_version"} == set(
        inspector.get_table_names()
    )
    assert "is_catalog_source" in {
        item["name"] for item in inspector.get_columns("conferences")
    }
    assert (
        engine.connect()
        .exec_driver_sql("SELECT version_num FROM alembic_version")
        .scalar_one()
        == "20261029_0016"
    )
    engine.dispose()


def test_existing_0015_database_is_upgraded_without_losing_rows(tmp_path: Path) -> None:
    database = tmp_path / "existing.db"
    config = _config(database)
    command.upgrade(config, "20261024_0015")
    engine = create_engine(f"sqlite:///{database}")
    with engine.begin() as connection:
        connection.exec_driver_sql("DROP INDEX ix_conferences_is_catalog_source")
        connection.exec_driver_sql("ALTER TABLE conferences DROP COLUMN is_catalog_source")
        connection.exec_driver_sql(
            "INSERT INTO trusted_sources "
            "(id, url, name, source_type, enabled, created_at) VALUES "
            "(1, 'https://example.org/events', 'Example Events', 'PAGE', 1, CURRENT_TIMESTAMP)"
        )
        connection.exec_driver_sql(
            "INSERT INTO conferences "
            "(id, name, normalized_name, website, status, is_test, created_at, updated_at) "
            "VALUES (1, 'Example Events', 'example events', "
            "'https://example.org/events', 'ARCHIVED', 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
        )
    engine.dispose()

    command.upgrade(config, "head")

    engine = create_engine(f"sqlite:///{database}")
    with engine.connect() as connection:
        assert connection.exec_driver_sql(
            "SELECT name, is_catalog_source FROM conferences WHERE id = 1"
        ).one() == ("Example Events", 1)
    engine.dispose()


def test_0016_restores_missing_catalog_source_index(tmp_path: Path) -> None:
    database = tmp_path / "missing-index.db"
    config = _config(database)
    command.upgrade(config, "20261024_0015")
    engine = create_engine(f"sqlite:///{database}")
    with engine.begin() as connection:
        connection.exec_driver_sql("DROP INDEX ix_conferences_is_catalog_source")
    engine.dispose()

    command.upgrade(config, "head")

    engine = create_engine(f"sqlite:///{database}")
    assert "ix_conferences_is_catalog_source" in {
        item["name"] for item in inspect(engine).get_indexes("conferences")
    }
    engine.dispose()


def test_baseline_rejects_unknown_partial_database(tmp_path: Path) -> None:
    database = tmp_path / "partial.db"
    engine = create_engine(f"sqlite:///{database}")
    with engine.begin() as connection:
        connection.exec_driver_sql("CREATE TABLE unknown_table (id INTEGER PRIMARY KEY)")
    engine.dispose()

    with pytest.raises(RuntimeError, match="non-empty database"):
        run_migrations(_url(database))
