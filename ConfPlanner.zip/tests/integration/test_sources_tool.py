import pytest

from conference_planner.app import _build_read_handlers
from conference_planner.db.migrations import run_migrations
from conference_planner.db.repositories.sources import SourceRepository
from conference_planner.db.repositories.users import UserRepository
from conference_planner.db.session import create_engine_and_sessionmaker
from conference_planner.owner import OwnerContext
from conference_planner.schemas.common import SourceType


@pytest.mark.asyncio
async def test_list_sources_handler_reads_persisted_source_registry(tmp_path) -> None:
    database_url = f"sqlite+aiosqlite:///{tmp_path / 'sources.db'}"
    run_migrations(database_url)
    engine, factory = create_engine_and_sessionmaker(database_url)
    try:
        async with factory() as session:
            owner = await UserRepository(session).get_or_create_by_telegram_id(81)
            source = await SourceRepository(session).create(
                "https://www.eso.org/sci/meetings/2027.html",
                "ESO Meetings 2027",
                SourceType.PAGE,
            )
            await session.commit()
            owner_context = OwnerContext(owner.id, owner.telegram_id)

        handlers = _build_read_handlers(
            factory,
            owner_context,
            None,
            search=None,
            fetcher=None,
            settings=None,
            application_clock=None,
        )
        result = await handlers["list_sources"](owner.id, {"limit": 20})

        assert result == {
            "items": [
                {
                    "kind": "source",
                    "id": source.id,
                    "name": "ESO Meetings 2027",
                    "url": "https://www.eso.org/sci/meetings/2027.html",
                    "source_type": "PAGE",
                    "enabled": True,
                    "last_checked_at": None,
                }
            ],
            "provenance": {"source": "database"},
        }
    finally:
        await engine.dispose()
